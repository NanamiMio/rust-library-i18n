// Haiku implements the image_info struct and the get_next_image_info() functions to iterate through the loaded executable images. <br>Haiku 实现了 image_info 结构和 get_next_image_info() 函数来迭代加载的可执行图像。<br>
// The image_info struct contains a pointer to the start of the .text section within the virtual address space, as well as the size of that section. <br>image_info 结构体包含一个指向虚拟地址空间内 .text 部分开头的指针，以及该部分的大小。<br>
//
// All the read-only segments of the ELF-binary are in that part of the address space. <br>ELF 二进制文件的所有只读段都在地址空间的这一部分。<br>
//
//

use super::mystd::borrow::ToOwned;
use super::mystd::ffi::{CStr, OsStr};
use super::mystd::mem::MaybeUninit;
use super::mystd::os::unix::prelude::*;
use super::{Library, LibrarySegment, Vec};

pub(super) fn native_libraries() -> Vec<Library> {
    let mut libraries: Vec<Library> = Vec::new();

    unsafe {
        let mut info = MaybeUninit::<libc::image_info>::zeroed();
        let mut cookie: i32 = 0;
        // Load the first image to get a valid info struct <br>加载第一张图片以获取有效信息结构体<br>
        let mut status =
            libc::get_next_image_info(libc::B_CURRENT_TEAM, &mut cookie, info.as_mut_ptr());
        if status != libc::B_OK {
            return libraries;
        }
        let mut info = info.assume_init();

        while status == libc::B_OK {
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: info.text_size as usize,
            });

            let bytes = CStr::from_ptr(info.name.as_ptr()).to_bytes();
            let name = OsStr::from_bytes(bytes).to_owned();
            libraries.push(Library {
                name: name,
                segments: segments,
                bias: info.text as usize,
            });

            status = libc::get_next_image_info(libc::B_CURRENT_TEAM, &mut cookie, &mut info);
        }
    }

    libraries
}

#![allow(deprecated)]

use super::mystd::ffi::{CStr, OsStr};
use super::mystd::os::unix::prelude::*;
use super::mystd::prelude::v1::*;
use super::{Library, LibrarySegment};
use core::convert::TryInto;
use core::mem;

pub(super) fn native_libraries() -> Vec<Library> {
    let mut ret = Vec::new();
    let images = unsafe { libc::_dyld_image_count() };
    for i in 0..images {
        ret.extend(native_library(i));
    }
    return ret;
}

fn native_library(i: u32) -> Option<Library> {
    use object::macho;
    use object::read::macho::{MachHeader, Segment};
    use object::NativeEndian;

    // Fetch the name of this library which corresponds to the path of where to load it as well. <br>获取该库的名称，该名称也与加载该库的路径相对应。<br>
    //
    let name = unsafe {
        let name = libc::_dyld_get_image_name(i);
        if name.is_null() {
            return None;
        }
        CStr::from_ptr(name)
    };

    // Load the image header of this library and delegate to `object` to parse all the load commands so we can figure out all the segments involved here. <br>加载该库的图像头并将其委托给 `object` 来解析所有加载命令，因此我们可以找出此处涉及的所有段。<br>
    //
    //
    let (mut load_commands, endian) = unsafe {
        let header = libc::_dyld_get_image_header(i);
        if header.is_null() {
            return None;
        }
        match (*header).magic {
            macho::MH_MAGIC => {
                let endian = NativeEndian;
                let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                let data = core::slice::from_raw_parts(
                    header as *const _ as *const u8,
                    mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize,
                );
                (header.load_commands(endian, data, 0).ok()?, endian)
            }
            macho::MH_MAGIC_64 => {
                let endian = NativeEndian;
                let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                let data = core::slice::from_raw_parts(
                    header as *const _ as *const u8,
                    mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize,
                );
                (header.load_commands(endian, data, 0).ok()?, endian)
            }
            _ => return None,
        }
    };

    // Iterate over the segments and register known regions for segments that we find. <br>遍历这些段，并为找到的段注册已知区域。<br>
    // Additionally record information bout text segments for processing later, see comments below. <br>另外，记录有关文本段的信息以供以后处理，请参见下面的注释。<br>
    //
    let mut segments = Vec::new();
    let mut first_text = 0;
    let mut text_fileoff_zero = false;
    while let Some(cmd) = load_commands.next().ok()? {
        if let Some((seg, _)) = cmd.segment_32().ok()? {
            if seg.name() == b"__TEXT" {
                first_text = segments.len();
                if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                    text_fileoff_zero = true;
                }
            }
            segments.push(LibrarySegment {
                len: seg.vmsize(endian).try_into().ok()?,
                stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
            });
        }
        if let Some((seg, _)) = cmd.segment_64().ok()? {
            if seg.name() == b"__TEXT" {
                first_text = segments.len();
                if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                    text_fileoff_zero = true;
                }
            }
            segments.push(LibrarySegment {
                len: seg.vmsize(endian).try_into().ok()?,
                stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
            });
        }
    }

    // Determine the "slide" for this library which ends up being the bias we use to figure out where in memory objects are loaded. <br>确定该库的 "slide"，这最终是我们用来确定内存对象加载位置的偏差。<br>
    // This is a bit of a weird computation though and is the result of trying a few things in the wild and seeing what sticks. <br>但是，不过，这是一个有点奇怪的计算，并且是在野外尝试一些东西并看到什么是坚持的结果。<br>
    //
    // The general idea is that the `bias` plus a segment's `stated_virtual_memory_address` is going to be where in the actual address space the segment resides. <br>通常的想法是，`bias` 加上段的 `stated_virtual_memory_address` 将成为该段在实际地址空间中的位置。<br>
    // The other thing we rely on though is that a real address minus the `bias` is the index to look up in the symbol table and debuginfo. <br>但是，我们所依赖的另一件事是，实际地址减去 `bias` 是要在符号表和 debuginfo 中查找的索引。<br>
    //
    // It turns out, though, that for system loaded libraries these calculations are incorrect. <br>但是事实证明，对于系统加载的库，这些计算是不正确的。<br> For native executables, however, it appears correct. <br>但是，对于原生可执行文件，它似乎是正确的。<br>
    // Lifting some logic from LLDB's source it has some special-casing for the first `__TEXT` section loaded from file offset 0 with a nonzero size. <br>从 LLDB 的源代码中提取了一些逻辑，它对从文件偏移量 0 (非零大小) 加载的第一个 `__TEXT` 节有一些特殊的框。<br>
    // For whatever reason when this is present it appears to mean that the symbol table is relative to just the vmaddr slide for the library. <br>无论出于何种原因，出现这种情况似乎都意味着符号表仅相对于库的 vmaddr 幻灯片。<br>
    // If it's *not* present then the symbol table is relative to the the vmaddr slide plus the segment's stated address. <br>如果 *不存在*，则符号表是相对于 vmaddr 幻灯片加上段的声明地址的。<br>
    //
    // To handle this situation if we *don't* find a text section at file offset zero then we increase the bias by the first text sections's stated address and decrease all stated addresses by that amount as well. <br>为了处理这种情况，如果我们 *找不到* 文件偏移量为零的文本部分，那么我们将增加第一个文本部分的声明地址的偏见，并将所有声明地址也减少该数量。<br>
    //
    // That way the symbol table is always appears relative to the library's bias amount. <br>这样，符号表总是相对于库的偏差量出现。<br>
    // This appears to have the right results for symbolizing via the symbol table. <br>这似乎对于通过符号表进行符号化具有正确的结果。<br>
    //
    // Honestly I'm not entirely sure whether this is right or if there's something else that should indicate how to do this. <br>老实说，我不确定这是正确的还是还有其他方法可以指示如何做到这一点。<br>
    // For now though this seems to work well enough (?) and we should always be able to tweak this over time if necessary. <br>目前，尽管 (?) 看起来已经足够好了，但如果有必要，我们应该可以随时对其进行调整。<br>
    //
    // For some more information see #318 <br>有关更多信息，请参见 #318。<br>
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
    if !text_fileoff_zero {
        let adjust = segments[first_text].stated_virtual_memory_address;
        for segment in segments.iter_mut() {
            segment.stated_virtual_memory_address -= adjust;
        }
        slide += adjust;
    }

    Some(Library {
        name: OsStr::from_bytes(name.to_bytes()).to_owned(),
        segments,
        bias: slide,
    })
}

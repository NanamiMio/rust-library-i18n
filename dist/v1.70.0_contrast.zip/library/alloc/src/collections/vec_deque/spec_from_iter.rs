use super::{IntoIter, VecDeque};

/// Specialization trait used for `VecDeque::from_iter` <br>专业化 trait 用于 `VecDeque::from_iter`<br>
pub(super) trait SpecFromIter<T, I> {
    fn spec_from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for VecDeque<T>
where
    I: Iterator<Item = T>,
{
    default fn spec_from_iter(iterator: I) -> Self {
        // Since converting is O(1) now, just re-use the `Vec` logic for anything where we can't do something extra-special for `VecDeque`, especially as that could save us some monomorphiziation work if one uses the same iterators (like slice ones) with both. <br>由于现在转换为 O(1)，只需将 `Vec` 逻辑重新用于我们无法为 `VecDeque` 做一些特别的事情的任何事情，特别是如果我们对两者使用相同的迭代器 (如切片迭代器)，这可以为我们节省一些单态化工作.<br>
        //
        //
        //
        crate::vec::Vec::from_iter(iterator).into()
    }
}

impl<T> SpecFromIter<T, crate::vec::IntoIter<T>> for VecDeque<T> {
    #[inline]
    fn spec_from_iter(iterator: crate::vec::IntoIter<T>) -> Self {
        iterator.into_vecdeque()
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for VecDeque<T> {
    #[inline]
    fn spec_from_iter(iterator: IntoIter<T>) -> Self {
        iterator.into_vecdeque()
    }
}

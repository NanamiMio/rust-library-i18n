/// Zero-Sized Type (ZST) for internal `BTreeSet` values. <br>内部 `BTreeSet` 值的零大小类型 (ZST)。<br>
/// Used instead of `()` to differentiate between: <br>代替 `()` 用于区分:<br>
/// * `BTreeMap<T, ()>` (possible user-defined map) <br>`BTreeMap<T, ()>` (可能的用户自定义 map)<br>
/// * `BTreeMap<T, SetValZST>` (internal set representation) <br>`BTreeMap<T, SetValZST>` (内部集合表示)<br>
#[derive(Debug, Eq, PartialEq, Ord, PartialOrd, Hash, Clone, Default)]
pub struct SetValZST;

/// A trait to differentiate between `BTreeMap` and `BTreeSet` values. <br>用于区分 `BTreeMap` 和 `BTreeSet` 值的 trait。<br>
/// Returns `true` only for type `SetValZST`, `false` for all other types (blanket implementation). <br>仅对 `SetValZST` 类型返回 `true`，对所有其他类型返回 `false` (一揽子实现)。<br>
/// `TypeId` requires a `'static` lifetime, use of this trait avoids that restriction. <br>`TypeId` 需要一个 `'static` 生命周期，使用这个 trait 可以避免这个限制。<br>
///
/// [`TypeId`]: std::any::TypeId
pub trait IsSetVal {
    fn is_set_val() -> bool;
}

// Blanket implementation <br>一揽子实现<br>
impl<V> IsSetVal for V {
    default fn is_set_val() -> bool {
        false
    }
}

// Specialization
impl IsSetVal for SetValZST {
    fn is_set_val() -> bool {
        true
    }
}

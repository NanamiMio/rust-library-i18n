fn require_sync<T: Sync>(_: T) {}
fn require_send_sync<T: Send + Sync>(_: T) {}

struct NotSend(*const ());
unsafe impl Sync for NotSend {}

#[test]
fn test_btree_map() {
    // Tests of this form are prone to https://github.com/rust-lang/rust/issues/64552. <br>这种形式的测试很容易出现 https://github.com/rust-lang/rust/issues/64552。<br>
    //
    // In theory the async block's future would be Send if the value we hold across the await point is Send, and Sync if the value we hold across the await point is Sync. <br>理论上，如果我们在等待点上持有的值是 Send，则异步块的 future 将为 Send，如果我们在等待点上持有的值是 Sync，则为 Sync。<br>
    //
    // We test autotraits in this convoluted way, instead of a straightforward `require_send_sync::<TypeIWantToTest>()`, because the interaction with generators exposes some current limitations in rustc's ability to prove a lifetime bound on the erased generator witness types. <br>我们以这种复杂的方式测试 autotraits，而不是直接的 `require_send_sync::<TypeIWantToTest>()`，因为与生成器的交互暴露了 rustc 证明生命周期绑定在 erased 生成器见证类型上的能力的一些当前限制。<br>
    // See the above link. <br>请参见上面的链接。<br>
    //
    // A typical way this would surface in real code is: <br>在实际代码中出现的典型方式是:<br>
    //
    //     fn spawn<T: Future + Send>(_: T) {}
    //
    //     async fn f() {
    //         let map = BTreeMap::<u32, Box<dyn Send + Sync>>::new();
    //         for _ in &map { async {}.await; } }
    //
    //     fn main() {
    //         spawn(f());
    //     }
    //
    // where with some unintentionally overconstrained Send impls in alloc's internals, the future might incorrectly not be Send even though every single type involved in the program is Send and Sync. <br>在 alloc 的内部结构中有一些无意中过度约束的 Send impls，future 可能错误地不是 Send，即使程序中涉及的每个类型都是 Send 和 Sync。<br>
    //
    //
    //
    //
    //
    //
    //
    //
    //
    require_send_sync(async {
        let _v = None::<alloc::collections::btree_map::Iter<'_, &u32, &u32>>;
        async {}.await;
    });

    // Testing like this would not catch all issues that the above form catches. <br>像这样的测试不会捕捉到上述表格捕捉到的所有问题。<br>
    require_send_sync(None::<alloc::collections::btree_map::Iter<'_, &u32, &u32>>);

    require_sync(async {
        let _v = None::<alloc::collections::btree_map::Iter<'_, u32, NotSend>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_map::BTreeMap<&u32, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<
            alloc::collections::btree_map::DrainFilter<
                '_,
                &u32,
                &u32,
                fn(&&u32, &mut &u32) -> bool,
            >,
        >;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_map::Entry<'_, &u32, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_map::IntoIter<&u32, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_map::IntoKeys<&u32, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_map::IntoValues<&u32, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_map::Iter<'_, &u32, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_map::IterMut<'_, &u32, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_map::Keys<'_, &u32, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_map::OccupiedEntry<'_, &u32, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_map::OccupiedError<'_, &u32, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_map::Range<'_, &u32, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_map::RangeMut<'_, &u32, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_map::VacantEntry<'_, &u32, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_map::Values<'_, &u32, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_map::ValuesMut<'_, &u32, &u32>>;
        async {}.await;
    });
}

#[test]
fn test_btree_set() {
    require_send_sync(async {
        let _v = None::<alloc::collections::btree_set::BTreeSet<&u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_set::Difference<'_, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_set::DrainFilter<'_, &u32, fn(&&u32) -> bool>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_set::Intersection<'_, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_set::IntoIter<&u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_set::Iter<'_, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_set::Range<'_, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_set::SymmetricDifference<'_, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::btree_set::Union<'_, &u32>>;
        async {}.await;
    });
}

#[test]
fn test_binary_heap() {
    require_send_sync(async {
        let _v = None::<alloc::collections::binary_heap::BinaryHeap<&u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::binary_heap::Drain<'_, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::binary_heap::DrainSorted<'_, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::binary_heap::IntoIter<&u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::binary_heap::IntoIterSorted<&u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::binary_heap::Iter<'_, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::binary_heap::PeekMut<'_, &u32>>;
        async {}.await;
    });
}

#[test]
fn test_linked_list() {
    require_send_sync(async {
        let _v = None::<alloc::collections::linked_list::Cursor<'_, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::linked_list::CursorMut<'_, &u32>>;
        async {}.await;
    });

    // FIXME
    /*
    require_send_sync(async {
        let _v =
            None::<alloc::collections::linked_list::DrainFilter<'_, &u32, fn(&mut &u32) -> bool>>;
        async {}.await;
    });
    */

    require_send_sync(async {
        let _v = None::<alloc::collections::linked_list::IntoIter<&u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::linked_list::Iter<'_, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::linked_list::IterMut<'_, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::linked_list::LinkedList<&u32>>;
        async {}.await;
    });
}

#[test]
fn test_vec_deque() {
    require_send_sync(async {
        let _v = None::<alloc::collections::vec_deque::Drain<'_, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::vec_deque::IntoIter<&u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::vec_deque::Iter<'_, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::vec_deque::IterMut<'_, &u32>>;
        async {}.await;
    });

    require_send_sync(async {
        let _v = None::<alloc::collections::vec_deque::VecDeque<&u32>>;
        async {}.await;
    });
}

use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics::{self, const_eval_select};
use crate::mem;
use crate::slice::{self, SliceIndex};

impl<T: ?Sized> *const T {
    /// Returns `true` if the pointer is null. <br>如果指针为空，则返回 `true`。<br>
    ///
    /// Note that unsized types have many possible null pointers, as only the raw data pointer is considered, not their length, vtable, etc. <br>请注意，未定义大小的类型具有许多可能的空指针，因为仅考虑原始数据指针，而不考虑其长度，vtable 等。<br>
    /// Therefore, two pointers that are null may still not compare equal to each other. <br>因此，两个为空的指针可能仍不能相互比较相等。<br>
    ///
    /// ## Behavior during const evaluation <br>常量评估期间的行为<br>
    ///
    /// When this function is used during const evaluation, it may return `false` for pointers that turn out to be null at runtime. <br>在 const 评估期间使用此函数时，对于在运行时结果为空的指针，它可能返回 `false`。<br>
    /// Specifically, when a pointer to some memory is offset beyond its bounds in such a way that the resulting pointer is null, the function will still return `false`. <br>具体来说，当指向某个内存的指针超出其范围的偏移量 (使结果指针为空) 时，函数仍将返回 `false`。<br>
    ///
    /// There is no way for CTFE to know the absolute position of that memory, so we cannot tell if the pointer is null or not. <br>CTFE 无法知道该内存的绝对位置，因此我们无法确定指针是否为空。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        #[inline]
        fn runtime_impl(ptr: *const u8) -> bool {
            ptr.addr() == 0
        }

        #[inline]
        const fn const_impl(ptr: *const u8) -> bool {
            // Compare via a cast to a thin pointer, so fat pointers are only considering their "data" part for null-ness. <br>通过对瘦指针进行强制转换进行比较，因此胖指针仅考虑其 "data" 部分是否为空。<br>
            //
            match (ptr).guaranteed_eq(null_mut()) {
                None => false,
                Some(res) => res,
            }
        }

        // SAFETY: The two versions are equivalent at runtime. <br>这两个版本在运行时是等效的。<br>
        unsafe { const_eval_select((self as *const u8,), const_impl, runtime_impl) }
    }

    /// Casts to a pointer of another type. <br>强制转换为另一种类型的指针。<br>
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline(always)]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Use the pointer value in a new pointer of another type. <br>在另一种类型的新指针中使用指针值。<br>
    ///
    /// In case `meta` is a (fat) pointer to an unsized type, this operation will ignore the pointer part, whereas for (thin) pointers to sized types, this has the same effect as a simple cast. <br>如果 `meta` 是指向未定义大小类型的 (fat) 指针，此操作将忽略指针部分，而对于指向大小类型的 (thin) 指针，这与简单强制转换具有相同的效果。<br>
    ///
    /// The resulting pointer will have provenance of `self`, i.e., for a fat pointer, this operation is semantically the same as creating a new fat pointer with the data pointer value of `self` but the metadata of `meta`. <br>生成的指针将具有 `self` 的来源，即，对于胖指针，此操作在语义上与创建数据指针值为 `self` 但元数据为 `meta` 的新胖指针相同。<br>
    ///
    ///
    /// # Examples
    ///
    /// This function is primarily useful for allowing byte-wise pointer arithmetic on potentially fat pointers: <br>此函数主要用于允许对潜在的胖指针进行按字节指针算术运算：<br>
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = arr.as_ptr() as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = thin.add(8).with_metadata_of(ptr);
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // will print "3" <br>将打印 "3"<br>
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[rustc_const_unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub const fn with_metadata_of<U>(self, meta: *const U) -> *const U
    where
        U: ?Sized,
    {
        from_raw_parts::<U>(self as *const (), metadata(meta))
    }

    /// Changes constness without changing the type. <br>更改常量而不更改类型。<br>
    ///
    /// This is a bit safer than `as` because it wouldn't silently change the type if the code is refactored. <br>这比 `as` 安全一点，因为如果重构代码，它不会默默地改变类型。<br>
    ///
    #[stable(feature = "ptr_const_cast", since = "1.65.0")]
    #[rustc_const_stable(feature = "ptr_const_cast", since = "1.65.0")]
    #[inline(always)]
    pub const fn cast_mut(self) -> *mut T {
        self as _
    }

    /// Casts a pointer to its raw bits. <br>将指针强制转换为原始位。<br>
    ///
    /// This is equivalent to `as usize`, but is more specific to enhance readability. <br>这等效于 `as usize`，但更具体以增强可读性。<br>
    /// The inverse method is [`from_bits`](#method.from_bits). <br>相反的方法是 [`from_bits`](#method.from_bits)。<br>
    ///
    /// In particular, `*p as usize` and `p as usize` will both compile for pointers to numeric types but do very different things, so using this helps emphasize that reading the bits was intentional. <br>特别是，`*p as usize` 和 `p as usize` 都会编译指向数字类型的指针，但做的事情却截然不同，因此使用它有助于强调读取位是有意的。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ptr_to_from_bits)]
    /// # #[cfg(not(miri))] { // doctest does not work with strict provenance <br>doctest 不适用于严格的出处<br>
    /// let array = [13, 42];
    /// let p0: *const i32 = &array[0];
    /// assert_eq!(<*const _>::from_bits(p0.to_bits()), p0);
    /// let p1: *const i32 = &array[1];
    /// assert_eq!(p1.to_bits() - p0.to_bits(), 4);
    /// # }
    /// ```
    ///
    #[unstable(feature = "ptr_to_from_bits", issue = "91126")]
    #[deprecated(
        since = "1.67",
        note = "replaced by the `exposed_addr` method, or update your code \
            to follow the strict provenance rules using its APIs"
    )]
    #[inline(always)]
    pub fn to_bits(self) -> usize
    where
        T: Sized,
    {
        self as usize
    }

    /// Creates a pointer from its raw bits. <br>从其原始位创建一个指针。<br>
    ///
    /// This is equivalent to `as *const T`, but is more specific to enhance readability. <br>这等效于 `as *const T`，但更具体地说是为了增强可读性。<br>
    /// The inverse method is [`to_bits`](#method.to_bits). <br>相反的方法是 [`to_bits`](#method.to_bits)。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ptr_to_from_bits)]
    /// # #[cfg(not(miri))] { // doctest does not work with strict provenance <br>doctest 不适用于严格的出处<br>
    /// use std::ptr::NonNull;
    /// let dangling: *const u8 = NonNull::dangling().as_ptr();
    /// assert_eq!(<*const u8>::from_bits(1), dangling);
    /// # }
    /// ```
    #[unstable(feature = "ptr_to_from_bits", issue = "91126")]
    #[deprecated(
        since = "1.67",
        note = "replaced by the `ptr::from_exposed_addr` function, or update \
            your code to follow the strict provenance rules using its APIs"
    )]
    #[allow(fuzzy_provenance_casts)] // this is an unstable and semi-deprecated cast function <br>这是一个不稳定且半弃用的转换函数<br>
    #[inline(always)]
    pub fn from_bits(bits: usize) -> Self
    where
        T: Sized,
    {
        bits as Self
    }

    /// Gets the "address" portion of the pointer. <br>获取指针的 "address" 部分。<br>
    ///
    /// This is similar to `self as usize`, which semantically discards *provenance* and *address-space* information. <br>这类似于 `self as usize`，它在语义上丢弃了*provenance* 和*address-space* 信息。<br>
    /// However, unlike `self as usize`, casting the returned address back to a pointer yields [`invalid`][], which is undefined behavior to dereference. <br>但是，与 `self as usize` 不同，将返回的地址转换回指针会产生 [`invalid`][]，这对于解引用来说是未定义的行为。<br>
    /// To properly restore the lost information and obtain a dereferenceable pointer, use [`with_addr`][pointer::with_addr] or [`map_addr`][pointer::map_addr]. <br>要正确恢复丢失的信息并获得可解引用的指针，请使用 [`with_addr`][pointer::with_addr] 或 [`map_addr`][pointer::map_addr]。<br>
    ///
    /// If using those APIs is not possible because there is no way to preserve a pointer with the required provenance, use [`expose_addr`][pointer::expose_addr] and [`from_exposed_addr`][from_exposed_addr] instead. <br>如果由于无法保留具有所需出处的指针而无法使用这些 API，请改用 [`expose_addr`][pointer::expose_addr] 和 [`from_exposed_addr`][from_exposed_addr]。<br>
    ///
    /// However, note that this makes your code less portable and less amenable to tools that check for compliance with the Rust memory model. <br>但是，请注意，这会降低您的代码的可移植性，并且不太适合用于检查是否符合 Rust 内存模型的工具。<br>
    ///
    /// On most platforms this will produce a value with the same bytes as the original pointer, because all the bytes are dedicated to describing the address. <br>在大多数平台上，这将产生一个与原始指针具有相同字节的值，因为所有字节都专用于描述地址。<br>
    /// Platforms which need to store additional information in the pointer may perform a change of representation to produce a value containing only the address portion of the pointer. <br>需要在指针中存储附加信息的平台可以执行表示的改变，以产生仅包含指针的地址部分的值。<br>
    /// What that means is up to the platform to define. <br>这意味着什么取决于平台来定义。<br>
    ///
    /// This API and its claimed semantics are part of the Strict Provenance experiment, and as such might change in the future (including possibly weakening this so it becomes wholly equivalent to `self as usize`). <br>此 API 及其声明的语义是 Strict Provenance 实验的一部分，因此可能会在 future 中发生变化 (包括可能削弱这一点，使其完全等同于 `self as usize`)。<br>
    /// See the [module documentation][crate::ptr] for details. <br>有关详细信息，请参见 [[模块文档][crate::ptr]。<br>
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[must_use]
    #[inline(always)]
    #[unstable(feature = "strict_provenance", issue = "95228")]
    pub fn addr(self) -> usize {
        // FIXME(strict_provenance_magic): I am magic and should be a compiler intrinsic. <br>我是魔法，应该是编译器内部函数。<br>
        // SAFETY: Pointer-to-integer transmutes are valid (if you are okay with losing the provenance). <br>指针到整数的转换是有效的 (如果您同意丢失出处的话)。<br>
        //
        unsafe { mem::transmute(self.cast::<()>()) }
    }

    /// Gets the "address" portion of the pointer, and 'exposes' the "provenance" part for future use in [`from_exposed_addr`][]. <br>获取指针的 "address" 部分，并暴露 "provenance" 部分，以便将来在 [`from_exposed_addr`][] 中使用。<br>
    ///
    /// This is equivalent to `self as usize`, which semantically discards *provenance* and *address-space* information. <br>这相当于 `self as usize`，它在语义上丢弃了 *provenance* 和 *address-space* 信息。<br>
    /// Furthermore, this (like the `as` cast) has the implicit side-effect of marking the provenance as 'exposed', so on platforms that support it you can later call [`from_exposed_addr`][] to reconstitute the original pointer including its provenance. <br>此外，这 (如 `as` cast  一样) 具有将出处标记为 'exposed' 的隐式副作用，因此在支持它的平台上，您可以稍后调用 [`from_exposed_addr`][] 来重构原始指针，包括其出处。<br>
    ///
    /// (Reconstructing address space information, if required, is your responsibility.) <br>(如果需要，重建地址空间信息是您的责任。)<br>
    ///
    /// Using this method means that code is *not* following Strict Provenance rules. <br>使用这种方法意味着代码没有遵循严格的出处规则。<br>
    /// Supporting [`from_exposed_addr`][] complicates specification and reasoning and may not be supported by tools that help you to stay conformant with the Rust memory model, so it is recommended to use [`addr`][pointer::addr] wherever possible. <br>支持 [`from_exposed_addr`][] 会使规范和推理复杂化，并且可能不受帮助您与 Rust 内存模型保持一致的工具的支持，因此建议尽可能使用 [`addr`][pointer::addr]。<br>
    ///
    /// On most platforms this will produce a value with the same bytes as the original pointer, because all the bytes are dedicated to describing the address. <br>在大多数平台上，这将产生一个与原始指针具有相同字节的值，因为所有字节都专用于描述地址。<br>
    /// Platforms which need to store additional information in the pointer may not support this operation, since the 'expose' side-effect which is required for [`from_exposed_addr`][] to work is typically not available. <br>需要在指针中存储附加信息的平台可能不支持此操作，因为 [`from_exposed_addr`][] 工作所需的 'expose' 副作用通常不可用。<br>
    ///
    /// This API and its claimed semantics are part of the Strict Provenance experiment, see the [module documentation][crate::ptr] for details. <br>此 API 及其声明的语义是 Strict Provenance 实验的一部分，有关详细信息，请参见 [模块文档][crate::ptr]。<br>
    ///
    /// [`from_exposed_addr`]: from_exposed_addr
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[must_use]
    #[inline(always)]
    #[unstable(feature = "strict_provenance", issue = "95228")]
    pub fn expose_addr(self) -> usize {
        // FIXME(strict_provenance_magic): I am magic and should be a compiler intrinsic. <br>我是魔法，应该是编译器内部函数。<br>
        self.cast::<()>() as usize
    }

    /// Creates a new pointer with the given address. <br>使用给定地址创建一个新指针。<br>
    ///
    /// This performs the same operation as an `addr as ptr` cast, but copies the *address-space* and *provenance* of `self` to the new pointer. <br>这执行与 `addr as ptr` 强制转换相同的操作，但将 `self` 的 *address-space* 和 *provenance* 复制到新指针。<br>
    /// This allows us to dynamically preserve and propagate this important information in a way that is otherwise impossible with a unary cast. <br>这使我们能够动态地保存和传播这些重要信息，而这在其他情况下使用一元强制转换是不可能的。<br>
    ///
    /// This is equivalent to using [`wrapping_offset`][pointer::wrapping_offset] to offset `self` to the given address, and therefore has all the same capabilities and restrictions. <br>这相当于使用 [`wrapping_offset`][pointer::wrapping_offset] 将 `self` 偏移到给定地址，因此具有所有相同的功能和限制。<br>
    ///
    ///
    /// This API and its claimed semantics are part of the Strict Provenance experiment, see the [module documentation][crate::ptr] for details. <br>此 API 及其声明的语义是 Strict Provenance 实验的一部分，有关详细信息，请参见 [模块文档][crate::ptr]。<br>
    ///
    ///
    ///
    #[must_use]
    #[inline]
    #[unstable(feature = "strict_provenance", issue = "95228")]
    pub fn with_addr(self, addr: usize) -> Self {
        // FIXME(strict_provenance_magic): I am magic and should be a compiler intrinsic. <br>我是魔法，应该是编译器内部函数。<br>
        //
        // In the mean-time, this operation is defined to be "as if" it was a wrapping_offset, so we can emulate it as such. <br>同时，这个操作被定义为 "as if"，它是一个 wrapping_offset，所以我们可以模拟它。<br>
        // This should properly restore pointer provenance even under today's compiler. <br>即使在今天的编译器下，这也应该正确地恢复指针 Provenance。<br>
        //
        let self_addr = self.addr() as isize;
        let dest_addr = addr as isize;
        let offset = dest_addr.wrapping_sub(self_addr);

        // This is the canonical desugarring of this operation <br>这是这个操作的规范脱糖<br>
        self.wrapping_byte_offset(offset)
    }

    /// Creates a new pointer by mapping `self`'s address to a new one. <br>通过将 `self` 的地址映射到新地址来创建新指针。<br>
    ///
    /// This is a convenience for [`with_addr`][pointer::with_addr], see that method for details. <br>这对 [`with_addr`][pointer::with_addr] 来说是一种方便，有关详细信息，请参见该方法。<br>
    ///
    /// This API and its claimed semantics are part of the Strict Provenance experiment, see the [module documentation][crate::ptr] for details. <br>此 API 及其声明的语义是 Strict Provenance 实验的一部分，有关详细信息，请参见 [模块文档][crate::ptr]。<br>
    ///
    #[must_use]
    #[inline]
    #[unstable(feature = "strict_provenance", issue = "95228")]
    pub fn map_addr(self, f: impl FnOnce(usize) -> usize) -> Self {
        self.with_addr(f(self.addr()))
    }

    /// Decompose a (possibly wide) pointer into its address and metadata components. <br>将指针 (可能是宽指针) 分解为其地址和元数据组件。<br>
    ///
    /// The pointer can be later reconstructed with [`from_raw_parts`]. <br>以后可以使用 [`from_raw_parts`] 重建指针。<br>
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Returns `None` if the pointer is null, or else returns a shared reference to the value wrapped in `Some`. <br>如果指针为空，则返回 `None`，否则返回 `Some` 中包装的值的共享引用。<br> If the value may be uninitialized, [`as_uninit_ref`] must be used instead. <br>如果该值可能未初始化，则必须改用 [`as_uninit_ref`]。<br>
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// When calling this method, you have to ensure that *either* the pointer is null *or* all of the following is true: <br>调用此方法时，您必须确保要么指针是空的，要么以下所有内容都为 true：<br>
    ///
    /// * The pointer must be properly aligned. <br>指针必须正确对齐。<br>
    ///
    /// * It must be "dereferenceable" in the sense defined in [the module documentation]. <br>在 [模块的文档][the module documentation] 中定义的含义上，它必须是 "dereferenceable"。<br>
    ///
    /// * The pointer must point to an initialized instance of `T`. <br>指针必须指向 `T` 的初始化实例。<br>
    ///
    /// * You must enforce Rust's aliasing rules, since the returned lifetime `'a` is arbitrarily chosen and does not necessarily reflect the actual lifetime of the data. <br>您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。<br>
    ///   In particular, while this reference exists, the memory the pointer points to must not get mutated (except inside `UnsafeCell`). <br>特别是，当这个引用存在时，指针指向的内存不能发生可变 (`UnsafeCell` 内部除外)。<br>
    ///
    /// This applies even if the result of this method is unused! <br>即使未使用此方法的结果也是如此！<br>
    /// (The part about being initialized is not yet fully decided, but until it is, the only safe approach is to ensure that they are indeed initialized.) <br>(关于初始化的部分尚未完全决定，但是直到确定之前，唯一安全的方法是确保它们确实被初始化。)<br>
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {val_back}!");
    ///     }
    /// }
    /// ```
    ///
    /// # Null-unchecked version <br>空未经检查的版本<br>
    ///
    /// If you are sure the pointer can never be null and are looking for some kind of `as_ref_unchecked` that returns the `&T` instead of `Option<&T>`, know that you can dereference the pointer directly. <br>如果确定指针永远不会为空，并且正在寻找某种返回 `&T` 而不是 `Option<&T>` 的 `as_ref_unchecked`，请知道您可以直接引用该指针。<br>
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {val_back}!");
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[rustc_const_unstable(feature = "const_ptr_as_ref", issue = "91822")]
    #[inline]
    pub const unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SAFETY: the caller must guarantee that `self` is valid for a reference if it isn't null. <br>调用者必须保证 `self` 对于引用有效 (如果它不为 null)。<br>
        //
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Returns `None` if the pointer is null, or else returns a shared reference to the value wrapped in `Some`. <br>如果指针为空，则返回 `None`，否则返回 `Some` 中包装的值的共享引用。<br>
    /// In contrast to [`as_ref`], this does not require that the value has to be initialized. <br>与 [`as_ref`] 相比，这不需要将该值初始化。<br>
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// When calling this method, you have to ensure that *either* the pointer is null *or* all of the following is true: <br>调用此方法时，您必须确保要么指针是空的，要么以下所有内容都为 true：<br>
    ///
    /// * The pointer must be properly aligned. <br>指针必须正确对齐。<br>
    ///
    /// * It must be "dereferenceable" in the sense defined in [the module documentation]. <br>在 [模块的文档][the module documentation] 中定义的含义上，它必须是 "dereferenceable"。<br>
    ///
    /// * You must enforce Rust's aliasing rules, since the returned lifetime `'a` is arbitrarily chosen and does not necessarily reflect the actual lifetime of the data. <br>您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。<br>
    ///
    ///   In particular, while this reference exists, the memory the pointer points to must not get mutated (except inside `UnsafeCell`). <br>特别是，当这个引用存在时，指针指向的内存不能发生可变 (`UnsafeCell` 内部除外)。<br>
    ///
    /// This applies even if the result of this method is unused! <br>即使未使用此方法的结果也是如此！<br>
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    #[rustc_const_unstable(feature = "const_ptr_as_ref", issue = "91822")]
    pub const unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SAFETY: the caller must guarantee that `self` meets all the requirements for a reference. <br>调用者必须保证 `self` 满足引用的所有要求。<br>
        //
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Calculates the offset from a pointer. <br>计算与指针的偏移量。<br>
    ///
    /// `count` is in units of T; <br>`count` 以 T 为单位；<br> e.g., a `count` of 3 represents a pointer offset of `3 * size_of::<T>()` bytes. <br>例如，`count` 为 3 表示 `3 * size_of::<T>()` 字节的指针偏移量。<br>
    ///
    /// # Safety
    ///
    /// If any of the following conditions are violated, the result is Undefined Behavior: <br>如果违反以下任一条件，则结果为未定义行为：<br>
    ///
    /// * Both the starting and resulting pointer must be either in bounds or one byte past the end of the same [allocated object]. <br>起始指针和结果指针都必须在边界内或在同一个 [分配对象][allocated object] 的末尾之后一个字节。<br>
    ///
    /// * The computed offset, **in bytes**, cannot overflow an `isize`. <br>计算的偏移量 (以字节为单位) 不会使 `isize` 溢出。<br>
    ///
    /// * The offset being in bounds cannot rely on "wrapping around" the address space. <br>偏移量不能依赖 "wrapping around" 地址空间。<br> That is, the infinite-precision sum, **in bytes** must fit in a usize. <br>也就是说，无限精度总和 (以字节为单位) 必须适合于 usize。<br>
    ///
    /// The compiler and standard library generally tries to ensure allocations never reach a size where an offset is a concern. <br>编译器和标准库通常会尝试确保分配永远不会达到需要考虑偏移量的大小。<br>
    /// For instance, `Vec` and `Box` ensure they never allocate more than `isize::MAX` bytes, so `vec.as_ptr().add(vec.len())` is always safe. <br>例如，`Vec` 和 `Box` 确保它们分配的字节数永远不会超过 `isize::MAX` 字节，因此 `vec.as_ptr().add(vec.len())` 始终是安全的。<br>
    ///
    /// Most platforms fundamentally can't even construct such an allocation. <br>从根本上说，大多数平台甚至都无法构造这样的分配。<br>
    /// For instance, no known 64-bit platform can ever serve a request for 2<sup>63</sup> bytes due to page-table limitations or splitting the address space. <br>例如，由于页表的限制或地址空间的分割，没有已知的 64 位平台可以满足 2 <sup>63</sup> 字节的请求。<br>
    /// However, some 32-bit and 16-bit platforms may successfully serve a request for more than `isize::MAX` bytes with things like Physical Address Extension. <br>但是，某些 32 位和 16 位平台可能通过物理地址扩展之类的东西成功地为超过 `isize::MAX` 字节的请求提供服务。<br>
    ///
    /// As such, memory acquired directly from allocators or memory mapped files *may* be too large to handle with this function. <br>因此，直接从分配器获取的内存或内存映射文件 *可能* 太大而无法使用此函数进行处理。<br>
    ///
    /// Consider using [`wrapping_offset`] instead if these constraints are difficult to satisfy. <br>如果这些约束难以满足，请考虑使用 [`wrapping_offset`]。<br>
    /// The only advantage of this method is that it enables more aggressive compiler optimizations. <br>此方法的唯一优点是，它可以实现更积极的编译器优化。<br>
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    /// [allocated object]: crate::ptr#allocated-object
    ///
    /// # Examples
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_stable(feature = "const_ptr_offset", since = "1.61.0")]
    #[inline(always)]
    #[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces <br>即使没有 panic，这也有助于 Miri 回溯<br>
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `offset`. <br>调用者必须遵守 `offset` 的安全保证。<br>
        unsafe { intrinsics::offset(self, count) }
    }

    /// Calculates the offset from a pointer in bytes. <br>计算与指针的偏移量 (以字节为单位)。<br>
    ///
    /// `count` is in units of **bytes**. <br>`count` 以 **字节** 为单位。<br>
    ///
    /// This is purely a convenience for casting to a `u8` pointer and using [offset][pointer::offset] on it. <br>这纯粹是为了方便转换为 `u8` 指针并在其上使用 [offset][pointer::offset]。<br>
    /// See that method for documentation and safety requirements. <br>有关文档和安全要求，请参见该方法。<br>
    ///
    /// For non-`Sized` pointees this operation changes only the data pointer, leaving the metadata untouched. <br>对于非 `Sized` 指针，此操作仅更改数据指针，而保留元数据不变。<br>
    ///
    ///
    #[must_use]
    #[inline(always)]
    #[unstable(feature = "pointer_byte_offsets", issue = "96283")]
    #[rustc_const_unstable(feature = "const_pointer_byte_offsets", issue = "96283")]
    #[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces <br>即使没有 panic，这也有助于 Miri 回溯<br>
    pub const unsafe fn byte_offset(self, count: isize) -> Self {
        // SAFETY: the caller must uphold the safety contract for `offset`. <br>调用者必须遵守 `offset` 的安全保证。<br>
        unsafe { self.cast::<u8>().offset(count).with_metadata_of(self) }
    }

    /// Calculates the offset from a pointer using wrapping arithmetic. <br>使用换行算法计算与指针的偏移量。<br>
    ///
    /// `count` is in units of T; <br>`count` 以 T 为单位；<br> e.g., a `count` of 3 represents a pointer offset of `3 * size_of::<T>()` bytes. <br>例如，`count` 为 3 表示 `3 * size_of::<T>()` 字节的指针偏移量。<br>
    ///
    /// # Safety
    ///
    /// This operation itself is always safe, but using the resulting pointer is not. <br>此操作本身始终是安全的，但使用结果指针则不安全。<br>
    ///
    /// The resulting pointer "remembers" the [allocated object] that `self` points to; <br>结果指针 "remembers" 是 `self` 指向的 [分配对象][allocated object]；<br> it must not be used to read or write other allocated objects. <br>它不得用于读取或写入其他分配的对象。<br>
    ///
    /// In other words, `let z = x.wrapping_offset((y as isize) - (x as isize))` does *not* make `z` the same as `y` even if we assume `T` has size `1` and there is no overflow: `z` is still attached to the object `x` is attached to, and dereferencing it is Undefined Behavior unless `x` and `y` point into the same allocated object. <br>换句话说，即使我们假设 `T` 的大小为 `1` 并且没有溢出，`let z = x.wrapping_offset((y as isize) - (x as isize))` 不会使 `z` 与 `y` 相同: `z` 仍附加到对象 `x` 所附加的对象，并且解引用它是 Undefined Behavior，除非 `x` 和 `y` 指向同一分配的对象。<br>
    ///
    /// Compared to [`offset`], this method basically delays the requirement of staying within the same allocated object: [`offset`] is immediate Undefined Behavior when crossing object boundaries; <br>与 [`offset`] 相比，此方法从根本上延迟了留在同一分配对象内的需求: [`offset`] 是跨越对象边界时的立即未定义行为；<br> `wrapping_offset` produces a pointer but still leads to Undefined Behavior if a pointer is dereferenced when it is out-of-bounds of the object it is attached to. <br>`wrapping_offset` 产生一个指针，但如果指针超出其附加对象的范围而被解引用，则仍会导致未定义行为。<br>
    /// [`offset`] can be optimized better and is thus preferable in performance-sensitive code. <br>[`offset`] 可以更好地优化，因此在性能敏感的代码中更可取。<br>
    ///
    /// The delayed check only considers the value of the pointer that was dereferenced, not the intermediate values used during the computation of the final result. <br>延迟检查仅考虑解引用的指针的值，而不考虑最终结果计算期间使用的中间值。<br>
    /// For example, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` is always the same as `x`. <br>例如，`x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` 始终与 `x` 相同。<br> In other words, leaving the allocated object and then re-entering it later is permitted. <br>换句话说，允许离开已分配的对象，然后在以后重新输入它。<br>
    ///
    /// [`offset`]: #method.offset
    /// [allocated object]: crate::ptr#allocated-object
    ///
    /// # Examples
    ///
    /// ```
    /// // Iterate using a raw pointer in increments of two elements <br>使用裸指针以两个元素为增量进行迭代<br>
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // This loop prints "1, 3, 5, " <br>此循环打印 "1, 3, 5, "<br>
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_stable(feature = "const_ptr_offset", since = "1.61.0")]
    #[inline(always)]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SAFETY: the `arith_offset` intrinsic has no prerequisites to be called. <br>`arith_offset` 内部函数没有要调用的先决条件。<br>
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Calculates the offset from a pointer in bytes using wrapping arithmetic. <br>使用环绕算法计算与指针的偏移量 (以字节为单位)。<br>
    ///
    /// `count` is in units of **bytes**. <br>`count` 以 **字节** 为单位。<br>
    ///
    /// This is purely a convenience for casting to a `u8` pointer and using [wrapping_offset][pointer::wrapping_offset] on it. <br>这纯粹是为了方便转换为 `u8` 指针并在其上使用 [wrapping_offset][pointer::wrapping_offset]。<br>
    /// See that method for documentation. <br>请参见该方法以获取文档。<br>
    ///
    /// For non-`Sized` pointees this operation changes only the data pointer, leaving the metadata untouched. <br>对于非 `Sized` 指针，此操作仅更改数据指针，而保留元数据不变。<br>
    ///
    ///
    #[must_use]
    #[inline(always)]
    #[unstable(feature = "pointer_byte_offsets", issue = "96283")]
    #[rustc_const_unstable(feature = "const_pointer_byte_offsets", issue = "96283")]
    pub const fn wrapping_byte_offset(self, count: isize) -> Self {
        self.cast::<u8>().wrapping_offset(count).with_metadata_of(self)
    }

    /// Masks out bits of the pointer according to a mask. <br>根据掩码屏蔽指针的位。<br>
    ///
    /// This is convenience for `ptr.map_addr(|a| a & mask)`. <br>这对 `ptr.map_addr(|a| a & mask)` 来说很方便。<br>
    ///
    /// For non-`Sized` pointees this operation changes only the data pointer, leaving the metadata untouched. <br>对于非 `Sized` 指针，此操作仅更改数据指针，而保留元数据不变。<br>
    ///
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(ptr_mask, strict_provenance)]
    /// let v = 17_u32;
    /// let ptr: *const u32 = &v;
    ///
    /// // `u32` is 4 bytes aligned, which means that lower 2 bits are always <br>`u32` 是 4 字节对齐的，这意味着低 2 位总是<br> 0.
    /////
    /// let tag_mask = 0b11;
    /// let ptr_mask = !tag_mask;
    ///
    /// // We can store something in these lower bits <br>我们可以在这些低位存储一些东西<br>
    /// let tagged_ptr = ptr.map_addr(|a| a | 0b10);
    ///
    /// // Get the "tag" back <br>取回 "tag"<br>
    /// let tag = tagged_ptr.addr() & tag_mask;
    /// assert_eq!(tag, 0b10);
    ///
    /// // Note that `tagged_ptr` is unaligned, it's UB to read from it. <br>注意 `tagged_ptr` 是未对齐的，它是 UB 读取它。<br>
    /// // To get original pointer `mask` can be used: <br>要获得原始指针 `mask` 可以使用:<br>
    /// let masked_ptr = tagged_ptr.mask(ptr_mask);
    /// assert_eq!(unsafe { *masked_ptr }, 17);
    /// ```
    #[unstable(feature = "ptr_mask", issue = "98290")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline(always)]
    pub fn mask(self, mask: usize) -> *const T {
        intrinsics::ptr_mask(self.cast::<()>(), mask).with_metadata_of(self)
    }

    /// Calculates the distance between two pointers. <br>计算两个指针之间的距离。<br> The returned value is in units of T: the distance in bytes divided by `mem::size_of::<T>()`. <br>返回值以 T 为单位: 以字节为单位的距离除以 `mem::size_of::<T>()`。<br>
    ///
    /// This function is the inverse of [`offset`]. <br>该函数是 [`offset`] 的逆函数。<br>
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// If any of the following conditions are violated, the result is Undefined Behavior: <br>如果违反以下任一条件，则结果为未定义行为：<br>
    ///
    /// * Both the starting and other pointer must be either in bounds or one byte past the end of the same [allocated object]. <br>起始指针和其他指针都必须在边界内或在同一个 [分配对象][allocated object] 的末尾之后一个字节。<br>
    ///
    /// * Both pointers must be *derived from* a pointer to the same object. <br>两个指针必须是指向同一对象的指针的 *derived。<br>
    ///   (See below for an example.) <br>(请参见下面的示例。)<br>
    ///
    /// * The distance between the pointers, in bytes, must be an exact multiple of the size of `T`. <br>指针之间的距离 (以字节为单位) 必须是 `T` 大小的精确倍数。<br>
    ///
    /// * The distance between the pointers, **in bytes**, cannot overflow an `isize`. <br>指针之间的距离 (以字节为单位) 不会溢出 `isize`。<br>
    ///
    /// * The distance being in bounds cannot rely on "wrapping around" the address space. <br>该距离不能依赖于 "wrapping around" 地址空间。<br>
    ///
    /// Rust types are never larger than `isize::MAX` and Rust allocations never wrap around the address space, so two pointers within some value of any Rust type `T` will always satisfy the last two conditions. <br>Rust 类型从不大于 `isize::MAX`，并且 Rust 分配从不环绕地址空间，因此，任何 Rust 类型 `T` 的某个值内的两个指针将始终满足最后两个条件。<br>
    ///
    /// The standard library also generally ensures that allocations never reach a size where an offset is a concern. <br>标准库通常还确保分配永远不会达到需要考虑偏移量的大小。<br>
    /// For instance, `Vec` and `Box` ensure they never allocate more than `isize::MAX` bytes, so `ptr_into_vec.offset_from(vec.as_ptr())` always satisfies the last two conditions. <br>例如，`Vec` 和 `Box` 确保它们分配的字节数永远不超过 `isize::MAX` 字节，因此 `ptr_into_vec.offset_from(vec.as_ptr())` 始终满足最后两个条件。<br>
    ///
    /// Most platforms fundamentally can't even construct such a large allocation. <br>从根本上说，大多数平台甚至都无法构建如此大的分配。<br>
    /// For instance, no known 64-bit platform can ever serve a request for 2<sup>63</sup> bytes due to page-table limitations or splitting the address space. <br>例如，由于页表的限制或地址空间的分割，没有已知的 64 位平台可以满足 2 <sup>63</sup> 字节的请求。<br>
    /// However, some 32-bit and 16-bit platforms may successfully serve a request for more than `isize::MAX` bytes with things like Physical Address Extension. <br>但是，某些 32 位和 16 位平台可能通过物理地址扩展之类的东西成功地为超过 `isize::MAX` 字节的请求提供服务。<br>
    /// As such, memory acquired directly from allocators or memory mapped files *may* be too large to handle with this function. <br>因此，直接从分配器获取的内存或内存映射文件 *可能* 太大而无法使用此函数进行处理。<br>
    /// (Note that [`offset`] and [`add`] also have a similar limitation and hence cannot be used on such large allocations either.) <br>(请注意，[`offset`] 和 [`add`] 也具有类似的限制，因此也不能在如此大的分配上使用。)<br>
    ///
    /// [`add`]: #method.add
    /// [allocated object]: crate::ptr#allocated-object
    ///
    /// # Panics
    ///
    /// This function panics if `T` is a Zero-Sized Type ("ZST"). <br>如果 `T` 是零大小类型 ("ZST")，则此函数 panics。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Incorrect* usage: <br>*不正确* 用法：<br>
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Make ptr2_other an "alias" of ptr2, but derived from ptr1. <br>将 ptr2_other 设置为 ptr2 的 "alias"，但从 ptr1 派生。<br>
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Since ptr2_other and ptr2 are derived from pointers to different objects, computing their offset is undefined behavior, even though they point to the same address! <br>由于 ptr2_other 和 ptr2 是从指向不同对象的指针派生的，因此即使它们指向相同的地址，计算其偏移量也是未定义的行为！<br>
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Undefined Behavior <br>未定义的行为<br>
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_stable(feature = "const_ptr_offset_from", since = "1.65.0")]
    #[inline]
    #[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces <br>即使没有 panic，这也有助于 Miri 回溯<br>
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SAFETY: the caller must uphold the safety contract for `ptr_offset_from`. <br>调用者必须遵守 `ptr_offset_from` 的安全保证。<br>
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Calculates the distance between two pointers. <br>计算两个指针之间的距离。<br> The returned value is in units of **bytes**. <br>返回值以 **字节** 为单位。<br>
    ///
    /// This is purely a convenience for casting to a `u8` pointer and using [offset_from][pointer::offset_from] on it. <br>这纯粹是为了方便转换为 `u8` 指针并在其上使用 [offset_from][pointer::offset_from]。<br>
    /// See that method for documentation and safety requirements. <br>有关文档和安全要求，请参见该方法。<br>
    ///
    /// For non-`Sized` pointees this operation considers only the data pointers, ignoring the metadata. <br>对于非 `Sized` 指针，此操作仅考虑数据指针，忽略元数据。<br>
    ///
    ///
    ///
    #[inline(always)]
    #[unstable(feature = "pointer_byte_offsets", issue = "96283")]
    #[rustc_const_unstable(feature = "const_pointer_byte_offsets", issue = "96283")]
    #[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces <br>即使没有 panic，这也有助于 Miri 回溯<br>
    pub const unsafe fn byte_offset_from<U: ?Sized>(self, origin: *const U) -> isize {
        // SAFETY: the caller must uphold the safety contract for `offset_from`. <br>调用者必须遵守 `offset_from` 的安全保证。<br>
        unsafe { self.cast::<u8>().offset_from(origin.cast::<u8>()) }
    }

    /// Calculates the distance between two pointers, *where it's known that `self` is equal to or greater than `origin`*. The returned value is in units of T: the distance in bytes is divided by `mem::size_of::<T>()`. <br>计算两个指针之间的距离，*where 已知 `self` 等于或大于 `origin`*。返回值以 T 为单位: 以字节为单位的距离除以 `mem::size_of::<T>()`。<br>
    ///
    /// This computes the same value that [`offset_from`](#method.offset_from) would compute, but with the added precondition that the offset is guaranteed to be non-negative. <br>这将计算 [`offset_from`](#method.offset_from) 将计算的相同值，但附加的前提条件是偏移量保证为非 negative。<br>
    /// This method is equivalent to `usize::try_from(self.offset_from(origin)).unwrap_unchecked()`, but it provides slightly more information to the optimizer, which can sometimes allow it to optimize slightly better with some backends. <br>此方法等同于 `usize::try_from(self.offset_from(origin)).unwrap_unchecked()`，但它为优化器提供了更多的信息，这有时可以使其在某些后端优化得更好。<br>
    ///
    ///
    /// This method can be though of as recovering the `count` that was passed to [`add`](#method.add) (or, with the parameters in the other order, to [`sub`](#method.sub)). <br>这个方法可以看作是恢复传递给 [`add`](#method.add) 的 `count` (或者，使用其他顺序的参数，到 [`sub`](#method.sub)).<br>
    /// The following are all equivalent, assuming that their safety preconditions are met: <br>以下都是等价的，假设它们的安全先决条件得到满足:<br>
    ///
    /// ```rust
    /// # #![feature(ptr_sub_ptr)]
    /// # unsafe fn blah(ptr: *const i32, origin: *const i32, count: usize) -> bool {
    /// ptr.sub_ptr(origin) == count
    /// # &&
    /// origin.add(count) == ptr
    /// # &&
    /// ptr.sub(count) == origin
    /// # }
    /// ```
    ///
    /// # Safety
    ///
    /// - The distance between the pointers must be non-negative (`self >= origin`) <br>指针之间的距离必须是非 negative (`self >= origin`)<br>
    ///
    /// - *All* the safety conditions of [`offset_from`](#method.offset_from) apply to this method as well; <br>*所有*[`offset_from`](#method.offset_from) 的安全条件也适用于此方法;<br> see it for the full details. <br>查看完整的详细信息。<br>
    ///
    /// Importantly, despite the return type of this method being able to represent a larger offset, it's still *not permitted* to pass pointers which differ by more than `isize::MAX` *bytes*. <br>重要的是，尽管此方法的返回类型能够表示更大的偏移量，但仍然*不允许*传递相差超过 `isize::MAX` *bytes* 的指针。<br>
    /// As such, the result of this method will always be less than or equal to `isize::MAX as usize`. <br>因此，此方法的结果将始终小于或等于 `isize::MAX as usize`。<br>
    ///
    /// # Panics
    ///
    /// This function panics if `T` is a Zero-Sized Type ("ZST"). <br>如果 `T` 是零大小类型 ("ZST")，则此函数 panics。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ptr_sub_ptr)]
    ///
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.sub_ptr(ptr1), 2);
    ///     assert_eq!(ptr1.add(2), ptr2);
    ///     assert_eq!(ptr2.sub(2), ptr1);
    ///     assert_eq!(ptr2.sub_ptr(ptr2), 0);
    /// }
    ///
    /// // This would be incorrect, as the pointers are not correctly ordered: <br>这是不正确的，因为指针的顺序不正确:<br>
    /// // ptr1.sub_ptr(ptr2)
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "ptr_sub_ptr", issue = "95892")]
    #[rustc_const_unstable(feature = "const_ptr_sub_ptr", issue = "95892")]
    #[inline]
    #[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces <br>即使没有 panic，这也有助于 Miri 回溯<br>
    pub const unsafe fn sub_ptr(self, origin: *const T) -> usize
    where
        T: Sized,
    {
        let this = self;
        // SAFETY: The comparison has no side-effects, and the intrinsic does this check internally in the CTFE implementation. <br>比较没有副作用，内部函数在 CTFE 实现中进行内部检查。<br>
        //
        unsafe {
            assert_unsafe_precondition!(
                "ptr::sub_ptr requires `this >= origin`",
                [T](this: *const T, origin: *const T) => this >= origin
            )
        };

        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SAFETY: the caller must uphold the safety contract for `ptr_offset_from_unsigned`. <br>调用者必须维护 `ptr_offset_from_unsigned` 的安全保证。<br>
        unsafe { intrinsics::ptr_offset_from_unsigned(self, origin) }
    }

    /// Returns whether two pointers are guaranteed to be equal. <br>返回两个指针是否保证相等。<br>
    ///
    /// At runtime this function behaves like `Some(self == other)`. <br>在运行时，这个函数的行为类似于 `Some(self == other)`。<br>
    /// However, in some contexts (e.g., compile-time evaluation), it is not always possible to determine equality of two pointers, so this function may spuriously return `None` for pointers that later actually turn out to have its equality known. <br>但是，在某些情况下 (例如，编译时评估)，并不总是可以确定两个指针的相等性，因此该函数可能会虚假地返回 `None` 以获取稍后实际上证明其相等性已知的指针。<br>
    ///
    /// But when it returns `Some`, the pointers' equality is guaranteed to be known. <br>但是当它返回 `Some` 时，可以保证知道指针的相等性。<br>
    ///
    /// The return value may change from `Some` to `None` and vice versa depending on the compiler version and unsafe code must not rely on the result of this function for soundness. <br>返回值可能会从 `Some` 更改为 `None`，反之亦然，具体取决于编译器版本，并且不安全的代码不能依赖此函数的结果来保证可靠性。<br>
    /// It is suggested to only use this function for performance optimizations where spurious `None` return values by this function do not affect the outcome, but just the performance. <br>建议仅将此函数用于性能优化，其中此函数的虚假 `None` 返回值不会影响结果，而只会影响性能。<br>
    /// The consequences of using this method to make runtime and compile-time code behave differently have not been explored. <br>尚未探讨使用此方法使运行时和编译时代码表现不同的后果。<br>
    /// This method should not be used to introduce such differences, and it should also not be stabilized before we have a better understanding of this issue. <br>不应使用这种方法来引入这种差异，并且在我们对这个问题有更好的理解之前，也不应使其稳定。<br>
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> Option<bool>
    where
        T: Sized,
    {
        match intrinsics::ptr_guaranteed_cmp(self as _, other as _) {
            2 => None,
            other => Some(other == 1),
        }
    }

    /// Returns whether two pointers are guaranteed to be inequal. <br>返回是否保证两个指针不相等。<br>
    ///
    /// At runtime this function behaves like `Some(self != other)`. <br>在运行时，这个函数的行为类似于 `Some(self != other)`。<br>
    /// However, in some contexts (e.g., compile-time evaluation), it is not always possible to determine inequality of two pointers, so this function may spuriously return `None` for pointers that later actually turn out to have its inequality known. <br>然而，在某些情况下 (例如，编译时求值)，并不总是可以确定两个指针的不等式，因此该函数可能会虚假地返回 `None` 以获取后来实际证明其不等式的指针。<br>
    ///
    /// But when it returns `Some`, the pointers' inequality is guaranteed to be known. <br>但是当它返回 `Some` 时，指针的不等式保证是已知的。<br>
    ///
    /// The return value may change from `Some` to `None` and vice versa depending on the compiler version and unsafe code must not rely on the result of this function for soundness. <br>返回值可能会从 `Some` 更改为 `None`，反之亦然，具体取决于编译器版本，并且不安全的代码不能依赖此函数的结果来保证可靠性。<br>
    /// It is suggested to only use this function for performance optimizations where spurious `None` return values by this function do not affect the outcome, but just the performance. <br>建议仅将此函数用于性能优化，其中此函数的虚假 `None` 返回值不会影响结果，而只会影响性能。<br>
    /// The consequences of using this method to make runtime and compile-time code behave differently have not been explored. <br>尚未探讨使用此方法使运行时和编译时代码表现不同的后果。<br>
    /// This method should not be used to introduce such differences, and it should also not be stabilized before we have a better understanding of this issue. <br>不应使用这种方法来引入这种差异，并且在我们对这个问题有更好的理解之前，也不应使其稳定。<br>
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> Option<bool>
    where
        T: Sized,
    {
        match self.guaranteed_eq(other) {
            None => None,
            Some(eq) => Some(!eq),
        }
    }

    /// Calculates the offset from a pointer (convenience for `.offset(count as isize)`). <br>计算与指针的偏移量 (`.offset(count as isize)` 的便利性)。<br>
    ///
    /// `count` is in units of T; <br>`count` 以 T 为单位；<br> e.g., a `count` of 3 represents a pointer offset of `3 * size_of::<T>()` bytes. <br>例如，`count` 为 3 表示 `3 * size_of::<T>()` 字节的指针偏移量。<br>
    ///
    /// # Safety
    ///
    /// If any of the following conditions are violated, the result is Undefined Behavior: <br>如果违反以下任一条件，则结果为未定义行为：<br>
    ///
    /// * Both the starting and resulting pointer must be either in bounds or one byte past the end of the same [allocated object]. <br>起始指针和结果指针都必须在边界内或在同一个 [分配对象][allocated object] 的末尾之后一个字节。<br>
    ///
    /// * The computed offset, **in bytes**, cannot overflow an `isize`. <br>计算的偏移量 (以字节为单位) 不会使 `isize` 溢出。<br>
    ///
    /// * The offset being in bounds cannot rely on "wrapping around" the address space. <br>偏移量不能依赖 "wrapping around" 地址空间。<br> That is, the infinite-precision sum must fit in a `usize`. <br>也就是说，无限精度的总和必须符合 `usize`。<br>
    ///
    /// The compiler and standard library generally tries to ensure allocations never reach a size where an offset is a concern. <br>编译器和标准库通常会尝试确保分配永远不会达到需要考虑偏移量的大小。<br>
    /// For instance, `Vec` and `Box` ensure they never allocate more than `isize::MAX` bytes, so `vec.as_ptr().add(vec.len())` is always safe. <br>例如，`Vec` 和 `Box` 确保它们分配的字节数永远不会超过 `isize::MAX` 字节，因此 `vec.as_ptr().add(vec.len())` 始终是安全的。<br>
    ///
    /// Most platforms fundamentally can't even construct such an allocation. <br>从根本上说，大多数平台甚至都无法构造这样的分配。<br>
    /// For instance, no known 64-bit platform can ever serve a request for 2<sup>63</sup> bytes due to page-table limitations or splitting the address space. <br>例如，由于页表的限制或地址空间的分割，没有已知的 64 位平台可以满足 2 <sup>63</sup> 字节的请求。<br>
    /// However, some 32-bit and 16-bit platforms may successfully serve a request for more than `isize::MAX` bytes with things like Physical Address Extension. <br>但是，某些 32 位和 16 位平台可能通过物理地址扩展之类的东西成功地为超过 `isize::MAX` 字节的请求提供服务。<br>
    ///
    /// As such, memory acquired directly from allocators or memory mapped files *may* be too large to handle with this function. <br>因此，直接从分配器获取的内存或内存映射文件 *可能* 太大而无法使用此函数进行处理。<br>
    ///
    /// Consider using [`wrapping_add`] instead if these constraints are difficult to satisfy. <br>如果这些约束难以满足，请考虑使用 [`wrapping_add`]。<br>
    /// The only advantage of this method is that it enables more aggressive compiler optimizations. <br>此方法的唯一优点是，它可以实现更积极的编译器优化。<br>
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    /// [allocated object]: crate::ptr#allocated-object
    ///
    /// # Examples
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_stable(feature = "const_ptr_offset", since = "1.61.0")]
    #[inline(always)]
    #[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces <br>即使没有 panic，这也有助于 Miri 回溯<br>
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `offset`. <br>调用者必须遵守 `offset` 的安全保证。<br>
        unsafe { self.offset(count as isize) }
    }

    /// Calculates the offset from a pointer in bytes (convenience for `.byte_offset(count as isize)`). <br>以字节为单位计算指针的偏移量 (方便 `.byte_offset(count as isize)`)。<br>
    ///
    /// `count` is in units of bytes. <br>`count` 以字节为单位。<br>
    ///
    /// This is purely a convenience for casting to a `u8` pointer and using [add][pointer::add] on it. <br>这纯粹是为了方便转换为 `u8` 指针并在其上使用 [add][pointer::add]。<br>
    /// See that method for documentation and safety requirements. <br>有关文档和安全要求，请参见该方法。<br>
    ///
    /// For non-`Sized` pointees this operation changes only the data pointer, leaving the metadata untouched. <br>对于非 `Sized` 指针，此操作仅更改数据指针，而保留元数据不变。<br>
    ///
    ///
    #[must_use]
    #[inline(always)]
    #[unstable(feature = "pointer_byte_offsets", issue = "96283")]
    #[rustc_const_unstable(feature = "const_pointer_byte_offsets", issue = "96283")]
    #[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces <br>即使没有 panic，这也有助于 Miri 回溯<br>
    pub const unsafe fn byte_add(self, count: usize) -> Self {
        // SAFETY: the caller must uphold the safety contract for `add`. <br>调用者必须维护 `add` 的安全保证。<br>
        unsafe { self.cast::<u8>().add(count).with_metadata_of(self) }
    }

    /// Calculates the offset from a pointer (convenience for `.offset((count as isize).wrapping_neg())`). <br>计算与指针的偏移量 (`.offset((count as isize).wrapping_neg())` 的便利性)。<br>
    ///
    /// `count` is in units of T; <br>`count` 以 T 为单位；<br> e.g., a `count` of 3 represents a pointer offset of `3 * size_of::<T>()` bytes. <br>例如，`count` 为 3 表示 `3 * size_of::<T>()` 字节的指针偏移量。<br>
    ///
    /// # Safety
    ///
    /// If any of the following conditions are violated, the result is Undefined Behavior: <br>如果违反以下任一条件，则结果为未定义行为：<br>
    ///
    /// * Both the starting and resulting pointer must be either in bounds or one byte past the end of the same [allocated object]. <br>起始指针和结果指针都必须在边界内或在同一个 [分配对象][allocated object] 的末尾之后一个字节。<br>
    ///
    /// * The computed offset cannot exceed `isize::MAX` **bytes**. <br>计算的偏移量不能超过 `isize::MAX` 个 **字节**。<br>
    ///
    /// * The offset being in bounds cannot rely on "wrapping around" the address space. <br>偏移量不能依赖 "wrapping around" 地址空间。<br> That is, the infinite-precision sum must fit in a usize. <br>也就是说，无限精度的总和必须符合使用大小。<br>
    ///
    /// The compiler and standard library generally tries to ensure allocations never reach a size where an offset is a concern. <br>编译器和标准库通常会尝试确保分配永远不会达到需要考虑偏移量的大小。<br>
    /// For instance, `Vec` and `Box` ensure they never allocate more than `isize::MAX` bytes, so `vec.as_ptr().add(vec.len()).sub(vec.len())` is always safe. <br>例如，`Vec` 和 `Box` 确保它们分配的字节数永远不会超过 `isize::MAX` 字节，因此 `vec.as_ptr().add(vec.len()).sub(vec.len())` 始终是安全的。<br>
    ///
    /// Most platforms fundamentally can't even construct such an allocation. <br>从根本上说，大多数平台甚至都无法构造这样的分配。<br>
    /// For instance, no known 64-bit platform can ever serve a request for 2<sup>63</sup> bytes due to page-table limitations or splitting the address space. <br>例如，由于页表的限制或地址空间的分割，没有已知的 64 位平台可以满足 2 <sup>63</sup> 字节的请求。<br>
    /// However, some 32-bit and 16-bit platforms may successfully serve a request for more than `isize::MAX` bytes with things like Physical Address Extension. <br>但是，某些 32 位和 16 位平台可能通过物理地址扩展之类的东西成功地为超过 `isize::MAX` 字节的请求提供服务。<br>
    ///
    /// As such, memory acquired directly from allocators or memory mapped files *may* be too large to handle with this function. <br>因此，直接从分配器获取的内存或内存映射文件 *可能* 太大而无法使用此函数进行处理。<br>
    ///
    /// Consider using [`wrapping_sub`] instead if these constraints are difficult to satisfy. <br>如果这些约束难以满足，请考虑使用 [`wrapping_sub`]。<br>
    /// The only advantage of this method is that it enables more aggressive compiler optimizations. <br>此方法的唯一优点是，它可以实现更积极的编译器优化。<br>
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    /// [allocated object]: crate::ptr#allocated-object
    ///
    /// # Examples
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_stable(feature = "const_ptr_offset", since = "1.61.0")]
    #[inline(always)]
    #[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces <br>即使没有 panic，这也有助于 Miri 回溯<br>
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `offset`. <br>调用者必须遵守 `offset` 的安全保证。<br>
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Calculates the offset from a pointer in bytes (convenience for `.byte_offset((count as isize).wrapping_neg())`). <br>以字节为单位计算指针的偏移量 (方便 `.byte_offset((count as isize).wrapping_neg())`)。<br>
    ///
    ///
    /// `count` is in units of bytes. <br>`count` 以字节为单位。<br>
    ///
    /// This is purely a convenience for casting to a `u8` pointer and using [sub][pointer::sub] on it. <br>这纯粹是为了方便转换为 `u8` 指针并在其上使用 [sub][pointer::sub]。<br>
    /// See that method for documentation and safety requirements. <br>有关文档和安全要求，请参见该方法。<br>
    ///
    /// For non-`Sized` pointees this operation changes only the data pointer, leaving the metadata untouched. <br>对于非 `Sized` 指针，此操作仅更改数据指针，而保留元数据不变。<br>
    ///
    ///
    #[must_use]
    #[inline(always)]
    #[unstable(feature = "pointer_byte_offsets", issue = "96283")]
    #[rustc_const_unstable(feature = "const_pointer_byte_offsets", issue = "96283")]
    #[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces <br>即使没有 panic，这也有助于 Miri 回溯<br>
    pub const unsafe fn byte_sub(self, count: usize) -> Self {
        // SAFETY: the caller must uphold the safety contract for `sub`. <br>调用者必须维护 `sub` 的安全保证。<br>
        unsafe { self.cast::<u8>().sub(count).with_metadata_of(self) }
    }

    /// Calculates the offset from a pointer using wrapping arithmetic. <br>使用换行算法计算与指针的偏移量。<br>
    /// (convenience for `.wrapping_offset(count as isize)`) <br>(为 `.wrapping_offset(count as isize)` 带来的便利)<br>
    ///
    /// `count` is in units of T; <br>`count` 以 T 为单位；<br> e.g., a `count` of 3 represents a pointer offset of `3 * size_of::<T>()` bytes. <br>例如，`count` 为 3 表示 `3 * size_of::<T>()` 字节的指针偏移量。<br>
    ///
    /// # Safety
    ///
    /// This operation itself is always safe, but using the resulting pointer is not. <br>此操作本身始终是安全的，但使用结果指针则不安全。<br>
    ///
    /// The resulting pointer "remembers" the [allocated object] that `self` points to; <br>结果指针 "remembers" 是 `self` 指向的 [分配对象][allocated object]；<br> it must not be used to read or write other allocated objects. <br>它不得用于读取或写入其他分配的对象。<br>
    ///
    /// In other words, `let z = x.wrapping_add((y as usize) - (x as usize))` does *not* make `z` the same as `y` even if we assume `T` has size `1` and there is no overflow: `z` is still attached to the object `x` is attached to, and dereferencing it is Undefined Behavior unless `x` and `y` point into the same allocated object. <br>换句话说，即使我们假设 `T` 的大小为 `1` 并且没有溢出，`let z = x.wrapping_add((y as usize) - (x as usize))` 不会使 `z` 与 `y` 相同: `z` 仍附加到对象 `x` 所附加的对象，并且解引用它是 Undefined Behavior，除非 `x` 和 `y` 指向同一分配的对象。<br>
    ///
    /// Compared to [`add`], this method basically delays the requirement of staying within the same allocated object: [`add`] is immediate Undefined Behavior when crossing object boundaries; <br>与 [`add`] 相比，此方法从根本上延迟了留在同一分配对象内的需求: [`add`] 是跨越对象边界时的立即未定义行为；<br> `wrapping_add` produces a pointer but still leads to Undefined Behavior if a pointer is dereferenced when it is out-of-bounds of the object it is attached to. <br>`wrapping_add` 产生一个指针，但如果指针超出其附加对象的范围而被解引用，则仍会导致未定义行为。<br>
    /// [`add`] can be optimized better and is thus preferable in performance-sensitive code. <br>[`add`] 可以更好地优化，因此在性能敏感的代码中更可取。<br>
    ///
    /// The delayed check only considers the value of the pointer that was dereferenced, not the intermediate values used during the computation of the final result. <br>延迟检查仅考虑解引用的指针的值，而不考虑最终结果计算期间使用的中间值。<br>
    /// For example, `x.wrapping_add(o).wrapping_sub(o)` is always the same as `x`. <br>例如，`x.wrapping_add(o).wrapping_sub(o)` 始终与 `x` 相同。<br> In other words, leaving the allocated object and then re-entering it later is permitted. <br>换句话说，允许离开已分配的对象，然后在以后重新输入它。<br>
    ///
    /// [`add`]: #method.add
    /// [allocated object]: crate::ptr#allocated-object
    ///
    /// # Examples
    ///
    /// ```
    /// // Iterate using a raw pointer in increments of two elements <br>使用裸指针以两个元素为增量进行迭代<br>
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // This loop prints "1, 3, 5, " <br>此循环打印 "1, 3, 5, "<br>
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_stable(feature = "const_ptr_offset", since = "1.61.0")]
    #[inline(always)]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Calculates the offset from a pointer in bytes using wrapping arithmetic. <br>使用环绕算法计算与指针的偏移量 (以字节为单位)。<br>
    /// (convenience for `.wrapping_byte_offset(count as isize)`) <br>(便于 `.wrapping_byte_offset(计为 isize)`)<br>
    ///
    /// `count` is in units of bytes. <br>`count` 以字节为单位。<br>
    ///
    /// This is purely a convenience for casting to a `u8` pointer and using [wrapping_add][pointer::wrapping_add] on it. <br>这纯粹是为了方便转换为 `u8` 指针并在其上使用 [wrapping_add][pointer::wrapping_add]。<br>
    /// See that method for documentation. <br>请参见该方法以获取文档。<br>
    ///
    /// For non-`Sized` pointees this operation changes only the data pointer, leaving the metadata untouched. <br>对于非 `Sized` 指针，此操作仅更改数据指针，而保留元数据不变。<br>
    ///
    #[must_use]
    #[inline(always)]
    #[unstable(feature = "pointer_byte_offsets", issue = "96283")]
    #[rustc_const_unstable(feature = "const_pointer_byte_offsets", issue = "96283")]
    pub const fn wrapping_byte_add(self, count: usize) -> Self {
        self.cast::<u8>().wrapping_add(count).with_metadata_of(self)
    }

    /// Calculates the offset from a pointer using wrapping arithmetic. <br>使用换行算法计算与指针的偏移量。<br>
    /// (convenience for `.wrapping_offset((count as isize).wrapping_neg())`) <br>(为 `.wrapping_offset((count as isize).wrapping_neg())` 带来的便利)<br>
    ///
    /// `count` is in units of T; <br>`count` 以 T 为单位；<br> e.g., a `count` of 3 represents a pointer offset of `3 * size_of::<T>()` bytes. <br>例如，`count` 为 3 表示 `3 * size_of::<T>()` 字节的指针偏移量。<br>
    ///
    /// # Safety
    ///
    /// This operation itself is always safe, but using the resulting pointer is not. <br>此操作本身始终是安全的，但使用结果指针则不安全。<br>
    ///
    /// The resulting pointer "remembers" the [allocated object] that `self` points to; <br>结果指针 "remembers" 是 `self` 指向的 [分配对象][allocated object]；<br> it must not be used to read or write other allocated objects. <br>它不得用于读取或写入其他分配的对象。<br>
    ///
    /// In other words, `let z = x.wrapping_sub((x as usize) - (y as usize))` does *not* make `z` the same as `y` even if we assume `T` has size `1` and there is no overflow: `z` is still attached to the object `x` is attached to, and dereferencing it is Undefined Behavior unless `x` and `y` point into the same allocated object. <br>换句话说，即使我们假设 `T` 的大小为 `1` 并且没有溢出，`let z = x.wrapping_sub((x as usize) - (y as usize))` 不会使 `z` 与 `y` 相同: `z` 仍附加到对象 `x` 所附加的对象，并且解引用它是 Undefined Behavior，除非 `x` 和 `y` 指向同一分配的对象。<br>
    ///
    /// Compared to [`sub`], this method basically delays the requirement of staying within the same allocated object: [`sub`] is immediate Undefined Behavior when crossing object boundaries; <br>与 [`sub`] 相比，此方法从根本上延迟了留在同一分配对象内的需求: [`sub`] 是跨越对象边界时的立即未定义行为；<br> `wrapping_sub` produces a pointer but still leads to Undefined Behavior if a pointer is dereferenced when it is out-of-bounds of the object it is attached to. <br>`wrapping_sub` 产生一个指针，但如果指针超出其附加对象的范围而被解引用，则仍会导致未定义行为。<br>
    /// [`sub`] can be optimized better and is thus preferable in performance-sensitive code. <br>[`sub`] 可以更好地优化，因此在性能敏感的代码中更可取。<br>
    ///
    /// The delayed check only considers the value of the pointer that was dereferenced, not the intermediate values used during the computation of the final result. <br>延迟检查仅考虑解引用的指针的值，而不考虑最终结果计算期间使用的中间值。<br>
    /// For example, `x.wrapping_add(o).wrapping_sub(o)` is always the same as `x`. <br>例如，`x.wrapping_add(o).wrapping_sub(o)` 始终与 `x` 相同。<br> In other words, leaving the allocated object and then re-entering it later is permitted. <br>换句话说，允许离开已分配的对象，然后在以后重新输入它。<br>
    ///
    /// [`sub`]: #method.sub
    /// [allocated object]: crate::ptr#allocated-object
    ///
    /// # Examples
    ///
    /// ```
    /// // Iterate using a raw pointer in increments of two elements (backwards) <br>使用裸指针以两个元素 (backwards) 为增量进行迭代<br>
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // This loop prints "5, 3, 1, " <br>此循环打印 "5, 3, 1, "<br>
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_stable(feature = "const_ptr_offset", since = "1.61.0")]
    #[inline(always)]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Calculates the offset from a pointer in bytes using wrapping arithmetic. <br>使用环绕算法计算与指针的偏移量 (以字节为单位)。<br>
    /// (convenience for `.wrapping_offset((count as isize).wrapping_neg())`) <br>(为 `.wrapping_offset((count as isize).wrapping_neg())` 带来的便利)<br>
    ///
    /// `count` is in units of bytes. <br>`count` 以字节为单位。<br>
    ///
    /// This is purely a convenience for casting to a `u8` pointer and using [wrapping_sub][pointer::wrapping_sub] on it. <br>这纯粹是为了方便转换为 `u8` 指针并在其上使用 [wrapping_sub][pointer::wrapping_sub]。<br>
    /// See that method for documentation. <br>请参见该方法以获取文档。<br>
    ///
    /// For non-`Sized` pointees this operation changes only the data pointer, leaving the metadata untouched. <br>对于非 `Sized` 指针，此操作仅更改数据指针，而保留元数据不变。<br>
    ///
    #[must_use]
    #[inline(always)]
    #[unstable(feature = "pointer_byte_offsets", issue = "96283")]
    #[rustc_const_unstable(feature = "const_pointer_byte_offsets", issue = "96283")]
    pub const fn wrapping_byte_sub(self, count: usize) -> Self {
        self.cast::<u8>().wrapping_sub(count).with_metadata_of(self)
    }

    /// Reads the value from `self` without moving it. <br>从 `self` 读取值而不移动它。<br>
    /// This leaves the memory in `self` unchanged. <br>这将使 `self` 中的内存保持不变。<br>
    ///
    /// See [`ptr::read`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::read`]。<br>
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    #[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces <br>即使没有 panic，这也有助于 Miri 回溯<br>
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `read`. <br>调用者必须遵守 `read` 的安全保证。<br>
        unsafe { read(self) }
    }

    /// Performs a volatile read of the value from `self` without moving it. <br>对 `self` 的值进行易失性读取，而无需移动它。<br> This leaves the memory in `self` unchanged. <br>这将使 `self` 中的内存保持不变。<br>
    ///
    /// Volatile operations are intended to act on I/O memory, and are guaranteed to not be elided or reordered by the compiler across other volatile operations. <br>易失性操作旨在作用于 I/O 存储器，并保证编译器不会在其他易失性操作中对易失性操作进行清除或重新排序。<br>
    ///
    ///
    /// See [`ptr::read_volatile`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::read_volatile`]。<br>
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    #[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces <br>即使没有 panic，这也有助于 Miri 回溯<br>
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `read_volatile`. <br>调用者必须遵守 `read_volatile` 的安全保证。<br>
        unsafe { read_volatile(self) }
    }

    /// Reads the value from `self` without moving it. <br>从 `self` 读取值而不移动它。<br>
    /// This leaves the memory in `self` unchanged. <br>这将使 `self` 中的内存保持不变。<br>
    ///
    /// Unlike `read`, the pointer may be unaligned. <br>与 `read` 不同，指针可能未对齐。<br>
    ///
    /// See [`ptr::read_unaligned`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::read_unaligned`]。<br>
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    #[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces <br>即使没有 panic，这也有助于 Miri 回溯<br>
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `read_unaligned`. <br>调用者必须遵守 `read_unaligned` 的安全保证。<br>
        unsafe { read_unaligned(self) }
    }

    /// Copies `count * size_of<T>` bytes from `self` to `dest`. <br>将 `count * size_of<T>` 字节从 `self` 复制到 `dest`。<br>
    /// The source and destination may overlap. <br>源和目标可能会重叠。<br>
    ///
    /// NOTE: this has the *same* argument order as [`ptr::copy`]. <br>这与 [`ptr::copy`] 具有相同的参数顺序。<br>
    ///
    /// See [`ptr::copy`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::copy`]。<br>
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_stable(feature = "const_intrinsic_copy", since = "1.63.0")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    #[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces <br>即使没有 panic，这也有助于 Miri 回溯<br>
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `copy`. <br>调用者必须遵守 `copy` 的安全保证。<br>
        unsafe { copy(self, dest, count) }
    }

    /// Copies `count * size_of<T>` bytes from `self` to `dest`. <br>将 `count * size_of<T>` 字节从 `self` 复制到 `dest`。<br>
    /// The source and destination may *not* overlap. <br>源和目标可能 *不* 重叠。<br>
    ///
    /// NOTE: this has the *same* argument order as [`ptr::copy_nonoverlapping`]. <br>这与 [`ptr::copy_nonoverlapping`] 具有相同的参数顺序。<br>
    ///
    /// See [`ptr::copy_nonoverlapping`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::copy_nonoverlapping`]。<br>
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_stable(feature = "const_intrinsic_copy", since = "1.63.0")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    #[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces <br>即使没有 panic，这也有助于 Miri 回溯<br>
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `copy_nonoverlapping`. <br>调用者必须遵守 `copy_nonoverlapping` 的安全保证。<br>
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Computes the offset that needs to be applied to the pointer in order to make it aligned to `align`. <br>计算为使其与 `align` 对齐而需要应用到指针的偏移量。<br>
    ///
    /// If it is not possible to align the pointer, the implementation returns `usize::MAX`. <br>如果无法对齐指针，则实现将返回 `usize::MAX`。<br>
    /// It is permissible for the implementation to *always* return `usize::MAX`. <br>允许实现 *始终* 返回 `usize::MAX`。<br>
    /// Only your algorithm's performance can depend on getting a usable offset here, not its correctness. <br>只有算法的性能可以取决于此处是否可获得可用的偏移量，而不取决于其正确性。<br>
    ///
    /// The offset is expressed in number of `T` elements, and not bytes. <br>偏移量以 `T` 元素的数量表示，而不是以字节表示。<br> The value returned can be used with the `wrapping_add` method. <br>返回的值可以与 `wrapping_add` 方法一起使用。<br>
    ///
    /// There are no guarantees whatsoever that offsetting the pointer will not overflow or go beyond the allocation that the pointer points into. <br>不能保证偏移指针不会溢出或超出指针所指向的分配范围。<br>
    ///
    /// It is up to the caller to ensure that the returned offset is correct in all terms other than alignment. <br>调用者应确保返回的偏移量在对齐方式以外的所有方面都是正确的。<br>
    ///
    /// # Panics
    ///
    /// The function panics if `align` is not a power-of-two. <br>如果 `align` 不是 2 的幂，则函数 panics。<br>
    ///
    /// # Examples
    ///
    /// Accessing adjacent `u8` as `u16` <br>将相邻的 `u8` 作为 `u16` 进行访问<br>
    ///
    /// ```
    /// use std::mem::align_of;
    ///
    /// # unsafe {
    /// let x = [5_u8, 6, 7, 8, 9];
    /// let ptr = x.as_ptr();
    /// let offset = ptr.align_offset(align_of::<u16>());
    ///
    /// if offset < x.len() - 1 {
    ///     let u16_ptr = ptr.add(offset).cast::<u16>();
    ///     assert!(*u16_ptr == u16::from_ne_bytes([5, 6]) || *u16_ptr == u16::from_ne_bytes([6, 7]));
    /// } else {
    ///     // while the pointer can be aligned via `offset`, it would point outside the allocation <br>虽然指针可以通过 `offset` 对齐，但它会指向分配之外<br>
    /////
    /// }
    /// # }
    /// ```
    ///
    ///
    ///
    #[must_use]
    #[inline]
    #[stable(feature = "align_offset", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_align_offset", issue = "90962")]
    pub const fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }

        {
            // SAFETY: `align` has been checked to be a power of 2 above <br>`align` 已被检查为 2 以上的幂<br>
            unsafe { align_offset(self, align) }
        }
    }

    /// Returns whether the pointer is properly aligned for `T`. <br>返回指针是否为 `T` 正确对齐。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(pointer_is_aligned)]
    /// #![feature(pointer_byte_offsets)]
    ///
    /// // On some platforms, the alignment of i32 is less than <br>在某些平台上，i32 的对齐小于<br> 4.
    /// #[repr(align(4))]
    /// struct AlignedI32(i32);
    ///
    /// let data = AlignedI32(42);
    /// let ptr = &data as *const AlignedI32;
    ///
    /// assert!(ptr.is_aligned());
    /// assert!(!ptr.wrapping_byte_add(1).is_aligned());
    /// ```
    ///
    /// # At compiletime <br>在编译时<br>
    /// **Note: Alignment at compiletime is experimental and subject to change. <br>编译时的对齐是实验性的，可能会发生变化。<br> See the [tracking issue] for details. <br>有关详细信息，请参见 [tracking issue]。<br>**
    ///
    /// At compiletime, the compiler may not know where a value will end up in memory. <br>在编译时，编译器可能不知道值将在内存中的何处结束。<br>
    /// Calling this function on a pointer created from a reference at compiletime will only return `true` if the pointer is guaranteed to be aligned. <br>在编译时对从引用创建的指针调用此函数将仅在保证指针对齐的情况下返回 `true`。<br>
    /// This means that the pointer is never aligned if cast to a type with a stricter alignment than the reference's underlying allocation. <br>这意味着如果将指针转换为比引用的底层分配具有更严格对齐的类型，则指针永远不会对齐。<br>
    ///
    /// ```
    /// #![feature(pointer_is_aligned)]
    /// #![feature(const_pointer_is_aligned)]
    ///
    /// // On some platforms, the alignment of primitives is less than their size. <br>在某些平台上，图元的对齐方式小于它们的大小。<br>
    /// #[repr(align(4))]
    /// struct AlignedI32(i32);
    /// #[repr(align(8))]
    /// struct AlignedI64(i64);
    ///
    /// const _: () = {
    ///     let data = AlignedI32(42);
    ///     let ptr = &data as *const AlignedI32;
    ///     assert!(ptr.is_aligned());
    ///
    ///     // At runtime either `ptr1` or `ptr2` would be aligned, but at compiletime neither is aligned. <br>在运行时 `ptr1` 或 `ptr2` 将对齐，但在编译时两者都不对齐。<br>
    ///     let ptr1 = ptr.cast::<AlignedI64>();
    ///     let ptr2 = ptr.wrapping_add(1).cast::<AlignedI64>();
    ///     assert!(!ptr1.is_aligned());
    ///     assert!(!ptr2.is_aligned());
    /// };
    /// ```
    ///
    /// Due to this behavior, it is possible that a runtime pointer derived from a compiletime pointer is aligned, even if the compiletime pointer wasn't aligned. <br>由于此行为，即使编译时指针未对齐，派生自编译时指针的运行时指针也可能对齐。<br>
    ///
    ///
    /// ```
    /// #![feature(pointer_is_aligned)]
    /// #![feature(const_pointer_is_aligned)]
    ///
    /// // On some platforms, the alignment of primitives is less than their size. <br>在某些平台上，图元的对齐方式小于它们的大小。<br>
    /// #[repr(align(4))]
    /// struct AlignedI32(i32);
    /// #[repr(align(8))]
    /// struct AlignedI64(i64);
    ///
    /// // At compiletime, neither `COMPTIME_PTR` nor `COMPTIME_PTR + 1` is aligned. <br>在编译时，`COMPTIME_PTR` 和 `COMPTIME_PTR + 1` 都没有对齐。<br>
    /// const COMPTIME_PTR: *const AlignedI32 = &AlignedI32(42);
    /// const _: () = assert!(!COMPTIME_PTR.cast::<AlignedI64>().is_aligned());
    /// const _: () = assert!(!COMPTIME_PTR.wrapping_add(1).cast::<AlignedI64>().is_aligned());
    ///
    /// // At runtime, either `runtime_ptr` or `runtime_ptr + 1` is aligned. <br>在运行时，`runtime_ptr` 或 `runtime_ptr + 1` 对齐。<br>
    /// let runtime_ptr = COMPTIME_PTR;
    /// assert_ne!(
    ///     runtime_ptr.cast::<AlignedI64>().is_aligned(),
    ///     runtime_ptr.wrapping_add(1).cast::<AlignedI64>().is_aligned(),
    /// );
    /// ```
    ///
    /// If a pointer is created from a fixed address, this function behaves the same during runtime and compiletime. <br>如果指针是从固定地址创建的，则此函数在运行时和编译时的行为相同。<br>
    ///
    /// ```
    /// #![feature(pointer_is_aligned)]
    /// #![feature(const_pointer_is_aligned)]
    ///
    /// // On some platforms, the alignment of primitives is less than their size. <br>在某些平台上，图元的对齐方式小于它们的大小。<br>
    /// #[repr(align(4))]
    /// struct AlignedI32(i32);
    /// #[repr(align(8))]
    /// struct AlignedI64(i64);
    ///
    /// const _: () = {
    ///     let ptr = 40 as *const AlignedI32;
    ///     assert!(ptr.is_aligned());
    ///
    ///     // For pointers with a known address, runtime and compiletime behavior are identical. <br>对于具有已知地址的指针，运行时和编译时行为是相同的。<br>
    ///     let ptr1 = ptr.cast::<AlignedI64>();
    ///     let ptr2 = ptr.wrapping_add(1).cast::<AlignedI64>();
    ///     assert!(ptr1.is_aligned());
    ///     assert!(!ptr2.is_aligned());
    /// };
    /// ```
    ///
    /// [tracking issue]: https://github.com/rust-lang/rust/issues/104203
    ///
    ///
    ///
    ///
    #[must_use]
    #[inline]
    #[unstable(feature = "pointer_is_aligned", issue = "96284")]
    #[rustc_const_unstable(feature = "const_pointer_is_aligned", issue = "104203")]
    pub const fn is_aligned(self) -> bool
    where
        T: Sized,
    {
        self.is_aligned_to(mem::align_of::<T>())
    }

    /// Returns whether the pointer is aligned to `align`. <br>返回指针是否与 `align` 对齐。<br>
    ///
    /// For non-`Sized` pointees this operation considers only the data pointer, ignoring the metadata. <br>对于非 `Sized` 指针，此操作仅考虑数据指针，而忽略元数据。<br>
    ///
    /// # Panics
    ///
    /// The function panics if `align` is not a power-of-two (this includes 0). <br>如果 `align` 不是 2 的幂 (包括 0)，函数会出现 panic。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(pointer_is_aligned)]
    /// #![feature(pointer_byte_offsets)]
    ///
    /// // On some platforms, the alignment of i32 is less than <br>在某些平台上，i32 的对齐小于<br> 4.
    /// #[repr(align(4))]
    /// struct AlignedI32(i32);
    ///
    /// let data = AlignedI32(42);
    /// let ptr = &data as *const AlignedI32;
    ///
    /// assert!(ptr.is_aligned_to(1));
    /// assert!(ptr.is_aligned_to(2));
    /// assert!(ptr.is_aligned_to(4));
    ///
    /// assert!(ptr.wrapping_byte_add(2).is_aligned_to(2));
    /// assert!(!ptr.wrapping_byte_add(2).is_aligned_to(4));
    ///
    /// assert_ne!(ptr.is_aligned_to(8), ptr.wrapping_add(1).is_aligned_to(8));
    /// ```
    ///
    /// # At compiletime <br>在编译时<br>
    /// **Note: Alignment at compiletime is experimental and subject to change. <br>编译时的对齐是实验性的，可能会发生变化。<br> See the [tracking issue] for details. <br>有关详细信息，请参见 [tracking issue]。<br>**
    ///
    /// At compiletime, the compiler may not know where a value will end up in memory. <br>在编译时，编译器可能不知道值将在内存中的何处结束。<br>
    /// Calling this function on a pointer created from a reference at compiletime will only return `true` if the pointer is guaranteed to be aligned. <br>在编译时对从引用创建的指针调用此函数将仅在保证指针对齐的情况下返回 `true`。<br>
    /// This means that the pointer cannot be stricter aligned than the reference's underlying allocation. <br>这意味着指针不能比引用的底层分配更严格地对齐。<br>
    ///
    /// ```
    /// #![feature(pointer_is_aligned)]
    /// #![feature(const_pointer_is_aligned)]
    ///
    /// // On some platforms, the alignment of i32 is less than <br>在某些平台上，i32 的对齐小于<br> 4.
    /// #[repr(align(4))]
    /// struct AlignedI32(i32);
    ///
    /// const _: () = {
    ///     let data = AlignedI32(42);
    ///     let ptr = &data as *const AlignedI32;
    ///
    ///     assert!(ptr.is_aligned_to(1));
    ///     assert!(ptr.is_aligned_to(2));
    ///     assert!(ptr.is_aligned_to(4));
    ///
    ///     // At compiletime, we know for sure that the pointer isn't aligned to <br>在编译时，我们确定指针没有对齐到<br> 8.
    ///     assert!(!ptr.is_aligned_to(8));
    ///     assert!(!ptr.wrapping_add(1).is_aligned_to(8));
    /// };
    /// ```
    ///
    /// Due to this behavior, it is possible that a runtime pointer derived from a compiletime pointer is aligned, even if the compiletime pointer wasn't aligned. <br>由于此行为，即使编译时指针未对齐，派生自编译时指针的运行时指针也可能对齐。<br>
    ///
    ///
    /// ```
    /// #![feature(pointer_is_aligned)]
    /// #![feature(const_pointer_is_aligned)]
    ///
    /// // On some platforms, the alignment of i32 is less than <br>在某些平台上，i32 的对齐小于<br> 4.
    /// #[repr(align(4))]
    /// struct AlignedI32(i32);
    ///
    /// // At compiletime, neither `COMPTIME_PTR` nor `COMPTIME_PTR + 1` is aligned. <br>在编译时，`COMPTIME_PTR` 和 `COMPTIME_PTR + 1` 都没有对齐。<br>
    /// const COMPTIME_PTR: *const AlignedI32 = &AlignedI32(42);
    /// const _: () = assert!(!COMPTIME_PTR.is_aligned_to(8));
    /// const _: () = assert!(!COMPTIME_PTR.wrapping_add(1).is_aligned_to(8));
    ///
    /// // At runtime, either `runtime_ptr` or `runtime_ptr + 1` is aligned. <br>在运行时，`runtime_ptr` 或 `runtime_ptr + 1` 对齐。<br>
    /// let runtime_ptr = COMPTIME_PTR;
    /// assert_ne!(
    ///     runtime_ptr.is_aligned_to(8),
    ///     runtime_ptr.wrapping_add(1).is_aligned_to(8),
    /// );
    /// ```
    ///
    /// If a pointer is created from a fixed address, this function behaves the same during runtime and compiletime. <br>如果指针是从固定地址创建的，则此函数在运行时和编译时的行为相同。<br>
    ///
    /// ```
    /// #![feature(pointer_is_aligned)]
    /// #![feature(const_pointer_is_aligned)]
    ///
    /// const _: () = {
    ///     let ptr = 40 as *const u8;
    ///     assert!(ptr.is_aligned_to(1));
    ///     assert!(ptr.is_aligned_to(2));
    ///     assert!(ptr.is_aligned_to(4));
    ///     assert!(ptr.is_aligned_to(8));
    ///     assert!(!ptr.is_aligned_to(16));
    /// };
    /// ```
    ///
    /// [tracking issue]: https://github.com/rust-lang/rust/issues/104203
    ///
    ///
    ///
    ///
    #[must_use]
    #[inline]
    #[unstable(feature = "pointer_is_aligned", issue = "96284")]
    #[rustc_const_unstable(feature = "const_pointer_is_aligned", issue = "104203")]
    pub const fn is_aligned_to(self, align: usize) -> bool {
        if !align.is_power_of_two() {
            panic!("is_aligned_to: align is not a power-of-two");
        }

        #[inline]
        fn runtime_impl(ptr: *const (), align: usize) -> bool {
            ptr.addr() & (align - 1) == 0
        }

        #[inline]
        const fn const_impl(ptr: *const (), align: usize) -> bool {
            // We can't use the address of `self` in a `const fn`, so we use `align_offset` instead. <br>我们不能在 `const fn` 中使用 `self` 的地址，所以我们使用 `align_offset` 代替。<br>
            // The cast to `()` is used to <br>转换为 `()` 用于<br>
            //   1. deal with fat pointers; <br>处理胖指针;<br> and
            //   2. ensure that `align_offset` doesn't actually try to compute an offset. <br>确保 `align_offset` 实际上不会尝试计算偏移量。<br>
            ptr.align_offset(align) == 0
        }

        // SAFETY: The two versions are equivalent at runtime. <br>这两个版本在运行时是等效的。<br>
        unsafe { const_eval_select((self.cast::<()>(), align), const_impl, runtime_impl) }
    }
}

impl<T> *const [T] {
    /// Returns the length of a raw slice. <br>返回原始切片的长度。<br>
    ///
    /// The returned value is the number of **elements**, not the number of bytes. <br>返回的值是 **元素** 的数量，而不是字节数。<br>
    ///
    /// This function is safe, even when the raw slice cannot be cast to a slice reference because the pointer is null or unaligned. <br>即使原始切片由于指针为空或未对齐而无法转换为切片引用，此函数也是安全的。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        metadata(self)
    }

    /// Returns a raw pointer to the slice's buffer. <br>将裸指针返回到切片的缓冲区。<br>
    ///
    /// This is equivalent to casting `self` to `*const T`, but more type-safe. <br>这等效于将 `self` 强制转换为 `*const T`，但类型安全性更高。<br>
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), ptr::null());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Returns a raw pointer to an element or subslice, without doing bounds checking. <br>将裸指针返回到元素或子切片，而不进行边界检查。<br>
    ///
    /// Calling this method with an out-of-bounds index or when `self` is not dereferenceable is *[undefined behavior]* even if the resulting pointer is not used. <br>使用越界索引或当 `self` 不可解引用时调用此方法是 *[未定义行为][undefined behavior]*，即使未使用结果指针。<br>
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "const_slice_index", issue = "none")]
    #[inline]
    pub const unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: ~const SliceIndex<[T]>,
    {
        // SAFETY: the caller ensures that `self` is dereferenceable and `index` in-bounds. <br>调用者确保 `self` 是可解引用的，并且 `index` 在边界内。<br>
        unsafe { index.get_unchecked(self) }
    }

    /// Returns `None` if the pointer is null, or else returns a shared slice to the value wrapped in `Some`. <br>如果指针为空，则返回 `None`，否则返回共享切片到 `Some` 中包装的值。<br>
    /// In contrast to [`as_ref`], this does not require that the value has to be initialized. <br>与 [`as_ref`] 相比，这不需要将该值初始化。<br>
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// When calling this method, you have to ensure that *either* the pointer is null *or* all of the following is true: <br>调用此方法时，您必须确保要么指针是空的，要么以下所有内容都为 true：<br>
    ///
    /// * The pointer must be [valid] for reads for `ptr.len() * mem::size_of::<T>()` many bytes, and it must be properly aligned. <br>指针必须为 [有效][valid] 的，才能读取许多字节的 `ptr.len() * mem::size_of::<T>()`，并且必须正确对齐。<br> This means in particular: <br>这尤其意味着：<br>
    ///
    ///     * The entire memory range of this slice must be contained within a single [allocated object]! <br>整个内存范围必须包含在单个 [分配对象][allocated object] 内！<br>
    ///       Slices can never span across multiple allocated objects. <br>切片永远不能跨越多个分配的对象。<br>
    ///
    ///     * The pointer must be aligned even for zero-length slices. <br>即使对于零长度的切片，指针也必须对齐。<br>
    ///     One reason for this is that enum layout optimizations may rely on references (including slices of any length) being aligned and non-null to distinguish them from other data. <br>这样做的一个原因是，枚举布局优化可能依赖于对齐的引用 (包括任何长度的切片) 和非空值，以将它们与其他数据区分开。<br>
    ///
    ///     You can obtain a pointer that is usable as `data` for zero-length slices using [`NonNull::dangling()`]. <br>您可以使用 [`NonNull::dangling()`] 获得可用作零长度切片的 `data` 的指针。<br>
    ///
    /// * The total size `ptr.len() * mem::size_of::<T>()` of the slice must be no larger than `isize::MAX`. <br>切片的总大小 `ptr.len() * mem::size_of::<T>()` 不能大于 `isize::MAX`。<br>
    ///   See the safety documentation of [`pointer::offset`]. <br>请参见 [`pointer::offset`] 的安全文档。<br>
    ///
    /// * You must enforce Rust's aliasing rules, since the returned lifetime `'a` is arbitrarily chosen and does not necessarily reflect the actual lifetime of the data. <br>您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。<br>
    ///   In particular, while this reference exists, the memory the pointer points to must not get mutated (except inside `UnsafeCell`). <br>特别是，当这个引用存在时，指针指向的内存不能发生可变 (`UnsafeCell` 内部除外)。<br>
    ///
    /// This applies even if the result of this method is unused! <br>即使未使用此方法的结果也是如此！<br>
    ///
    /// See also [`slice::from_raw_parts`][]. <br>另请参见 [`slice::from_raw_parts`][]。<br>
    ///
    /// [valid]: crate::ptr#safety
    /// [allocated object]: crate::ptr#allocated-object
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    #[rustc_const_unstable(feature = "const_ptr_as_ref", issue = "91822")]
    pub const unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SAFETY: the caller must uphold the safety contract for `as_uninit_slice`. <br>调用者必须遵守 `as_uninit_slice` 的安全保证。<br>
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Equality for pointers <br>指针的相等<br>
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Comparison for pointers <br>指针的比较<br>
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}

use crate::iter::TrustedLen;

/// [`TrustedLen`] cannot have methods, so this allows augmenting it. <br>[`TrustedLen`] 不能有方法，所以这允许扩充它。<br>
///
/// It currently requires `TrustedLen` because it's unclear whether it's reasonably possible to depend on the `size_hint` of anything else. <br>它目前需要 `TrustedLen`，因为尚不清楚依赖 `size_hint` 是否合理。<br>
///
pub(crate) trait UncheckedIterator: TrustedLen {
    /// Gets the next item from a non-empty iterator. <br>从非空迭代器获取下一项。<br>
    ///
    /// Because there's always a value to return, that means it can return the `Item` type directly, without wrapping it in an `Option`. <br>因为总是有一个值要返回，这意味着它可以直接返回 `Item` 类型，而无需将其包装在 `Option` 中。<br>
    ///
    /// # Safety
    ///
    /// This can only be called if `size_hint().0 != 0`, guaranteeing that there's at least one item available. <br>这只能在 `size_hint().0 != 0` 时调用，保证至少有一项可用。<br>
    ///
    /// Otherwise (aka when `size_hint().1 == Some(0)`), this is UB. <br>否则 (也就是当 `size_hint ().1 == Some(0)`) 时，这是 UB。<br>
    ///
    /// # Note to Implementers <br>给实现者的注意事项<br>
    ///
    /// This has a default implementation using [`Option::unwrap_unchecked`]. <br>这有一个使用 [`Option::unwrap_unchecked`] 的默认实现。<br>
    /// That's probably sufficient if your `next` *always* returns `Some`, such as for infinite iterators. <br>如果您的 `next`*总是*返回 `Some`，这可能就足够了，例如对于无限迭代器。<br>
    /// In more complicated situations, however, sometimes there can still be `insertvalue`/`assume`/`extractvalue` instructions remaining in the IR from the `Option` handling, at which point you might want to implement this manually instead. <br>然而，在更复杂的情况下，有时 `Option` 处理中的 IR 中仍会残留 `insertvalue`/`assume`/`extractvalue` 指令，此时您可能希望手动实现它。<br>
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "trusted_len_next_unchecked", issue = "37572")]
    #[inline]
    unsafe fn next_unchecked(&mut self) -> Self::Item {
        let opt = self.next();
        // SAFETY: The caller promised that we're not empty, and `Self: TrustedLen` so we can actually trust the `size_hint`. <br>调用者承诺我们不是空的，`Self: TrustedLen` 所以我们实际上可以信任 `size_hint`。<br>
        //
        unsafe { opt.unwrap_unchecked() }
    }
}

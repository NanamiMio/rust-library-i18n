Equivalent to C's `unsigned short` type. <br>等效于 C 的 `unsigned short` 类型。<br>

This type will almost always be [`u16`], but may differ on some esoteric systems. <br>这种类型几乎总是 [`u16`]，但在某些深奥的系统上可能有所不同。<br> The C standard technically only requires that this type be an unsigned integer with the same size as a [`short`]. <br>C 标准从技术上仅要求此类型是与 [`short`] 大小相同的无符号整数。<br>

[`short`]: c_short

Equivalent to C's `unsigned int` type. <br>等效于 C 的 `unsigned int` 类型。<br>

This type will almost always be [`u32`], but may differ on some esoteric systems. <br>这种类型几乎总是 [`u32`]，但在某些深奥的系统上可能有所不同。<br> The C standard technically only requires that this type be an unsigned integer with the same size as an [`int`]; <br>从技术上讲，C 标准仅要求此类型是与 [`int`] 大小相同的无符号整数。<br> some systems define it as a [`u16`], for example. <br>例如，某些系统将其定义为 [`u16`]。<br>

[`int`]: c_int

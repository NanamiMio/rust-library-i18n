Equivalent to C's `unsigned long` type. <br>等效于 C 的 `unsigned long` 类型。<br>

This type will always be [`u32`] or [`u64`]. <br>此类型将始终为 [`u32`] 或 [`u64`]。<br> Most notably, many Linux-based systems assume an `u64`, but Windows assumes `u32`. <br>最值得注意的是，许多基于 Linux 的系统都使用 `u64`，但 Windows 则使用 `u32`。<br> The C standard technically only requires that this type be an unsigned integer with the size of a [`long`], although in practice, no system would have a `ulong` that is neither a `u32` nor `u64`. <br>C 标准从技术上仅要求此类型是 [`long`] 大小的无符号整数，尽管在实践中，没有系统会使用既不是 `u32` 也不是 `u64` 的 `ulong`。<br>

[`long`]: c_long

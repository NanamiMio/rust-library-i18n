Equivalent to C's `unsigned long long` type. <br>等效于 C 的 `unsigned long long` 类型。<br>

This type will almost always be [`u64`], but may differ on some systems. <br>此类型几乎总是 [`u64`]，但在某些系统上可能有所不同。<br> The C standard technically only requires that this type be an unsigned integer with the size of a [`long long`], although in practice, no system would have a `long long` that is not a `u64`, as most systems do not have a standardised [`u128`] type. <br>C 标准从技术上仅要求此类型是 [`long long`] 大小的无符号整数，尽管实际上，没有系统会具有不是 `u64` 的 `long long`，因为大多数系统都没有标准化的 [`u128`] 类型。<br>

[`long long`]: c_longlong

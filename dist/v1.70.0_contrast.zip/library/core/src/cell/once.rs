use crate::cell::UnsafeCell;
use crate::fmt;
use crate::mem;

/// A cell which can be written to only once. <br>一个 cell 只能写入一次。<br>
///
/// This allows obtaining a shared `&T` reference to its inner value without copying or replacing it (unlike [`Cell`]), and without runtime borrow checks (unlike [`RefCell`]). <br>这允许在不复制或替换它的情况下获取共享的 `&T` 引用其内部值 (与 [`Cell`] 不同)，并且无需运行时引用检查 (与 [`RefCell`] 不同)。<br>
///
/// However, only immutable references can be obtained unless one has a mutable reference to the cell itself. <br>但是，除非对 cell 本身具有可变引用，否则只能获得不可更改引用。<br>
///
/// For a thread-safe version of this struct, see [`std::sync::OnceLock`]. <br>有关此结构体的线程安全版本，请参见 [`std::sync::OnceLock`]。<br>
///
/// [`RefCell`]: crate::cell::RefCell
/// [`Cell`]: crate::cell::Cell
/// [`std::sync::OnceLock`]: ../../std/sync/struct.OnceLock.html
///
/// # Examples
///
/// ```
/// use std::cell::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
///
#[stable(feature = "once_cell", since = "1.70.0")]
pub struct OnceCell<T> {
    // Invariant: written to at most once. <br>不变量：最多写入一次。<br>
    inner: UnsafeCell<Option<T>>,
}

impl<T> OnceCell<T> {
    /// Creates a new empty cell. <br>创建一个新的空 cell。<br>
    #[inline]
    #[must_use]
    #[stable(feature = "once_cell", since = "1.70.0")]
    #[rustc_const_stable(feature = "once_cell", since = "1.70.0")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Gets the reference to the underlying value. <br>获取对底层值的引用。<br>
    ///
    /// Returns `None` if the cell is empty. <br>如果 cell 为空，则返回 `None`。<br>
    #[inline]
    #[stable(feature = "once_cell", since = "1.70.0")]
    pub fn get(&self) -> Option<&T> {
        // SAFETY: Safe due to `inner`'s invariant <br>由于 `inner` 的不变性而安全<br>
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Gets the mutable reference to the underlying value. <br>获取对底层值的可变引用。<br>
    ///
    /// Returns `None` if the cell is empty. <br>如果 cell 为空，则返回 `None`。<br>
    #[inline]
    #[stable(feature = "once_cell", since = "1.70.0")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        self.inner.get_mut().as_mut()
    }

    /// Sets the contents of the cell to `value`. <br>将 cell 的内容设置为 `value`。<br>
    ///
    /// # Errors
    ///
    /// This method returns `Ok(())` if the cell was empty and `Err(value)` if it was full. <br>如果 cell 为空，则此方法返回 `Ok(())`; 如果 cell 已满，则返回 `Err(value)`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[inline]
    #[stable(feature = "once_cell", since = "1.70.0")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // SAFETY: Safe because we cannot have overlapping mutable borrows <br>很安全，因为我们不能有重叠的可变借用<br>
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // SAFETY: This is the only place where we set the slot, no races due to reentrancy/concurrency are possible, and we've checked that slot is currently `None`, so this write maintains the `inner`'s invariant. <br>这是我们设置插槽的唯一地方，由于 reentrancy/concurrency 不可能发生竞争，并且我们检查了插槽当前是否为 `None`，因此此写入维护了 `inner` 的不变性。<br>
        //
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Gets the contents of the cell, initializing it with `f` if the cell was empty. <br>获取 cell 的内容，如果 cell 为空，则使用 `f` 对其进行初始化。<br>
    ///
    /// # Panics
    ///
    /// If `f` panics, the panic is propagated to the caller, and the cell remains uninitialized. <br>如果 `f` panics，则 panic 会传播给调用者，并且 cell 仍保持未初始化状态。<br>
    ///
    ///
    /// It is an error to reentrantly initialize the cell from `f`. <br>重新从 `f` 初始化 cell 是错误的。<br> Doing so results in a panic. <br>这样做会导致 panic。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "once_cell", since = "1.70.0")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Gets the contents of the cell, initializing it with `f` if the cell was empty. <br>获取 cell 的内容，如果 cell 为空，则使用 `f` 对其进行初始化。<br>
    /// If the cell was empty and `f` failed, an error is returned. <br>如果 cell 为空并且 `f` 失败，则返回错误。<br>
    ///
    /// # Panics
    ///
    /// If `f` panics, the panic is propagated to the caller, and the cell remains uninitialized. <br>如果 `f` panics，则 panic 会传播给调用者，并且 cell 仍保持未初始化状态。<br>
    ///
    ///
    /// It is an error to reentrantly initialize the cell from `f`. <br>重新从 `f` 初始化 cell 是错误的。<br> Doing so results in a panic. <br>这样做会导致 panic。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell_try)]
    ///
    /// use std::cell::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell_try", issue = "109737")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        /// Avoid inlining the initialization closure into the common path that fetches the already initialized value <br>避免将初始化闭包内联到获取已初始化值的公共路径中<br>
        ///
        #[cold]
        fn outlined_call<F, T, E>(f: F) -> Result<T, E>
        where
            F: FnOnce() -> Result<T, E>,
        {
            f()
        }
        let val = outlined_call(f)?;
        // Note that *some* forms of reentrant initialization might lead to UB (see `reentrant_init` test). <br>请注意，某些形式的可重入初始化可能会导致 UB (请参见 `reentrant_init` 测试)。<br>
        // I believe that just removing this `assert`, while keeping `set/get` would be sound, but it seems better to panic, rather than to silently use an old value. <br>我相信，仅删除此 `assert`，同时保留 `set/get` 听起来是不错的选择，但对于 panic 似乎更好，而不是默默地使用旧值。<br>
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Consumes the cell, returning the wrapped value. <br>消费 cell，返回包装后的值。<br>
    ///
    /// Returns `None` if the cell was empty. <br>如果 cell 为空，则返回 `None`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[inline]
    #[stable(feature = "once_cell", since = "1.70.0")]
    pub fn into_inner(self) -> Option<T> {
        // Because `into_inner` takes `self` by value, the compiler statically verifies that it is not currently borrowed. <br>因为 `into_inner` 按值取 `self`，所以编译器将静态验证它当前是否未被借用。<br>
        // So it is safe to move out `Option<T>`. <br>因此，移动 `Option<T>` 是安全的。<br>
        self.inner.into_inner()
    }

    /// Takes the value out of this `OnceCell`, moving it back to an uninitialized state. <br>从 `OnceCell` 中取出值，将其移回未初始化状态。<br>
    ///
    /// Has no effect and returns `None` if the `OnceCell` hasn't been initialized. <br>无效，如果尚未初始化 `OnceCell`，则返回 `None`。<br>
    ///
    /// Safety is guaranteed by requiring a mutable reference. <br>通过要求可变引用来保证安全。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[inline]
    #[stable(feature = "once_cell", since = "1.70.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

#[stable(feature = "once_cell", since = "1.70.0")]
impl<T> Default for OnceCell<T> {
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

#[stable(feature = "once_cell", since = "1.70.0")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[stable(feature = "once_cell", since = "1.70.0")]
impl<T: Clone> Clone for OnceCell<T> {
    #[inline]
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[stable(feature = "once_cell", since = "1.70.0")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "once_cell", since = "1.70.0")]
impl<T: Eq> Eq for OnceCell<T> {}

#[stable(feature = "once_cell", since = "1.70.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T> const From<T> for OnceCell<T> {
    /// Creates a new `OnceCell<T>` which already contains the given `value`. <br>创建一个已经包含给定 `value` 的新 `OnceCell<T>`。<br>
    #[inline]
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

// Just like for `Cell<T>` this isn't needed, but results in nicer error messages. <br>就像 `Cell<T>` 一样，这不是必需的，但会产生更好的错误消息。<br>
#[stable(feature = "once_cell", since = "1.70.0")]
impl<T> !Sync for OnceCell<T> {}

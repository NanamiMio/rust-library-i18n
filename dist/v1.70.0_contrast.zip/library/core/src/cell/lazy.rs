use crate::ops::Deref;
use crate::{fmt, mem};

use super::UnsafeCell;

enum State<T, F> {
    Uninit(F),
    Init(T),
    Poisoned,
}

/// A value which is initialized on the first access. <br>在首次访问时初始化的值。<br>
///
/// For a thread-safe version of this struct, see [`std::sync::LazyLock`]. <br>有关此结构体的线程安全版本，请参见 [`std::sync::LazyLock`]。<br>
///
/// [`std::sync::LazyLock`]: ../../std/sync/struct.LazyLock.html
///
/// # Examples
///
/// ```
/// #![feature(lazy_cell)]
///
/// use std::cell::LazyCell;
///
/// let lazy: LazyCell<i32> = LazyCell::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   ready initializing <br>准备初始化<br>
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "lazy_cell", issue = "109736")]
pub struct LazyCell<T, F = fn() -> T> {
    state: UnsafeCell<State<T, F>>,
}

impl<T, F: FnOnce() -> T> LazyCell<T, F> {
    /// Creates a new lazy value with the given initializing function. <br>使用给定的初始化函数创建一个新的惰性值。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(lazy_cell)]
    ///
    /// use std::cell::LazyCell;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = LazyCell::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// ```
    #[inline]
    #[unstable(feature = "lazy_cell", issue = "109736")]
    pub const fn new(f: F) -> LazyCell<T, F> {
        LazyCell { state: UnsafeCell::new(State::Uninit(f)) }
    }

    /// Forces the evaluation of this lazy value and returns a reference to the result. <br>强制对此延迟值求值，并向结果返回引用。<br>
    ///
    ///
    /// This is equivalent to the `Deref` impl, but is explicit. <br>这等效于 `Deref` impl，但是是显式的。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(lazy_cell)]
    ///
    /// use std::cell::LazyCell;
    ///
    /// let lazy = LazyCell::new(|| 92);
    ///
    /// assert_eq!(LazyCell::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[inline]
    #[unstable(feature = "lazy_cell", issue = "109736")]
    pub fn force(this: &LazyCell<T, F>) -> &T {
        // SAFETY:
        // This invalidates any mutable references to the data. <br>这会使对数据的任何可变引用无效。<br>
        // The resulting reference lives either until the end of the borrow of `this` (in the initialized case) or is invalidated in `really_init` (in the uninitialized case; `really_init` will create and return a fresh reference). <br>生成的引用要么一直存在到 `this` 的引用结束 (在初始化的情况下)，要么在 `really_init` 中失效 (在未初始化的情况下; `really_init` 将创建并返回一个新的引用)。<br>
        //
        //
        let state = unsafe { &*this.state.get() };
        match state {
            State::Init(data) => data,
            // SAFETY: The state is uninitialized. <br>状态未初始化。<br>
            State::Uninit(_) => unsafe { LazyCell::really_init(this) },
            State::Poisoned => panic!("LazyCell has previously been poisoned"),
        }
    }

    /// # Safety
    /// May only be called when the state is `Uninit`. <br>只能在状态为 `Uninit` 时调用。<br>
    #[cold]
    unsafe fn really_init(this: &LazyCell<T, F>) -> &T {
        // SAFETY:
        // This function is only called when the state is uninitialized, so no references to `state` can exist except for the reference in `force`, which is invalidated here and not accessed again. <br>该函数只有在状态未初始化时才会被调用，所以对 `state` 的引用不能存在，除了 `force` 中的引用，在这里失效，不再访问。<br>
        //
        //
        let state = unsafe { &mut *this.state.get() };
        // Temporarily mark the state as poisoned. <br>暂时将状态标记为中毒。<br>
        // This prevents reentrant accesses and correctly poisons the cell if the closure panicked. <br>这可以防止重入访问并在封包 panic 时正确地使 cell 中毒。<br>
        let State::Uninit(f) = mem::replace(state, State::Poisoned) else { unreachable!() };

        let data = f();

        // SAFETY:
        // If the closure accessed the cell through something like a reentrant mutex, but caught the panic resulting from the state being poisoned, the mutable borrow for `state` will be invalidated, so we need to go through the `UnsafeCell` pointer here. <br>如果关闭包通过重入互锁之类的方式访问了 cell，但是捕获了状态中毒导致的 panic，那么 `state` 的可变借用就会失效，所以我们需要在这里通过 `UnsafeCell` 指针。<br>
        // The state can only be poisoned at this point, so using `write` to skip the destructor of `State` should help the optimizer. <br>状态只能在此时中毒，所以使用 `write` 跳过 `State` 的析构函数应该有助于优化器。<br>
        //
        //
        //
        //
        unsafe { this.state.get().write(State::Init(data)) };

        // SAFETY:
        // The previous references were invalidated by the `write` call above, so do a new shared borrow of the state instead. <br>之前的引用被上面的 `write` 调用失效了，所以做一个新的状态共享引用代替。<br>
        //
        let state = unsafe { &*this.state.get() };
        let State::Init(data) = state else { unreachable!() };
        data
    }
}

impl<T, F> LazyCell<T, F> {
    #[inline]
    fn get(&self) -> Option<&T> {
        // SAFETY:
        // This is sound for the same reason as in `force`: once the state is initialized, it will not be mutably accessed again, so this reference will stay valid for the duration of the borrow to `self`. <br>这与 `force` 中的原因相同: 一旦状态被初始化，它就不会再次被可变地访问，所以这个引用将在对 `self` 的引用期间保持有效。<br>
        //
        //
        let state = unsafe { &*self.state.get() };
        match state {
            State::Init(data) => Some(data),
            _ => None,
        }
    }
}

#[unstable(feature = "lazy_cell", issue = "109736")]
impl<T, F: FnOnce() -> T> Deref for LazyCell<T, F> {
    type Target = T;
    #[inline]
    fn deref(&self) -> &T {
        LazyCell::force(self)
    }
}

#[unstable(feature = "lazy_cell", issue = "109736")]
impl<T: Default> Default for LazyCell<T> {
    /// Creates a new lazy value using `Default` as the initializing function. <br>使用 `Default` 作为初始化函数创建一个新的惰性值。<br>
    #[inline]
    fn default() -> LazyCell<T> {
        LazyCell::new(T::default)
    }
}

#[unstable(feature = "lazy_cell", issue = "109736")]
impl<T: fmt::Debug, F> fmt::Debug for LazyCell<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_tuple("LazyCell");
        match self.get() {
            Some(data) => d.field(data),
            None => d.field(&format_args!("<uninit>")),
        };
        d.finish()
    }
}

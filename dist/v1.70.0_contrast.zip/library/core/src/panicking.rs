//! Panic support for core <br>核心上的 panic 支持<br>
//!
//! The core library cannot define panicking, but it does *declare* panicking. <br>核心库无法定义 panic，但可以声明 panic。<br>
//! This means that the functions inside of core are allowed to panic, but to be useful an upstream crate must define panicking for core to use. <br>这意味着允许内核中的函数 panic，但要有用，上游 crate 必须定义内核使用的 panicing。<br>
//! The current interface for panicking is: <br>当前的 panic 接口是：<br>
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! This definition allows for panicking with any general message, but it does not allow for failing with a `Box<Any>` value. <br>此定义允许对任何常规消息进行 panic，但不允许 `Box<Any>` 值失败。<br>
//! (`PanicInfo` just contains a `&(dyn Any + Send)`, for which we fill in a dummy value in `PanicInfo::internal_constructor`.) The reason for this is that core is not allowed to allocate. <br>(`PanicInfo` 只包含一个 `&(dyn Any + Send)`，为此我们在 PanicInfo::internal_constructor 中为其填充了一个虚拟值。) 这样做的原因是核心不允许分配。<br>
//!
//!
//! This module contains a few other panicking functions, but these are just the necessary lang items for the compiler. <br>该模块还包含其他一些紧急函数，但这只是编译器必需的 lang 项。<br> All panics are funneled through this one function. <br>所有 panics 都通过此函数进行了分配。<br>
//! The actual symbol is declared through the `#[panic_handler]` attribute. <br>实际符号通过 `#[panic_handler]` 属性声明。<br>
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

#[cfg(feature = "panic_immediate_abort")]
const _: () = assert!(cfg!(panic = "abort"), "panic_immediate_abort requires -C panic=abort");

// First we define the two main entry points that all panics go through. <br>首先，我们定义所有 panic 都会经历的两个主要入口点。<br>
// In the end both are just convenience wrappers around `panic_impl`. <br>最后，两者都只是 `panic_impl` 的便利包装。<br>

/// The entry point for panicking with a formatted message. <br>带有格式化消息的 panic 的入口点。<br>
///
/// This is designed to reduce the amount of code required at the call site as much as possible (so that `panic!()` has as low an impact on (e.g.) the inlining of other functions as possible), by moving the actual formatting into this shared place. <br>通过将实际格式移到该共享位置，可以最大程度地减少调用站点上所需的代码量 (以使 `panic!()` 对 (e.g.) 内联其他函数的影响尽可能小)。<br>
///
///
///
// If panic_immediate_abort, inline the abort call, otherwise avoid inlining because of it is cold path. <br>如果使用 panic_immediate_abort，则内联中止调用，否则请避免内联，因为它是冷路径。<br>
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never), cold)]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
#[lang = "panic_fmt"] // needed for const-evaluated panics <br>常量评估的 panics 所需<br>
#[rustc_do_not_const_check] // hooked by const-eval <br>被 const-eval 钩住了<br>
#[rustc_const_unstable(feature = "core_panic", issue = "none")]
pub const fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // NOTE This function never crosses the FFI boundary; <br>这个函数永远不会越过 FFI 边界。<br> it's a Rust-to-Rust call that gets resolved to the `#[panic_handler]` function. <br>这是 Rust 到 Rust 调用，已解析为 `#[panic_handler]` 函数。<br>
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller(), true);

    // SAFETY: `panic_impl` is defined in safe Rust code and thus is safe to call. <br>`panic_impl` 在安全的 Rust 代码中定义，因此可以安全调用。<br>
    unsafe { panic_impl(&pi) }
}

/// Like `panic_fmt`, but for non-unwinding panics. <br>像 `panic_fmt`，但用于非展开 panic。<br>
///
/// Has to be a separate function so that it can carry the `rustc_nounwind` attribute. <br>必须是一个单独的函数，以便它可以携带 `rustc_nounwind` 属性。<br>
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never), cold)]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
// This attribute has the key side-effect that if the panic handler ignores `can_unwind` and unwinds anyway, we will hit the "unwinding out of nounwind function" guard, which causes a "panic in a function that cannot unwind". <br>这个属性有一个关键的副作用，如果 panic 处理程序忽略 `can_unwind` 并无论如何展开，我们将攻击 "unwinding out of nounwind function" 守卫，这会导致 "panic in a function that cannot unwind"。<br>
//
//
#[rustc_nounwind]
pub fn panic_nounwind_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // NOTE This function never crosses the FFI boundary; <br>这个函数永远不会越过 FFI 边界。<br> it's a Rust-to-Rust call that gets resolved to the `#[panic_handler]` function. <br>这是 Rust 到 Rust 调用，已解析为 `#[panic_handler]` 函数。<br>
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    // PanicInfo with the `can_unwind` flag set to false forces an abort. <br>将 `can_unwind` 标志设置为 false 的 PanicInfo 会强制中止。<br>
    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller(), false);

    // SAFETY: `panic_impl` is defined in safe Rust code and thus is safe to call. <br>`panic_impl` 在安全的 Rust 代码中定义，因此可以安全调用。<br>
    unsafe { panic_impl(&pi) }
}

// Next we define a bunch of higher-level wrappers that all bottom out in the two core functions above. <br>接下来我们在上面的两个核心函数中定义了一堆更高级别的包装器。<br>
//

/// The underlying implementation of core's `panic!` macro when no formatting is used. <br>不使用格式化时核心的 `panic!` 宏的底层实现。<br>
// never inline unless panic_immediate_abort to avoid code bloat at the call sites as much as possible <br>从不内联，除非 panic_immediate_abort 尽可能避免代码在调用站点上膨胀<br>
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never), cold)]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
#[rustc_const_unstable(feature = "core_panic", issue = "none")]
#[lang = "panic"] // needed by codegen for panic on overflow and other `Assert` MIR terminators <br>溢出和其他 `Assert` MIR 终结器时 panic 的代码生成所需的<br>
pub const fn panic(expr: &'static str) -> ! {
    // Use Arguments::new_v1 instead of format_args!("{expr}") to potentially reduce size overhead. <br>使用 Arguments::new_v1 而不是 format_args!("{expr}") 可能会减少大小开销。<br>
    // The format_args!  macro uses str's Display trait to write expr, which calls Formatter::pad, which must accommodate string truncation and padding (even though none is used here). <br>宏使用 str 的 Display trait 来编写 expr，它调用 Formatter::pad，它必须适应字符串截断和填充 (尽管这里没有使用任何内容)。<br>
    //
    // Using Arguments::new_v1 may allow the compiler to omit Formatter::pad from the output binary, saving up to a few kilobytes. <br>使用 Arguments::new_v1 可使编译器从输出二进制文件中省略 Formatter::pad，从而节省多达几千字节的空间。<br>
    //
    //
    panic_fmt(fmt::Arguments::new_const(&[expr]));
}

/// Like `panic`, but without unwinding and track_caller to reduce the impact on codesize. <br>像 `panic`，但没有展开和 track_caller 以减少对代码大小的影响。<br>
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never), cold)]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[lang = "panic_nounwind"] // needed by codegen for non-unwinding panics <br>codegen 需要用于非展开 panic<br>
#[rustc_nounwind]
pub fn panic_nounwind(expr: &'static str) -> ! {
    panic_nounwind_fmt(fmt::Arguments::new_const(&[expr]));
}

#[inline]
#[track_caller]
#[rustc_diagnostic_item = "panic_str"]
#[rustc_const_unstable(feature = "core_panic", issue = "none")]
pub const fn panic_str(expr: &str) -> ! {
    panic_display(&expr);
}

#[inline]
#[track_caller]
#[rustc_diagnostic_item = "unreachable_display"] // needed for `non-fmt-panics` lint <br>`non-fmt-panics` lint 需要<br>
pub fn unreachable_display<T: fmt::Display>(x: &T) -> ! {
    panic_fmt(format_args!("internal error: entered unreachable code: {}", *x));
}

#[inline]
#[track_caller]
#[lang = "panic_display"] // needed for const-evaluated panics <br>常量评估的 panics 所需<br>
#[rustc_do_not_const_check] // hooked by const-eval <br>被 const-eval 钩住了<br>
#[rustc_const_unstable(feature = "core_panic", issue = "none")]
pub const fn panic_display<T: fmt::Display>(x: &T) -> ! {
    panic_fmt(format_args!("{}", *x));
}

#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never), cold)]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
#[lang = "panic_bounds_check"] // needed by codegen for panic on OOB array/slice access <br>OOB array/slice 访问上 panic 的代码生成所需的<br>
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {len} but the index is {index}")
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[cfg_attr(not(bootstrap), lang = "panic_misaligned_pointer_dereference")] // needed by codegen for panic on misaligned pointer deref <br>codegen 需要对未对齐的指针 deref 进行 panic<br>
fn panic_misaligned_pointer_dereference(required: usize, found: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!(
        "misaligned pointer dereference: address must be a multiple of {required:#x} but is {found:#x}"
    )
}

/// Panic because we cannot unwind out of a function. <br>panic 是因为我们无法从函数中解脱出来。<br>
///
/// This function is called directly by the codegen backend, and must not have any extra arguments (including those synthesized by track_caller). <br>这个函数由 codegen 后端直接调用，并且不能有任何额外的参数 (包括那些由 track_caller 合成的参数)。<br>
///
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never), cold)]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[lang = "panic_cannot_unwind"] // needed by codegen for panic in nounwind function <br>odegen 需要在 nounwind 函数中出现 panic<br>
#[rustc_nounwind]
fn panic_cannot_unwind() -> ! {
    panic_nounwind("panic in a function that cannot unwind")
}

/// This function is used instead of panic_fmt in const eval. <br>在 const eval 中使用此函数代替 panic_fmt。<br>
#[lang = "const_panic_fmt"]
#[rustc_const_unstable(feature = "core_panic", issue = "none")]
pub const fn const_panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if let Some(msg) = fmt.as_str() {
        panic_str(msg);
    } else {
        // SAFETY: This is only evaluated at compile time, which reliably handles this UB (in case this branch turns out to be reachable somehow). <br>这仅在编译时评估，它可靠地处理此 UB (以防此分支以某种方式可达)。<br>
        //
        //
        unsafe { crate::hint::unreachable_unchecked() };
    }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
    Match,
}

/// Internal function for `assert_eq!` and `assert_ne!` macros <br>`assert_eq!` 和 `assert_ne!` 宏的内联函数<br>
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never), cold)]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    assert_failed_inner(kind, &left, &right, args)
}

/// Internal function for `assert_match!` <br>`assert_match!` 的内联函数<br>
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never), cold)]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
#[doc(hidden)]
pub fn assert_matches_failed<T: fmt::Debug + ?Sized>(
    left: &T,
    right: &str,
    args: Option<fmt::Arguments<'_>>,
) -> ! {
    // The pattern is a string so it can be displayed directly. <br>该模式是一个字符串，因此可以直接显示。<br>
    struct Pattern<'a>(&'a str);
    impl fmt::Debug for Pattern<'_> {
        fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
            f.write_str(self.0)
        }
    }
    assert_failed_inner(AssertKind::Match, &left, &Pattern(right), args);
}

/// Non-generic version of the above functions, to avoid code bloat. <br>上述函数的非泛型版本，以避免代码膨胀。<br>
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never), cold)]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
fn assert_failed_inner(
    kind: AssertKind,
    left: &dyn fmt::Debug,
    right: &dyn fmt::Debug,
    args: Option<fmt::Arguments<'_>>,
) -> ! {
    let op = match kind {
        AssertKind::Eq => "==",
        AssertKind::Ne => "!=",
        AssertKind::Match => "matches",
    };

    match args {
        Some(args) => panic!(
            r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
            op, left, right, args
        ),
        None => panic!(
            r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
            op, left, right,
        ),
    }
}

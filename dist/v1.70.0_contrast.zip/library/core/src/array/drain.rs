use crate::iter::{TrustedLen, UncheckedIterator};
use crate::mem::ManuallyDrop;
use crate::ptr::drop_in_place;
use crate::slice;

/// A situationally-optimized version of `array.into_iter().for_each(func)`. <br>`array.into_iter().for_each(func)` 的情境优化版本。<br>
///
/// [`crate::array::IntoIter`]s are great when you need an owned iterator, but storing the entire array *inside* the iterator like that can sometimes pessimize code. <br>[`crate::IntoIter`] 在您需要一个拥有所有权的迭代器时非常有用，但是像这样将整个数组*内部*存储在迭代器中有时会使代码变得悲观。<br>
/// Notable, it can be more bytes than you really want to move around, and because the array accesses index into it SRoA has a harder time optimizing away the type than it does iterators that just hold a couple pointers. <br>值得注意的是，它可能比您真正想要移动的字节更多，并且因为数组访问其中的索引，所以 SRoA 比只包含几个指针的迭代器更难优化类型。<br>
///
///
/// Thus this function exists, which gives a way to get *moved* access to the elements of an array using a small iterator -- no bigger than a slice iterator. <br>因此这个函数存在，它提供了一种方法来*移动*使用小迭代器访问数组的元素 -- 不比切片迭代器大。<br>
///
/// The function-taking-a-closure structure makes it safe, as it keeps callers from looking at already-dropped elements. <br>函数 - taking-a - 闭包结构体使它变得安全，因为它可以防止，调用者，查看已经 - 丢弃的元素。<br>
///
///
///
///
pub(crate) fn drain_array_with<T, R, const N: usize>(
    array: [T; N],
    func: impl for<'a> FnOnce(Drain<'a, T>) -> R,
) -> R {
    let mut array = ManuallyDrop::new(array);
    // SAFETY: Now that the local won't drop it, it's ok to construct the `Drain` which will. <br>既然当地人不会抛弃它，那么构建 `Drain` 就可以了。<br>
    let drain = Drain(array.iter_mut());
    func(drain)
}

/// See [`drain_array_with`] -- this is `pub(crate)` only so it's allowed to be mentioned in the signature of that method. <br>请参见 [`drain_array_with`]-- 这只是 `pub(crate)`，因此可以在该方法的签名中提及它。<br>
/// (Otherwise it hits `E0446`.) <br>(否则它会命中 `E0446`。)<br>
// INVARIANT: It's ok to drop the remainder of the inner iterator. <br>抛弃内部迭代器的其余部分是可以的。<br>
pub(crate) struct Drain<'a, T>(slice::IterMut<'a, T>);

impl<T> Drop for Drain<'_, T> {
    fn drop(&mut self) {
        // SAFETY: By the type invariant, we're allowed to drop all these. <br>通过类型不，变体，我们可以放弃所有这些。<br>
        unsafe { drop_in_place(self.0.as_mut_slice()) }
    }
}

impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        let p: *const T = self.0.next()?;
        // SAFETY: The iterator was already advanced, so we won't drop this later. <br>迭代器已经提前了，所以我们以后不会丢弃它。<br>
        Some(unsafe { p.read() })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = self.len();
        (n, Some(n))
    }
}

impl<T> ExactSizeIterator for Drain<'_, T> {
    #[inline]
    fn len(&self) -> usize {
        self.0.len()
    }
}

// SAFETY: This is a 1:1 wrapper for a slice iterator, which is also `TrustedLen`. <br>这是切片迭代器的 1:1 包装器，它也是 `TrustedLen`。<br>
unsafe impl<T> TrustedLen for Drain<'_, T> {}

impl<T> UncheckedIterator for Drain<'_, T> {
    unsafe fn next_unchecked(&mut self) -> T {
        // SAFETY: `Drain` is 1:1 with the inner iterator, so if the caller promised that there's an element left, the inner iterator has one too. <br>`Drain` 与内部迭代器是 1:1，所以如果调用者承诺还有一个元素，则内部迭代器也有一个。<br>
        //
        let p: *const T = unsafe { self.0.next_unchecked() };
        // SAFETY: The iterator was already advanced, so we won't drop this later. <br>迭代器已经提前了，所以我们以后不会丢弃它。<br>
        unsafe { p.read() }
    }
}

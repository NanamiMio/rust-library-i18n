//! Trait implementations for `str`. <br>`str` 的 Trait 实现。<br>

use crate::cmp::Ordering;
use crate::intrinsics::assert_unsafe_precondition;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implements ordering of strings. <br>实现字符串排序。<br>
///
/// Strings are ordered  [lexicographically](Ord#lexicographical-comparison) by their byte values. <br>字符串按字节值按 [按字典顺序](Ord#lexicographical-comparison) 排序。<br>
/// This orders Unicode code points based on their positions in the code charts. <br>这将根据 Unicode 代码点在代码图中的位置进行排序。<br>
/// This is not necessarily the same as "alphabetical" order, which varies by language and locale. <br>这不一定与 "alphabetical" 顺序相同，后者因语言和区域设置而异。<br>
/// Sorting strings according to culturally-accepted standards requires locale-specific data that is outside the scope of the `str` type. <br>根据文化认可的标准对字符串进行排序需要 `str` 类型的作用域之外的特定于语言环境的数据。<br>
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implements comparison operations on strings. <br>对字符串执行比较操作。<br>
///
/// Strings are compared [lexicographically](Ord#lexicographical-comparison) by their byte values. <br>[按字典顺序](Ord#lexicographical-comparison) 通过字符串的字节值对字符串进行比较。<br>
/// This compares Unicode code points based on their positions in the code charts. <br>这将根据 Unicode 代码点在代码表中的位置进行比较。<br>
/// This is not necessarily the same as "alphabetical" order, which varies by language and locale. <br>这不一定与 "alphabetical" 顺序相同，后者因语言和区域设置而异。<br>
/// Comparing strings according to culturally-accepted standards requires locale-specific data that is outside the scope of the `str` type. <br>根据文化认可的标准比较字符串需要特定于语言环境的数据，该数据不在 `str` 类型的作用域之内。<br>
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_slice_index", issue = "none")]
impl<I> const ops::Index<I> for str
where
    I: ~const SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_slice_index", issue = "none")]
impl<I> const ops::IndexMut<I> for str
where
    I: ~const SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
const fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implements substring slicing with syntax `&self[..]` or `&mut self[..]`. <br>使用语法 `&self[..]` 或 `&mut self[..]` 实现子字符串切片。<br>
///
/// Returns a slice of the whole string, i.e., returns `&self` or `&mut self`. <br>返回整个字符串的切片，即返回 `&self` 或 `&mut self`。<br> Equivalent to `&self[0 .. <br>相当于 `&self[0 ..<br>
/// len]` or `&mut self[0 .. <br>len]` 或 `&mut self[0 ..<br>
/// len]`.
/// Unlike other indexing operations, this can never panic. <br>与其他索引操作不同，此操作永远不能 panic。<br>
///
/// This operation is *O*(1). <br>此运算为 *O*(1)。<br>
///
/// Prior to 1.20.0, these indexing operations were still supported by direct implementation of `Index` and `IndexMut`. <br>在 1.20.0 之前，`Index` 和 `IndexMut` 的直接实现仍支持这些索引操作。<br>
///
/// Equivalent to `&self[0 .. len]` or `&mut self[0 .. len]`. <br>等效于 `&self[0 .. len]` 或 `&mut self[0 .. len]`。<br>
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
#[rustc_const_unstable(feature = "const_slice_index", issue = "none")]
unsafe impl const SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implements substring slicing with syntax `&self[begin .. end]` or `&mut self[begin .. end]`. <br>使用语法 `&self[begin .. end]` 或 `&mut self[begin .. end]` 实现子字符串切片。<br>
///
/// Returns a slice of the given string from the byte range [`begin`, `end`). <br>从字节范围 [`begin，`end`) 返回给定字符串的切片。<br>
///
/// This operation is *O*(1). <br>此运算为 *O*(1)。<br>
///
/// Prior to 1.20.0, these indexing operations were still supported by direct implementation of `Index` and `IndexMut`. <br>在 1.20.0 之前，`Index` 和 `IndexMut` 的直接实现仍支持这些索引操作。<br>
///
/// # Panics
///
/// Panics if `begin` or `end` does not point to the starting byte offset of a character (as defined by `is_char_boundary`), if `begin > end`, or if `end > len`. <br>如果 `begin` 或 `end` 未指向字符的起始字节偏移量 (由 `is_char_boundary` 定义)，`begin > end` 或 `end > len`，就会出现 panics。<br>
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // these will panic: <br>这些将是 panic：<br>
/// // byte 2 lies within `ö`: <br>字节 2 位于 `ö` 内：<br>
/// // &s[2 ..3];
///
/// // byte 8 lies within `老` &s[1 ..
/// // 8];
///
/// // byte 100 is outside the string &s[3 .. <br>字节 100 在字符串 &s[3 之外。<br>
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
#[rustc_const_unstable(feature = "const_slice_index", issue = "none")]
unsafe impl const SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: just checked that `start` and `end` are on a char boundary, and we are passing in a safe reference, so the return value will also be one. <br>刚刚检查了 `start` 和 `end` 是否在 char 边界上，并且我们传入了安全的引用，因此返回值也将为 1。<br>
            //
            // We also checked char boundaries, so this is valid UTF-8. <br>我们还检查了字符边界，因此这是有效的 UTF-8。<br>
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: just checked that `start` and `end` are on a char boundary. <br>刚刚检查 `start` 和 `end` 是否在字符边界上。<br>
            // We know the pointer is unique because we got it from `slice`. <br>我们知道指针是唯一的，因为我们是从 `slice` 获得的。<br>
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SAFETY: the caller guarantees that `self` is in bounds of `slice` which satisfies all the conditions for `add`. <br>调用者保证 `self` 在 `slice` 的范围内，该范围满足 `add` 的所有条件。<br>
        //
        let ptr = unsafe {
            let this = ops::Range { ..self };
            assert_unsafe_precondition!(
                "str::get_unchecked requires that the range is within the string slice",
                (this: ops::Range<usize>, slice: *const [u8]) =>
                // We'd like to check that the bounds are on char boundaries, but there's not really a way to do so without reading behind the pointer, which has aliasing implications. <br>我们想检查边界是否在 char 边界上，但是如果不读取指针后面的内容，就没有真正的方法可以做到这一点，这会产生别名影响。<br>
                //
                // It's also not possible to move this check up to `str::get_unchecked` without adding a special function to `SliceIndex` just for this. <br>如果不为此向 `SliceIndex` 添加特殊的函数，也无法将此检查向上移动到 `str::get_unchecked`。<br>
                //
                //
                //
                this.end >= this.start && this.end <= slice.len()
            );
            slice.as_ptr().add(self.start)
        };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAFETY: see comments for `get_unchecked`. <br>请参见 `get_unchecked` 的注释。<br>
        let ptr = unsafe {
            let this = ops::Range { ..self };
            assert_unsafe_precondition!(
                "str::get_unchecked_mut requires that the range is within the string slice",
                (this: ops::Range<usize>, slice: *mut [u8]) =>
                this.end >= this.start && this.end <= slice.len()
            );
            slice.as_mut_ptr().add(self.start)
        };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary checks that the index is in [0, .len()] cannot reuse `get` as above, because of NLL trouble <br>is_char_boundary 由于 NLL 问题而无法检查索引是否位于 [0, .len()] 中，因此无法如上所述重用 `get`<br>
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: just checked that `start` and `end` are on a char boundary, and we are passing in a safe reference, so the return value will also be one. <br>刚刚检查了 `start` 和 `end` 是否在 char 边界上，并且我们传入了安全的引用，因此返回值也将为 1。<br>
            //
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implements substring slicing with syntax `&self[.. end]` or `&mut self[.. end]`. <br>使用语法 `&self[.. end]` 或 `&mut self[.. end]` 实现子字符串切片。<br>
///
/// Returns a slice of the given string from the byte range \[0, `end`). <br>从字节范围 \[0, `end`) 中返回给定字符串的切片。<br>
/// Equivalent to `&self[0 .. end]` or `&mut self[0 .. end]`. <br>等效于 `&self[0 .. end]` 或 `&mut self[0 .. end]`。<br>
///
/// This operation is *O*(1). <br>此运算为 *O*(1)。<br>
///
/// Prior to 1.20.0, these indexing operations were still supported by direct implementation of `Index` and `IndexMut`. <br>在 1.20.0 之前，`Index` 和 `IndexMut` 的直接实现仍支持这些索引操作。<br>
///
/// # Panics
///
/// Panics if `end` does not point to the starting byte offset of a character (as defined by `is_char_boundary`), or if `end > len`. <br>如果 `end` 没有指向字符的起始字节偏移量 (由 `is_char_boundary` 定义)，或者 `end > len`，就会出现 panics。<br>
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
#[rustc_const_unstable(feature = "const_slice_index", issue = "none")]
unsafe impl const SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAFETY: just checked that `end` is on a char boundary, and we are passing in a safe reference, so the return value will also be one. <br>刚刚检查了 `end` 是否在 char 边界上，并且我们传递了一个安全的引用，因此返回值也将为 1。<br>
            //
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAFETY: just checked that `end` is on a char boundary, and we are passing in a safe reference, so the return value will also be one. <br>刚刚检查了 `end` 是否在 char 边界上，并且我们传递了一个安全的引用，因此返回值也将为 1。<br>
            //
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAFETY: the caller has to uphold the safety contract for `get_unchecked`. <br>调用者必须维护 `get_unchecked` 的安全保证。<br>
        unsafe { (0..self.end).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SAFETY: the caller has to uphold the safety contract for `get_unchecked_mut`. <br>调用者必须维护 `get_unchecked_mut` 的安全保证。<br>
        unsafe { (0..self.end).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SAFETY: just checked that `end` is on a char boundary, and we are passing in a safe reference, so the return value will also be one. <br>刚刚检查了 `end` 是否在 char 边界上，并且我们传递了一个安全的引用，因此返回值也将为 1。<br>
            //
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implements substring slicing with syntax `&self[begin ..]` or `&mut self[begin ..]`. <br>使用语法 `&self[begin ..]` 或 `&mut self[begin ..]` 实现子字符串切片。<br>
///
/// Returns a slice of the given string from the byte range \[`begin`, `len`). <br>从字节范围 \[`begin`, `len`) 中返回给定字符串的切片。<br>
/// Equivalent to `&self[begin .. len]` or `&mut self[begin .. len]`. <br>相当于 `&self[begin .. len]` 或 `&mut self[begin .. len]`。<br>
///
/// This operation is *O*(1). <br>此运算为 *O*(1)。<br>
///
/// Prior to 1.20.0, these indexing operations were still supported by direct implementation of `Index` and `IndexMut`. <br>在 1.20.0 之前，`Index` 和 `IndexMut` 的直接实现仍支持这些索引操作。<br>
///
/// # Panics
///
/// Panics if `begin` does not point to the starting byte offset of a character (as defined by `is_char_boundary`), or if `begin > len`. <br>如果 `begin` 没有指向字符的起始字节偏移量 (由 `is_char_boundary` 定义)，或者 `begin > len`，就会出现 panics。<br>
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
#[rustc_const_unstable(feature = "const_slice_index", issue = "none")]
unsafe impl const SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAFETY: just checked that `start` is on a char boundary, and we are passing in a safe reference, so the return value will also be one. <br>刚刚检查了 `start` 是否在 char 边界上，并且我们传递了一个安全的引用，因此返回值也将为 1。<br>
            //
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAFETY: just checked that `start` is on a char boundary, and we are passing in a safe reference, so the return value will also be one. <br>刚刚检查了 `start` 是否在 char 边界上，并且我们传递了一个安全的引用，因此返回值也将为 1。<br>
            //
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let len = (slice as *const [u8]).len();
        // SAFETY: the caller has to uphold the safety contract for `get_unchecked`. <br>调用者必须维护 `get_unchecked` 的安全保证。<br>
        unsafe { (self.start..len).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let len = (slice as *mut [u8]).len();
        // SAFETY: the caller has to uphold the safety contract for `get_unchecked_mut`. <br>调用者必须维护 `get_unchecked_mut` 的安全保证。<br>
        unsafe { (self.start..len).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SAFETY: just checked that `start` is on a char boundary, and we are passing in a safe reference, so the return value will also be one. <br>刚刚检查了 `start` 是否在 char 边界上，并且我们传递了一个安全的引用，因此返回值也将为 1。<br>
            //
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implements substring slicing with syntax `&self[begin ..= end]` or `&mut self[begin ..= end]`. <br>使用语法 `&self[begin ..= end]` 或 `&mut self[begin ..= end]` 实现子字符串切片。<br>
///
/// Returns a slice of the given string from the byte range [`begin`, `end`]. <br>从字节范围 [`begin`, `end`] 返回给定字符串的切片。<br> Equivalent to `&self [begin .. end + 1]` or `&mut self[begin .. end + 1]`, except if `end` has the maximum value for `usize`. <br>等效于 `&self [begin .. end + 1]` 或 `&mut self[begin .. end + 1]`，除非 `end` 具有 `usize` 的最大值。<br>
///
/// This operation is *O*(1). <br>此运算为 *O*(1)。<br>
///
/// # Panics
///
/// Panics if `begin` does not point to the starting byte offset of a character (as defined by `is_char_boundary`), if `end` does not point to the ending byte offset of a character (`end + 1` is either a starting byte offset or equal to `len`), if `begin > end`, or if `end >= len`. <br>如果 `begin` 没有指向字符的起始字节偏移量 (由 `is_char_boundary` 定义)，如果 `end` 没有指向字符的结束字节偏移量 (`end + 1` 是起始字节偏移量或等于 `len`)，如果 `begin > end`，或者如果 `end >= len`，就会出现 panics。<br>
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
#[rustc_const_unstable(feature = "const_slice_index", issue = "none")]
unsafe impl const SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAFETY: the caller must uphold the safety contract for `get_unchecked`. <br>调用者必须遵守 `get_unchecked` 的安全保证。<br>
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SAFETY: the caller must uphold the safety contract for `get_unchecked_mut`. <br>调用者必须遵守 `get_unchecked_mut` 的安全保证。<br>
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implements substring slicing with syntax `&self[..= end]` or `&mut self[..= end]`. <br>使用语法 `&self[..= end]` 或 `&mut self[..= end]` 实现子字符串切片。<br>
///
/// Returns a slice of the given string from the byte range \[0, `end`\]. <br>从字节范围 \[0, `end`\] 中返回给定字符串的切片。<br>
/// Equivalent to `&self [0 .. end + 1]`, except if `end` has the maximum value for `usize`. <br>等效于 `&self [0 .. end + 1]`，除非 `end` 具有 `usize` 的最大值。<br>
///
/// This operation is *O*(1). <br>此运算为 *O*(1)。<br>
///
/// # Panics
///
/// Panics if `end` does not point to the ending byte offset of a character (`end + 1` is either a starting byte offset as defined by `is_char_boundary`, or equal to `len`), or if `end >= len`. <br>如果 `end` 没有指向字符的结束字节偏移量 (`end + 1` 是 `is_char_boundary` 定义的起始字节偏移量，或者等于 `len`)，或者如果 `end >= len`，就会出现 panics。<br>
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
#[rustc_const_unstable(feature = "const_slice_index", issue = "none")]
unsafe impl const SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        (0..=self.end).get(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        (0..=self.end).get_mut(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAFETY: the caller must uphold the safety contract for `get_unchecked`. <br>调用者必须遵守 `get_unchecked` 的安全保证。<br>
        unsafe { (0..=self.end).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SAFETY: the caller must uphold the safety contract for `get_unchecked_mut`. <br>调用者必须遵守 `get_unchecked_mut` 的安全保证。<br>
        unsafe { (0..=self.end).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        (0..=self.end).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        (0..=self.end).index_mut(slice)
    }
}

/// Parse a value from a string <br>解析字符串中的值<br>
///
/// `FromStr`'s [`from_str`] method is often used implicitly, through [`str`]'s [`parse`] method. <br>FromStr 的 [`from_str`] 方法通常通过 [`str`] 的 [`parse`] 方法隐式使用。<br>
/// See [`parse`]'s documentation for examples. <br>有关示例，请参见 [`parse`] 的文档。<br>
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` does not have a lifetime parameter, and so you can only parse types that do not contain a lifetime parameter themselves. <br>`FromStr` 没有生命周期参数，因此您只能解析本身不包含生命周期参数的类型。<br>
///
/// In other words, you can parse an `i32` with `FromStr`, but not a `&i32`. <br>换句话说，您可以使用 `FromStr` 解析 `i32`，但是不能解析 `&i32`。<br>
/// You can parse a struct that contains an `i32`, but not one that contains an `&i32`. <br>您可以解析包含 `i32` 的结构体，但不能解析包含 `&i32` 的结构体。<br>
///
/// # Examples
///
/// Basic implementation of `FromStr` on an example `Point` type: <br>`FromStr` 在示例 `Point` 类型上的基本实现：<br>
///
/// ```
/// use std::str::FromStr;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// #[derive(Debug, PartialEq, Eq)]
/// struct ParsePointError;
///
/// impl FromStr for Point {
///     type Err = ParsePointError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let (x, y) = s
///             .strip_prefix('(')
///             .and_then(|s| s.strip_suffix(')'))
///             .and_then(|s| s.split_once(','))
///             .ok_or(ParsePointError)?;
///
///         let x_fromstr = x.parse::<i32>().map_err(|_| ParsePointError)?;
///         let y_fromstr = y.parse::<i32>().map_err(|_| ParsePointError)?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let expected = Ok(Point { x: 1, y: 2 });
/// // Explicit call <br>显式调用<br>
/// assert_eq!(Point::from_str("(1,2)"), expected);
/// // Implicit calls, through parse <br>隐式调用，通过解析<br>
/// assert_eq!("(1,2)".parse(), expected);
/// assert_eq!("(1,2)".parse::<Point>(), expected);
/// // Invalid input string <br>输入字符串无效<br>
/// assert!(Point::from_str("(1 2)").is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// The associated error which can be returned from parsing. <br>可以从解析中返回的相关错误。<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Parses a string `s` to return a value of this type. <br>解析字符串 `s` 以返回此类型的值。<br>
    ///
    /// If parsing succeeds, return the value inside [`Ok`], otherwise when the string is ill-formatted return an error specific to the inside [`Err`]. <br>如果解析成功，则返回 [`Ok`] 内部的值，否则，当字符串格式错误时，返回特定于 [`Err`] 内部的错误。<br>
    /// The error type is specific to the implementation of the trait. <br>错误类型特定于 trait 的实现。<br>
    ///
    /// # Examples
    ///
    /// Basic usage with [`i32`], a type that implements `FromStr`: <br>[`i32`] 的基本用法，一种实现 `FromStr` 的类型：<br>
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Parse a `bool` from a string. <br>从字符串中解析 `bool`。<br>
    ///
    /// The only accepted values are `"true"` and `"false"`. <br>唯一可接受的值是 `"true"` 和 `"false"`。<br>
    /// Any other input will return an error. <br>任何其他输入都将返回错误。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Note, in many cases, the `.parse()` method on `str` is more proper. <br>注意，在许多情况下，`str` 上的 `.parse()` 方法更合适。<br>
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError),
        }
    }
}

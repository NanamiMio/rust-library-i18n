//! Decodes a floating-point value into individual parts and error ranges. <br>将浮点值解码为单独的部分和错误范围。<br>

use crate::num::dec2flt::float::RawFloat;
use crate::num::FpCategory;

/// Decoded unsigned finite value, such that: <br>解码后的无符号有限值，例如：<br>
///
/// - The original value equals to `mant * 2^exp`. <br>原始值等于 `mant * 2^exp`。<br>
///
/// - Any number from `(mant - minus) * 2^exp` to `(mant + plus) * 2^exp` will round to the original value. <br>从 `(mant - minus)*2^exp` 到 `(mant + plus)* 2^exp` 的任何数字都将四舍五入为原始值。<br>
/// The range is inclusive only when `inclusive` is `true`. <br>仅当 `inclusive` 为 `true` 时，范围才包括在内。<br>
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// The scaled mantissa. <br>缩放的尾数。<br>
    pub mant: u64,
    /// The lower error range. <br>较低的误差范围。<br>
    pub minus: u64,
    /// The upper error range. <br>上限误差范围。<br>
    pub plus: u64,
    /// The shared exponent in base <br>基数中的共享指数<br> 2.
    pub exp: i16,
    /// True when the error range is inclusive. <br>如果错误范围包含在内，则为 true。<br>
    ///
    /// In IEEE 754, this is true when the original mantissa was even. <br>在 IEEE 754 中，当原始尾数为偶数时，这是正确的。<br>
    pub inclusive: bool,
}

/// Decoded unsigned value. <br>解码后的无符号值。<br>
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities, either positive or negative. <br>无穷大，正数或负数。<br>
    Infinite,
    /// Zero, either positive or negative. <br>零，正数或负数。<br>
    Zero,
    /// Finite numbers with further decoded fields. <br>具有进一步解码字段的有限数字。<br>
    Finite(Decoded),
}

/// A floating point type which can be `decode`d. <br>可以被解码的浮点类型。<br>
pub trait DecodableFloat: RawFloat + Copy {
    /// The minimum positive normalized value. <br>最小正归一化值。<br>
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Returns a sign (true when negative) and `FullDecoded` value from given floating point number. <br>从给定的浮点数返回一个符号 (当为负数时为 true) 和 `FullDecoded` 值。<br>
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // neighbors: (mant - 2, exp) -- (mant, exp) -- (mant + 2, exp) Float::integer_decode always preserves the exponent, so the mantissa is scaled for subnormals. <br>neighbors: (mant - 2, exp) -- (mant, exp) -- (mant + 2, exp) Float::integer_decode 始终保留指数，因此尾数针对正常以下进行缩放。<br>
            //
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // neighbors: (maxmant, exp - 1) -- (minnormmant, exp) -- (minnormmant + 1, exp) where maxmant = minnormmant * 2 - 1 <br>neighbors: (maxmant, exp - 1) -- (minnormmant, exp) -- (minnormmant + 1, exp) 其中 maxmant = minnormmant * 2 - 1<br>
                //
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // neighbors: (mant - 1, exp) -- (mant, exp) -- (mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}

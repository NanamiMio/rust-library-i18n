//! Redundant constants module for the [`i128` primitive type][i128]. <br>[`i128` primitive type][i128] 的冗余常量模块。<br>
//!
//! New code should use the associated constants directly on the primitive type. <br>新代码应直接在原始类型上使用关联的常量。<br>

#![stable(feature = "i128", since = "1.26.0")]
#![deprecated(
    since = "TBD",
    note = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }

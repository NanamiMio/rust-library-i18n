//! Functions to parse floating-point numbers. <br>解析浮点数的函数。<br>

use crate::num::dec2flt::common::{is_8digits, ByteSlice};
use crate::num::dec2flt::float::RawFloat;
use crate::num::dec2flt::number::Number;

const MIN_19DIGIT_INT: u64 = 100_0000_0000_0000_0000;

/// Parse 8 digits, loaded as bytes in little-endian order. <br>解析 8 位数字，以小端顺序加载为字节。<br>
///
/// This uses the trick where every digit is in [0x030, 0x39], and therefore can be parsed in 3 multiplications, much faster than the normal <br>这使用了每个数字都在 [0x030, 0x39] 中的技巧，因此可以在 3 次乘法中解析，比正常情况快得多<br> 8.
///
/// This is based off the algorithm described in "Fast numeric string to int", available here: <https://johnnylee-sde.github.io/Fast-numeric-string-to-int/>. <br>这是基于 "将数字字符串快速转换为整数" 中描述的算法，可在此处获得: <https://johnnylee-sde.github.io/Fast-numeric-string-to-int/>。<br>
///
///
///
fn parse_8digits(mut v: u64) -> u64 {
    const MASK: u64 = 0x0000_00FF_0000_00FF;
    const MUL1: u64 = 0x000F_4240_0000_0064;
    const MUL2: u64 = 0x0000_2710_0000_0001;
    v -= 0x3030_3030_3030_3030;
    v = (v * 10) + (v >> 8); // will not overflow, fits in 63 bits <br>不会溢出，适合 63 位<br>
    let v1 = (v & MASK).wrapping_mul(MUL1);
    let v2 = ((v >> 16) & MASK).wrapping_mul(MUL2);
    ((v1.wrapping_add(v2) >> 32) as u32) as u64
}

/// Parse digits until a non-digit character is found. <br>解析数字直到找到非数字字符。<br>
fn try_parse_digits(mut s: &[u8], mut x: u64) -> (&[u8], u64) {
    // may cause overflows, to be handled later <br>可能会导致溢出，稍后处理<br>

    while s.len() >= 8 {
        let num = s.read_u64();
        if is_8digits(num) {
            x = x.wrapping_mul(1_0000_0000).wrapping_add(parse_8digits(num));
            s = &s[8..];
        } else {
            break;
        }
    }

    s = s.parse_digits(|digit| {
        x = x.wrapping_mul(10).wrapping_add(digit as _);
    });

    (s, x)
}

/// Parse up to 19 digits (the max that can be stored in a 64-bit integer). <br>解析最多 19 位数字 (可以存储在 64 位整数中的最大值)。<br>
fn try_parse_19digits(s_ref: &mut &[u8], x: &mut u64) {
    let mut s = *s_ref;

    while *x < MIN_19DIGIT_INT {
        // FIXME: Can't use s.split_first() here yet, <br>这里还不能使用 s.split_first()，<br>
        // see https://github.com/rust-lang/rust/issues/109328
        if let [c, s_next @ ..] = s {
            let digit = c.wrapping_sub(b'0');

            if digit < 10 {
                *x = (*x * 10) + digit as u64; // no overflows here <br>这里没有溢出<br>
                s = s_next;
            } else {
                break;
            }
        } else {
            break;
        }
    }

    *s_ref = s;
}

/// Parse the scientific notation component of a float. <br>解析浮点数的科学记数法组件。<br>
fn parse_scientific(s_ref: &mut &[u8]) -> Option<i64> {
    let mut exponent = 0i64;
    let mut negative = false;

    let mut s = *s_ref;

    if let Some((&c, s_next)) = s.split_first() {
        negative = c == b'-';
        if c == b'-' || c == b'+' {
            s = s_next;
        }
    }

    if matches!(s.first(), Some(&x) if x.is_ascii_digit()) {
        *s_ref = s.parse_digits(|digit| {
            // no overflows here, saturate well before overflow <br>这里没有溢出，在溢出之前饱和<br>
            if exponent < 0x10000 {
                exponent = 10 * exponent + digit as i64;
            }
        });
        if negative { Some(-exponent) } else { Some(exponent) }
    } else {
        *s_ref = s;
        None
    }
}

/// Parse a partial, non-special floating point number. <br>解析部分非特殊浮点数。<br>
///
/// This creates a representation of the float as the significant digits and the decimal exponent. <br>这将创建浮点数表示为有效数字和十进制指数。<br>
///
fn parse_partial_number(mut s: &[u8]) -> Option<(Number, usize)> {
    debug_assert!(!s.is_empty());

    // parse initial digits before dot <br>解析点之前的初始数字<br>
    let mut mantissa = 0_u64;
    let start = s;
    let tmp = try_parse_digits(s, mantissa);
    s = tmp.0;
    mantissa = tmp.1;
    let mut n_digits = s.offset_from(start);

    // handle dot with the following digits <br>用以下数字处理点<br>
    let mut n_after_dot = 0;
    let mut exponent = 0_i64;
    let int_end = s;

    if let Some((&b'.', s_next)) = s.split_first() {
        s = s_next;
        let before = s;
        let tmp = try_parse_digits(s, mantissa);
        s = tmp.0;
        mantissa = tmp.1;
        n_after_dot = s.offset_from(before);
        exponent = -n_after_dot as i64;
    }

    n_digits += n_after_dot;
    if n_digits == 0 {
        return None;
    }

    // handle scientific format <br>处理科学格式<br>
    let mut exp_number = 0_i64;
    if let Some((&c, s_next)) = s.split_first() {
        if c == b'e' || c == b'E' {
            s = s_next;
            // If None, we have no trailing digits after exponent, or an invalid float. <br>如果没有，我们在指数之后没有尾随数字，或者一个无效的浮点数。<br>
            exp_number = parse_scientific(&mut s)?;
            exponent += exp_number;
        }
    }

    let len = s.offset_from(start) as _;

    // handle uncommon case with many digits <br>处理多位数的罕见情况<br>
    if n_digits <= 19 {
        return Some((Number { exponent, mantissa, negative: false, many_digits: false }, len));
    }

    n_digits -= 19;
    let mut many_digits = false;
    let mut p = start;
    while let Some((&c, p_next)) = p.split_first() {
        if c == b'.' || c == b'0' {
            n_digits -= c.saturating_sub(b'0' - 1) as isize;
            p = p_next;
        } else {
            break;
        }
    }
    if n_digits > 0 {
        // at this point we have more than 19 significant digits, let's try again <br>此时我们有超过 19 位有效数字，让我们再试一次<br>
        many_digits = true;
        mantissa = 0;
        let mut s = start;
        try_parse_19digits(&mut s, &mut mantissa);
        exponent = if mantissa >= MIN_19DIGIT_INT {
            // big int <br>大整数<br>
            int_end.offset_from(s)
        } else {
            s = &s[1..];
            let before = s;
            try_parse_19digits(&mut s, &mut mantissa);
            -s.offset_from(before)
        } as i64;
        // add back the explicit part <br>添加回显式部分<br>
        exponent += exp_number;
    }

    Some((Number { exponent, mantissa, negative: false, many_digits }, len))
}

/// Try to parse a non-special floating point number, as well as two slices with integer and fractional parts and the parsed exponent. <br>尝试解析一个非特殊的浮点数，以及具有整数和小数部分的两个切片以及解析的指数。<br>
///
///
pub fn parse_number(s: &[u8]) -> Option<Number> {
    if let Some((float, rest)) = parse_partial_number(s) {
        if rest == s.len() {
            return Some(float);
        }
    }
    None
}

/// Try to parse a special, non-finite float. <br>尝试解析一个特殊的、非有限的浮点数。<br>
pub(crate) fn parse_inf_nan<F: RawFloat>(s: &[u8], negative: bool) -> Option<F> {
    // Since a valid string has at most the length 8, we can load all relevant characters into a u64 and work from there. <br>由于有效字符串的长度最多为 8，因此我们可以将所有相关字符加载到 u64 中并从那里开始工作。<br>
    //
    // This also generates much better code. <br>这也会生成更好的代码。<br>

    let mut register;
    let len: usize;

    // All valid strings are either of length 8 or <br>所有有效字符串的长度都是 8 或<br> 3.
    if s.len() == 8 {
        register = s.read_u64();
        len = 8;
    } else if s.len() == 3 {
        let a = s[0] as u64;
        let b = s[1] as u64;
        let c = s[2] as u64;
        register = (c << 16) | (b << 8) | a;
        len = 3;
    } else {
        return None;
    }

    // Clear out the bits which turn ASCII uppercase characters into lowercase characters. <br>清除将 ASCII 大写字符转换为小写字符的位。<br>
    // The resulting string is all uppercase. <br>结果字符串全部大写。<br>
    // What happens to other characters is irrelevant. <br>其他角色发生什么是无关紧要的。<br>
    register &= 0xDFDFDFDFDFDFDFDF;

    // u64 values corresponding to relevant cases <br>相关案例对应的 u64 值<br>
    const INF_3: u64 = 0x464E49; // "INF"
    const INF_8: u64 = 0x5954494E49464E49; // "INFINITY"
    const NAN: u64 = 0x4E414E; // "NAN"

    // Match register value to constant to parse string. <br>匹配寄存器值到常量来解析字符串。<br>
    // Also match on the string length to catch edge cases like "inf\0\0\0\0\0". <br>还要在字符串长度上进行匹配，以捕捉像 "inf\0\0\0\0\0" 这样的边缘情况。<br>
    //
    let float = match (register, len) {
        (INF_3, 3) => F::INFINITY,
        (INF_8, 8) => F::INFINITY,
        (NAN, 3) => F::NAN,
        _ => return None,
    };

    if negative { Some(-float) } else { Some(float) }
}

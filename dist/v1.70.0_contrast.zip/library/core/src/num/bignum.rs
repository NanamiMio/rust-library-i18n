//! Custom arbitrary-precision number (bignum) implementation. <br>自定义任意精度数字 (bignum) 的实现。<br>
//!
//! This is designed to avoid the heap allocation at expense of stack memory. <br>这样做是为了避免以分配堆内存为代价来避免堆分配。<br>
//! The most used bignum type, `Big32x40`, is limited by 32 × 40 = 1,280 bits and will take at most 160 bytes of stack memory. <br>最常用的 bignum 类型 `Big32x40` 受 32×40=1,280 位的限制，最多占用 160 个字节的栈内存。<br>
//! This is more than enough for round-tripping all possible finite `f64` values. <br>对于往返所有可能的有限 `f64` 值而言，这绰绰有余。<br>
//!
//! In principle it is possible to have multiple bignum types for different inputs, but we don't do so to avoid the code bloat. <br>原则上，可以为不同的输入使用多个 bignum 类型，但是我们这样做并不是为了避免代码膨胀。<br>
//!
//! Each bignum is still tracked for the actual usages, so it normally doesn't matter. <br>仍然会跟踪每个 bignum 的实际用法，因此通常没有关系。<br>
//!

// This module is only for dec2flt and flt2dec, and only public because of coretests. <br>该模块仅用于 dec2flt 和 flt2dec，并且由于 coretests 而仅用于公共模块。<br>
// It is not intended to ever be stabilized. <br>它永远都不会稳定下来。<br>
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

/// Arithmetic operations required by bignums. <br>bignums 需要的算术运算。<br>
pub trait FullOps: Sized {
    /// Returns `(carry', v')` such that `carry' * 2^W + v' = self * other + other2 + carry`, where `W` is the number of bits in `Self`. <br>返回 `(carry', v')`，使得 `carry'*2^W + v' = self* other + other2 + carry`，其中 `W` 是 `Self` 中的位数。<br>
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// Returns `(quo, rem)` such that `borrow * 2^W + self = quo * other + rem` and `0 <= rem < other`, where `W` is the number of bits in `Self`. <br>返回 `(quo, rem)`，使得 `borrow *2^W + self = quo* other + rem` 和 `0 <= rem < other`，其中 `W` 是 `Self` 中的位数。<br>
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // This cannot overflow; <br>这不会溢出；<br>
                    // the output is between `0` and `2^nbits * (2^nbits - 1)`. <br>输出在 `0` 和 `2^nbits * (2^nbits - 1)` 之间。<br>
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // This cannot overflow; <br>这不会溢出；<br> the output is between `0` and `other * (2^nbits - 1)`. <br>输出在 `0` 和 `other * (2^nbits - 1)` 之间。<br>
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // See RFC #521 for enabling this. <br>有关启用此功能的信息，请参见 RFC #521。<br>
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Table of powers of 5 representable in digits. <br>5 的幂表可用数字表示。<br> Specifically, the largest {u8, u16, u32} value that's a power of five, plus the corresponding exponent. <br>具体来说，最大的 {u8, u16, u32} 值是 5 的幂，再加上相应的指数。<br>
/// Used in `mul_pow5`. <br>在 `mul_pow5` 中使用。<br>
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Stack-allocated arbitrary-precision (up to certain limit) integer. <br>栈分配的任意精度 (达到一定限制) 整数。<br>
        ///
        /// This is backed by a fixed-size array of given type ("digit"). <br>这由给定类型 ("digit") 的固定大小的数组支持。<br>
        /// While the array is not very large (normally some hundred bytes), copying it recklessly may result in the performance hit. <br>尽管数组不是很大 (通常为几百个字节)，但不计后果地复制它可能会导致性能下降。<br>
        ///
        /// Thus this is intentionally not `Copy`. <br>因此，这不是 `Copy`。<br>
        ///
        /// All operations available to bignums panic in the case of overflows. <br>发生溢出时，bignums panic 可以使用所有操作。<br>
        /// The caller is responsible to use large enough bignum types. <br>调用者负责使用足够大的 bignum 类型。<br>
        pub struct $name {
            /// One plus the offset to the maximum "digit" in use. <br>一加偏移量到正在使用的最大 "digit"。<br>
            /// This does not decrease, so be aware of the computation order. <br>这不会减少，因此请注意计算顺序。<br>
            /// `base[size..]` should be zero. <br>`base[size..]` 应为零。<br>
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` represents `a + b*2^W + c*2^(2W) + ...` where `W` is the number of bits in the digit type. <br>`[a, b, c, ...]` 代表 `a + b*2^W + c*2^(2W) + ...`，其中 `W` 是数字类型中的位数。<br>
            base: [$ty; $n],
        }

        impl $name {
            /// Makes a bignum from one digit. <br>从一位数产生一个大数。<br>
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base }
            }

            /// Makes a bignum from `u64` value. <br>从 `u64` 值得到一个大数。<br>
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base }
            }

            /// Returns the internal digits as a slice `[a, b, c, ...]` such that the numeric value is `a + b * 2^W + c * 2^(2W) + ...` where `W` is the number of bits in the digit type. <br>返回内部数字作为切片 `[a, b, c, ...]`，以使数值为 `a + b *2^W + c* 2^(2W) + ...`，其中 `W` 是数字类型中的位数。<br>
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Returns the `i`-th bit where bit 0 is the least significant one. <br>返回第 i 位，其中位 0 是最低有效位。<br>
            /// In other words, the bit with weight `2^i`. <br>换句话说，钻头的重量为 `2^i`。<br>
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Returns `true` if the bignum is zero. <br>如果 bignum 为零，则返回 `true`。<br>
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// Returns the number of bits necessary to represent this value. <br>返回表示此值所需的位数。<br>
            /// Note that zero is considered to need 0 bits. <br>注意，零被认为需要 0 位。<br>
            pub fn bit_length(&self) -> usize {
                let digitbits = <$ty>::BITS as usize;
                let digits = self.digits();
                // Find the most significant non-zero digit. <br>找到最重要的非零数字。<br>
                let msd = digits.iter().rposition(|&x| x != 0);
                match msd {
                    Some(msd) => msd * digitbits + digits[msd].ilog2() as usize + 1,
                    // There are no non-zero digits, i.e., the number is zero. <br>没有非零数字，即数字为零。<br>
                    _ => 0,
                }
            }

            /// Adds `other` to itself and returns its own mutable reference. <br>向其自身添加 `other`，并返回其自己的可变引用。<br>
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::iter;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in iter::zip(&mut self.base[..sz], &other.base[..sz]) {
                    let (v, c) = (*a).carrying_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                let (v, mut carry) = self.base[0].carrying_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (v, c) = self.base[i].carrying_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// Subtracts `other` from itself and returns its own mutable reference. <br>从自身中减去 `other`，并返回其自己的可变引用。<br>
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::iter;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in iter::zip(&mut self.base[..sz], &other.base[..sz]) {
                    let (v, c) = (*a).carrying_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Multiplies itself by a digit-sized `other` and returns its own mutable reference. <br>将自身乘以数字大小的 `other` 并返回其自己的可变引用。<br>
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (v, c) = (*a).carrying_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Multiplies itself by `2^bits` and returns its own mutable reference. <br>将自身乘以 `2^bits` 并返回自己的变量引用。<br>
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // shift by `digits * digitbits` bits <br>移位 `digits * digitbits` 位<br>
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // shift by `bits` bits <br>移位 `bits` 位<br>
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base[..digits] is zero, no need to shift <br>self.base [.. digits] 为零，无需移位<br>
                }

                self.size = sz;
                self
            }

            /// Multiplies itself by `5^e` and returns its own mutable reference. <br>将自身乘以 `5^e` 并返回自己的变量引用。<br>
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // There are exactly n trailing zeros on 2^n, and the only relevant digit sizes are consecutive powers of two, so this is well suited index for the table. <br>在 2 ^ n 上正好有 n 个尾随零，并且唯一相关的数字大小是 2 的连续幂，因此这非常适合该表的索引。<br>
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Multiply with the largest single-digit power as long as possible <br>尽可能长时间乘以最大个位数的幂<br> ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... then finish off the remainder. <br>然后结束剩余的部分。<br>
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Multiplies itself by a number described by `other[0] + other[1] * 2^W + other[2] * 2^(2W) + ...` (where `W` is the number of bits in the digit type) and returns its own mutable reference. <br>将自身乘以 `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` 描述的数字 (其中 `W` 是数字类型的位数)，并返回其自己的可变引用。<br>
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // the internal routine. <br>内部例程。<br> works best when aa.len() <= bb.len(). <br>当 aa.len() <= bb.len() 时，效果最佳。<br>
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// Divides itself by a digit-sized `other` and returns its own mutable reference *and* the remainder. <br>用数字大小的 `other` 除以自身，并返回其自身的变量引用 *，其余为*。<br>
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Divide self by another bignum, overwriting `q` with the quotient and `r` with the remainder. <br>用另一个大数除以 self，用商覆盖 `q`，用余数覆盖 `r`。<br>
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Stupid slow base-2 long division taken from <br>愚蠢的慢 base-2 长除法取自<br>
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME use a greater base ($ty) for the long division. <br>对于长除法使用更大的基数 ($ty)。<br>
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Set bit `i` of q to <br>将 q 的位 `i` 设置为<br> 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// The digit type for `Big32x40`. <br>`Big32x40` 的数字类型。<br>
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// this one is used for testing only. <br>此仅用于测试。<br>
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}

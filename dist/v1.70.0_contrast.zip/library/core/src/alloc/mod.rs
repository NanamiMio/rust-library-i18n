//! Memory allocation APIs <br>内存分配 API<br>

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[deprecated(
    since = "1.52.0",
    note = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::error::Error;
use crate::fmt;
use crate::ptr::{self, NonNull};

/// The `AllocError` error indicates an allocation failure that may be due to resource exhaustion or to something wrong when combining the given input arguments with this allocator. <br>`AllocError` 错误表示分配失败，这可能是由于资源耗尽或将给定输入参数与此分配器组合在一起时出错所致。<br>
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

#[unstable(
    feature = "allocator_api",
    reason = "the precise API and guarantees it provides may be tweaked.",
    issue = "32838"
)]
impl Error for AllocError {}

// (we need this for downstream impl of trait Error) <br>(对于 trait 错误的下游隐含我们需要此功能)<br>
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// An implementation of `Allocator` can allocate, grow, shrink, and deallocate arbitrary blocks of data described via [`Layout`][]. <br>`Allocator` 的实现可以分配，增长，收缩和释放通过 [`Layout`][] 描述的任意数据块。<br>
///
/// `Allocator` is designed to be implemented on ZSTs, references, or smart pointers because having an allocator like `MyAlloc([u8; N])` cannot be moved, without updating the pointers to the allocated memory. <br>`Allocator` 被设计为在 ZST、引用或智能指针上实现，因为像 `MyAlloc([u8; N])` 这样的分配器无法移动，而不更新指向已分配内存的指针。<br>
///
/// Unlike [`GlobalAlloc`][], zero-sized allocations are allowed in `Allocator`. <br>与 [`GlobalAlloc`][] 不同，`Allocator` 允许零大小的分配。<br>
/// If an underlying allocator does not support this (like jemalloc) or return a null pointer (such as `libc::malloc`), this must be caught by the implementation. <br>如果底层分配器不支持此功能 (例如 jemalloc) 或返回空指针 (例如 `libc::malloc`)，则必须由实现捕获。<br>
///
/// ### Currently allocated memory <br>当前分配的内存<br>
///
/// Some of the methods require that a memory block be *currently allocated* via an allocator. <br>某些方法要求通过分配器 *currently* 分配存储块。<br> This means that: <br>这意味着：<br>
///
/// * the starting address for that memory block was previously returned by [`allocate`], [`grow`], or [`shrink`], and <br>该内存块的起始地址先前由 [`allocate`]，[`grow`] 或 [`shrink`] 返回，并且<br>
///
/// * the memory block has not been subsequently deallocated, where blocks are either deallocated directly by being passed to [`deallocate`] or were changed by being passed to [`grow`] or [`shrink`] that returns `Ok`. <br>内存块随后并未被释放，其中的块要么通过传递到 [`deallocate`] 直接释放，要么通过传递到返回 `Ok` 的 [`grow`] 或 [`shrink`] 进行了更改。<br>
///
/// If `grow` or `shrink` have returned `Err`, the passed pointer remains valid. <br>如果 `grow` 或 `shrink` 返回了 `Err`，则传递的指针保持有效。<br>
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Memory fitting <br>内存拟合<br>
///
/// Some of the methods require that a layout *fit* a memory block. <br>有些方法要求布局适合内存块。<br>
/// What it means for a layout to "fit" a memory block means (or equivalently, for a memory block to "fit" a layout) is that the following conditions must hold: <br>对于到 "fit" 的布局，存储块意味着 (或者，对于到 "fit" 的存储块，布局意味着) 必须满足以下条件：<br>
///
/// * The block must be allocated with the same alignment as [`layout.align()`], and <br>必须以与 [`layout.align()`] 相同的对齐方式分配该块，并且<br>
///
/// * The provided [`layout.size()`] must fall in the range `min ..= max`, where: <br>提供的 [`layout.size()`] 必须在 `min ..= max` 范围内，其中：<br>
///   - `min` is the size of the layout most recently used to allocate the block, and <br>`min` 是最近用于分配块的布局的大小，并且<br>
///   - `max` is the latest actual size returned from [`allocate`], [`grow`], or [`shrink`]. <br>`max` 是从 [`allocate`]、[`grow`] 或 [`shrink`] 返回的最新实际大小。<br>
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Memory blocks returned from an allocator must point to valid memory and retain their validity until the instance and all of its copies and clones are dropped, <br>从分配器返回的内存块必须指向有效内存并保持其有效性，直到实例及其所有副本和克隆都丢弃，<br>
///
/// * copying, cloning, or moving the allocator must not invalidate memory blocks returned from this allocator. <br>复制、克隆或移动分配器不得使从该分配器返回的内存块无效。<br> A copied or cloned allocator must behave like the same allocator, and <br>复制或克隆的分配器必须表现得像同一个分配器，并且<br>
///
/// * any pointer to a memory block which is [*currently allocated*] may be passed to any other method of the allocator. <br>指向 [*currently allocated*] 的存储块的任何指针都可以传递给分配器的任何其他方法。<br>
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[const_trait]
pub unsafe trait Allocator {
    /// Attempts to allocate a block of memory. <br>尝试分配一块内存。<br>
    ///
    /// On success, returns a [`NonNull<[u8]>`][NonNull] meeting the size and alignment guarantees of `layout`. <br>成功后，返回满足 `layout` 大小和对齐保证的 [`NonNull<[u8]>`][NonNull]。<br>
    ///
    /// The returned block may have a larger size than specified by `layout.size()`, and may or may not have its contents initialized. <br>返回的块的大小可能大于 `layout.size()` 指定的大小，并且可能已初始化或未初始化其内容。<br>
    ///
    /// # Errors
    ///
    /// Returning `Err` indicates that either memory is exhausted or `layout` does not meet allocator's size or alignment constraints. <br>返回 `Err` 表示内存已耗尽，或者 `layout` 不满足分配器的大小或对齐约束。<br>
    ///
    /// Implementations are encouraged to return `Err` on memory exhaustion rather than panicking or aborting, but this is not a strict requirement. <br>鼓励实现在内存耗尽时返回 `Err`，而不是 panic 或中止，但是这不是严格的要求。<br>
    /// (Specifically: it is *legal* to implement this trait atop an underlying native allocation library that aborts on memory exhaustion.) <br>(具体来说：在一个底层的原生分配库上实现此 trait 是 *合法的*，该本地分配库在内存耗尽时中止。)<br>
    ///
    /// Clients wishing to abort computation in response to an allocation error are encouraged to call the [`handle_alloc_error`] function, rather than directly invoking `panic!` or similar. <br>鼓励希望响应分配错误而中止计算的客户端调用 [`handle_alloc_error`] 函数，而不是直接调用 `panic!` 或类似方法。<br>
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Behaves like `allocate`, but also ensures that the returned memory is zero-initialized. <br>行为类似于 `allocate`，但也确保返回的内存被零初始化。<br>
    ///
    /// # Errors
    ///
    /// Returning `Err` indicates that either memory is exhausted or `layout` does not meet allocator's size or alignment constraints. <br>返回 `Err` 表示内存已耗尽，或者 `layout` 不满足分配器的大小或对齐约束。<br>
    ///
    /// Implementations are encouraged to return `Err` on memory exhaustion rather than panicking or aborting, but this is not a strict requirement. <br>鼓励实现在内存耗尽时返回 `Err`，而不是 panic 或中止，但是这不是严格的要求。<br>
    /// (Specifically: it is *legal* to implement this trait atop an underlying native allocation library that aborts on memory exhaustion.) <br>(具体来说：在一个底层的原生分配库上实现此 trait 是 *合法的*，该本地分配库在内存耗尽时中止。)<br>
    ///
    /// Clients wishing to abort computation in response to an allocation error are encouraged to call the [`handle_alloc_error`] function, rather than directly invoking `panic!` or similar. <br>鼓励希望响应分配错误而中止计算的客户端调用 [`handle_alloc_error`] 函数，而不是直接调用 `panic!` 或类似方法。<br>
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SAFETY: `alloc` returns a valid memory block <br>`alloc` 返回有效的内存块<br>
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Deallocates the memory referenced by `ptr`. <br>释放 `ptr` 引用的内存。<br>
    ///
    /// # Safety
    ///
    /// * `ptr` must denote a block of memory [*currently allocated*] via this allocator, and <br>`ptr` 必须通过这个分配器表示一块内存 [*currently allocated*]，并且<br>
    /// * `layout` must [*fit*] that block of memory. <br>`layout` 必须 [*fit*] 那个内存块。<br>
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Attempts to extend the memory block. <br>尝试扩展内存块。<br>
    ///
    /// Returns a new [`NonNull<[u8]>`][NonNull] containing a pointer and the actual size of the allocated memory. <br>返回一个新的 [`NonNull<[u8]>`][NonNull]，其中包含一个指针和分配的内存的实际大小。<br> The pointer is suitable for holding data described by `new_layout`. <br>该指针适用于保存 `new_layout` 描述的数据。<br>
    /// To accomplish this, the allocator may extend the allocation referenced by `ptr` to fit the new layout. <br>为此，分配器可以扩展 `ptr` 引用的分配以适合新的布局。<br>
    ///
    /// If this returns `Ok`, then ownership of the memory block referenced by `ptr` has been transferred to this allocator. <br>如果返回 `Ok`，则 `ptr` 引用的内存块的所有权已转移到此分配器。<br>
    /// Any access to the old `ptr` is Undefined Behavior, even if the allocation was grown in-place. <br>对旧 `ptr` 的任何访问都是未定义行为，即使分配是就地增长的。<br>
    /// The newly returned pointer is the only valid pointer for accessing this memory now. <br>新返回的指针是现在访问这块内存的唯一有效指针。<br>
    ///
    /// If this method returns `Err`, then ownership of the memory block has not been transferred to this allocator, and the contents of the memory block are unaltered. <br>如果此方法返回 `Err`，则该存储块的所有权尚未转移到此分配器，并且该存储块的内容未更改。<br>
    ///
    /// # Safety
    ///
    /// * `ptr` must denote a block of memory [*currently allocated*] via this allocator. <br>`ptr` 必须通过这个分配器来表示一块内存 [*currently allocated*]。<br>
    /// * `old_layout` must [*fit*] that block of memory (The `new_layout` argument need not fit it.). <br>`old_layout` 必须 [*fit*] 该内存块 (`new_layout` 参数不需要适合它。)。<br>
    /// * `new_layout.size()` must be greater than or equal to `old_layout.size()`. <br>`new_layout.size()` 必须大于或等于 `old_layout.size()`。<br>
    ///
    /// Note that `new_layout.align()` need not be the same as `old_layout.align()`. <br>请注意，`new_layout.align()` 不必与 `old_layout.align()` 相同。<br>
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Returns `Err` if the new layout does not meet the allocator's size and alignment constraints of the allocator, or if growing otherwise fails. <br>如果新布局不符合分配器的大小和分配器的对齐约束，或者如果增长失败，则返回 `Err`。<br>
    ///
    /// Implementations are encouraged to return `Err` on memory exhaustion rather than panicking or aborting, but this is not a strict requirement. <br>鼓励实现在内存耗尽时返回 `Err`，而不是 panic 或中止，但是这不是严格的要求。<br>
    /// (Specifically: it is *legal* to implement this trait atop an underlying native allocation library that aborts on memory exhaustion.) <br>(具体来说：在一个底层的原生分配库上实现此 trait 是 *合法的*，该本地分配库在内存耗尽时中止。)<br>
    ///
    /// Clients wishing to abort computation in response to an allocation error are encouraged to call the [`handle_alloc_error`] function, rather than directly invoking `panic!` or similar. <br>鼓励希望响应分配错误而中止计算的客户端调用 [`handle_alloc_error`] 函数，而不是直接调用 `panic!` 或类似方法。<br>
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: because `new_layout.size()` must be greater than or equal to `old_layout.size()`, both the old and new memory allocation are valid for reads and writes for `old_layout.size()` bytes. <br>因为 `new_layout.size()` 必须大于或等于 `old_layout.size()`，所以旧的和新的内存分配对于 `old_layout.size()` 字节的读取和写入均有效。<br>
        // Also, because the old allocation wasn't yet deallocated, it cannot overlap `new_ptr`. <br>另外，由于尚未分配旧分配，因此它不能与 `new_ptr` 重叠。<br>
        // Thus, the call to `copy_nonoverlapping` is safe. <br>因此，调用 `copy_nonoverlapping` 是安全的。<br>
        // The safety contract for `dealloc` must be upheld by the caller. <br>调用者必须遵守 `dealloc` 的安全保证。<br>
        //
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Behaves like `grow`, but also ensures that the new contents are set to zero before being returned. <br>行为类似于 `grow`，但也确保在返回新内容之前将其设置为零。<br>
    ///
    /// The memory block will contain the following contents after a successful call to <br>成功调用后，该存储块将包含以下内容<br>
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` are preserved from the original allocation. <br>字节 `0..old_layout.size()` 从原始分配中保留。<br>
    ///   * Bytes `old_layout.size()..old_size` will either be preserved or zeroed, depending on the allocator implementation. <br>字节 `old_layout.size()..old_size` 将保留还是清零，具体取决于分配器的实现。<br>
    ///   `old_size` refers to the size of the memory block prior to the `grow_zeroed` call, which may be larger than the size that was originally requested when it was allocated. <br>`old_size` 是指 `grow_zeroed` 调用之前的内存块大小，可能比最初分配时请求的大小要大。<br>
    ///   * Bytes `old_size..new_size` are zeroed. <br>字节 `old_size..new_size` 被清零。<br> `new_size` refers to the size of the memory block returned by the `grow_zeroed` call. <br>`new_size` 是指 `grow_zeroed` 调用返回的存储块的大小。<br>
    ///
    /// # Safety
    ///
    /// * `ptr` must denote a block of memory [*currently allocated*] via this allocator. <br>`ptr` 必须通过这个分配器来表示一块内存 [*currently allocated*]。<br>
    /// * `old_layout` must [*fit*] that block of memory (The `new_layout` argument need not fit it.). <br>`old_layout` 必须 [*fit*] 该内存块 (`new_layout` 参数不需要适合它。)。<br>
    /// * `new_layout.size()` must be greater than or equal to `old_layout.size()`. <br>`new_layout.size()` 必须大于或等于 `old_layout.size()`。<br>
    ///
    /// Note that `new_layout.align()` need not be the same as `old_layout.align()`. <br>请注意，`new_layout.align()` 不必与 `old_layout.align()` 相同。<br>
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Returns `Err` if the new layout does not meet the allocator's size and alignment constraints of the allocator, or if growing otherwise fails. <br>如果新布局不符合分配器的大小和分配器的对齐约束，或者如果增长失败，则返回 `Err`。<br>
    ///
    /// Implementations are encouraged to return `Err` on memory exhaustion rather than panicking or aborting, but this is not a strict requirement. <br>鼓励实现在内存耗尽时返回 `Err`，而不是 panic 或中止，但是这不是严格的要求。<br>
    /// (Specifically: it is *legal* to implement this trait atop an underlying native allocation library that aborts on memory exhaustion.) <br>(具体来说：在一个底层的原生分配库上实现此 trait 是 *合法的*，该本地分配库在内存耗尽时中止。)<br>
    ///
    /// Clients wishing to abort computation in response to an allocation error are encouraged to call the [`handle_alloc_error`] function, rather than directly invoking `panic!` or similar. <br>鼓励希望响应分配错误而中止计算的客户端调用 [`handle_alloc_error`] 函数，而不是直接调用 `panic!` 或类似方法。<br>
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SAFETY: because `new_layout.size()` must be greater than or equal to `old_layout.size()`, both the old and new memory allocation are valid for reads and writes for `old_layout.size()` bytes. <br>因为 `new_layout.size()` 必须大于或等于 `old_layout.size()`，所以旧的和新的内存分配对于 `old_layout.size()` 字节的读取和写入均有效。<br>
        // Also, because the old allocation wasn't yet deallocated, it cannot overlap `new_ptr`. <br>另外，由于尚未分配旧分配，因此它不能与 `new_ptr` 重叠。<br>
        // Thus, the call to `copy_nonoverlapping` is safe. <br>因此，调用 `copy_nonoverlapping` 是安全的。<br>
        // The safety contract for `dealloc` must be upheld by the caller. <br>调用者必须遵守 `dealloc` 的安全保证。<br>
        //
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Attempts to shrink the memory block. <br>尝试缩小内存块。<br>
    ///
    /// Returns a new [`NonNull<[u8]>`][NonNull] containing a pointer and the actual size of the allocated memory. <br>返回一个新的 [`NonNull<[u8]>`][NonNull]，其中包含一个指针和分配的内存的实际大小。<br> The pointer is suitable for holding data described by `new_layout`. <br>该指针适用于保存 `new_layout` 描述的数据。<br>
    /// To accomplish this, the allocator may shrink the allocation referenced by `ptr` to fit the new layout. <br>为此，分配器可以缩小 `ptr` 引用的分配以适合新的布局。<br>
    ///
    /// If this returns `Ok`, then ownership of the memory block referenced by `ptr` has been transferred to this allocator. <br>如果返回 `Ok`，则 `ptr` 引用的内存块的所有权已转移到此分配器。<br>
    /// Any access to the old `ptr` is Undefined Behavior, even if the allocation was shrunk in-place. <br>对旧 `ptr` 的任何访问都是未定义行为，即使分配已就地收缩。<br>
    /// The newly returned pointer is the only valid pointer for accessing this memory now. <br>新返回的指针是现在访问这块内存的唯一有效指针。<br>
    ///
    /// If this method returns `Err`, then ownership of the memory block has not been transferred to this allocator, and the contents of the memory block are unaltered. <br>如果此方法返回 `Err`，则该存储块的所有权尚未转移到此分配器，并且该存储块的内容未更改。<br>
    ///
    /// # Safety
    ///
    /// * `ptr` must denote a block of memory [*currently allocated*] via this allocator. <br>`ptr` 必须通过这个分配器来表示一块内存 [*currently allocated*]。<br>
    /// * `old_layout` must [*fit*] that block of memory (The `new_layout` argument need not fit it.). <br>`old_layout` 必须 [*fit*] 该内存块 (`new_layout` 参数不需要适合它。)。<br>
    /// * `new_layout.size()` must be smaller than or equal to `old_layout.size()`. <br>`new_layout.size()` 必须小于或等于 `old_layout.size()`。<br>
    ///
    /// Note that `new_layout.align()` need not be the same as `old_layout.align()`. <br>请注意，`new_layout.align()` 不必与 `old_layout.align()` 相同。<br>
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Returns `Err` if the new layout does not meet the allocator's size and alignment constraints of the allocator, or if shrinking otherwise fails. <br>如果新的布局不符合分配器的大小和分配器的对齐约束，或者缩小失败，则返回 `Err`。<br>
    ///
    /// Implementations are encouraged to return `Err` on memory exhaustion rather than panicking or aborting, but this is not a strict requirement. <br>鼓励实现在内存耗尽时返回 `Err`，而不是 panic 或中止，但是这不是严格的要求。<br>
    /// (Specifically: it is *legal* to implement this trait atop an underlying native allocation library that aborts on memory exhaustion.) <br>(具体来说：在一个底层的原生分配库上实现此 trait 是 *合法的*，该本地分配库在内存耗尽时中止。)<br>
    ///
    /// Clients wishing to abort computation in response to an allocation error are encouraged to call the [`handle_alloc_error`] function, rather than directly invoking `panic!` or similar. <br>鼓励希望响应分配错误而中止计算的客户端调用 [`handle_alloc_error`] 函数，而不是直接调用 `panic!` 或类似方法。<br>
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: because `new_layout.size()` must be lower than or equal to `old_layout.size()`, both the old and new memory allocation are valid for reads and writes for `new_layout.size()` bytes. <br>因为 `new_layout.size()` 必须小于或等于 `old_layout.size()`，所以旧的和新的内存分配对于 `new_layout.size()` 字节的读取和写入均有效。<br>
        // Also, because the old allocation wasn't yet deallocated, it cannot overlap `new_ptr`. <br>另外，由于尚未分配旧分配，因此它不能与 `new_ptr` 重叠。<br>
        // Thus, the call to `copy_nonoverlapping` is safe. <br>因此，调用 `copy_nonoverlapping` 是安全的。<br>
        // The safety contract for `dealloc` must be upheld by the caller. <br>调用者必须遵守 `dealloc` 的安全保证。<br>
        //
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Creates a "by reference" adapter for this instance of `Allocator`. <br>为这个 `Allocator` 实例创建一个 "by reference" 适配器。<br>
    ///
    /// The returned adapter also implements `Allocator` and will simply borrow this. <br>返回的适配器也实现了 `Allocator`，并将简单地借用它。<br>
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SAFETY: the safety contract must be upheld by the caller <br>调用者必须坚持安全保证<br>
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: the safety contract must be upheld by the caller <br>调用者必须坚持安全保证<br>
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: the safety contract must be upheld by the caller <br>调用者必须坚持安全保证<br>
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: the safety contract must be upheld by the caller <br>调用者必须坚持安全保证<br>
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}

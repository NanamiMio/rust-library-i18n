// Seemingly inconsequential code changes to this file can lead to measurable performance impact on compilation times, due at least in part to the fact that the layout code gets called from many instantiations of the various collections, resulting in having to optimize down excess IR multiple times. <br>对该文件看似无关紧要的代码更改可能会对编译时间产生可衡量的性能影响，至少部分原因是布局代码从各种集合的许多实例中调用，导致不得不多次优化多余的 IR。<br>
//
// Your performance intuition is useless. <br>您的性能直觉毫无用处。<br> Run perf. <br>运行性能。<br>
//
//

use crate::cmp;
use crate::error::Error;
use crate::fmt;
use crate::mem;
use crate::ptr::{Alignment, NonNull};

// While this function is used in one place and its implementation could be inlined, the previous attempts to do so made rustc slower: <br>虽然此函数在一个地方使用过，并且可以内联其实现，但是以前的尝试使 rustc 变慢了：<br>
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Layout of a block of memory. <br>一块内存的布局。<br>
///
/// An instance of `Layout` describes a particular layout of memory. <br>`Layout` 的实例描述了特定的内存布局。<br>
/// You build a `Layout` up as an input to give to an allocator. <br>您将 `Layout` 作为输入分配给分配器。<br>
///
/// All layouts have an associated size and a power-of-two alignment. <br>所有布局都具有关联的大小和 2 的幂次对齐。<br>
///
/// (Note that layouts are *not* required to have non-zero size, even though `GlobalAlloc` requires that all memory requests be non-zero in size. <br>(请注意，布局不要求具有非零大小，即使 `GlobalAlloc` 要求所有内存请求的大小为非零。<br>
/// A caller must either ensure that conditions like this are met, use specific allocators with looser requirements, or use the more lenient `Allocator` interface.) <br>调用者必须确保满足这样的条件，使用要求较宽松的特定分配器，或者使用更宽松的 `Allocator` 接口。)<br>
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq, Hash)]
#[lang = "alloc_layout"]
pub struct Layout {
    // size of the requested block of memory, measured in bytes. <br>请求的内存块的大小，以字节为单位。<br>
    size: usize,

    // alignment of the requested block of memory, measured in bytes. <br>请求的内存块的对齐方式，以字节为单位。<br>
    // we ensure that this is always a power-of-two, because API's like `posix_memalign` require it and it is a reasonable constraint to impose on Layout constructors. <br>我们确保这始终是 2 的幂，因为像 `posix_memalign` 这样的 API 都需要这样做，并且强加给 Layout 构造函数是一个合理的约束。<br>
    //
    //
    // (However, we do not analogously require `align >= sizeof(void*)`, even though that is *also* a requirement of `posix_memalign`.) <br>(但是，我们类似地不要求 `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)<br>
    //
    //
    align: Alignment,
}

impl Layout {
    /// Constructs a `Layout` from a given `size` and `align`, or returns `LayoutError` if any of the following conditions are not met: <br>从给定的 `size` 和 `align` 创建 `Layout`，或者如果不满足以下任何条件，则返回 `LayoutError`：<br>
    ///
    /// * `align` must not be zero, <br>`align` 不能为零，<br>
    ///
    /// * `align` must be a power of two, <br>`align` 必须是 2 的幂，<br>
    ///
    /// * `size`, when rounded up to the nearest multiple of `align`, must not overflow isize (i.e., the rounded value must be less than or equal to `isize::MAX`). <br>`size` 向上取整到 `align` 的最接近倍数时，不得溢出 isize (即取整后的值必须小于或等于 `isize::MAX`)。<br>
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout_size_align", since = "1.50.0")]
    #[inline]
    #[rustc_allow_const_fn_unstable(ptr_alignment_type)]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError);
        }

        // SAFETY: just checked that align is a power of two. <br>刚刚检查了 align 是两个的幂。<br>
        Layout::from_size_alignment(size, unsafe { Alignment::new_unchecked(align) })
    }

    #[inline(always)]
    const fn max_size_for_align(align: Alignment) -> usize {
        // (power-of-two implies align != 0.) <br>(2 的幂表示 align=0。)<br>

        // Rounded up size is: <br>舍入后的大小为：<br>
        //   size_rounded_up = (size + align - 1) & !(align - 1);
        //
        // We know from above that align != <br>我们从上面知道 align !=<br> 0.
        // If adding (align - 1) does not overflow, then rounding up will be fine. <br>如果加法 (align-1) 没有溢出，则四舍五入是可以的。<br>
        //
        // Conversely, &-masking with !(align - 1) will subtract off only low-order-bits. <br>相反，&-masking with! (align-1) 将仅减去低位。<br>
        // Thus if overflow occurs with the sum, the &-mask cannot subtract enough to undo that overflow. <br>因此，如果总和发生溢出，则 &-mask cannot 减去足以抵消该溢出。<br>
        //
        //
        // Above implies that checking for summation overflow is both necessary and sufficient. <br>以上暗示检查总和溢出是否必要和充分。<br>
        //
        isize::MAX as usize - (align.as_usize() - 1)
    }

    /// Internal helper constructor to skip revalidating alignment validity. <br>内部辅助构造函数跳过重新验证对齐有效性。<br>
    #[inline]
    const fn from_size_alignment(size: usize, align: Alignment) -> Result<Self, LayoutError> {
        if size > Self::max_size_for_align(align) {
            return Err(LayoutError);
        }

        // SAFETY: Layout::size invariants checked above. <br>上面检查了 Layout::size 不，变体。<br>
        Ok(Layout { size, align })
    }

    /// Creates a layout, bypassing all checks. <br>创建一个布局，绕过所有检查。<br>
    ///
    /// # Safety
    ///
    /// This function is unsafe as it does not verify the preconditions from [`Layout::from_size_align`]. <br>此函数不安全，因为它无法验证 [`Layout::from_size_align`] 的前提条件。<br>
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout_unchecked", since = "1.36.0")]
    #[must_use]
    #[inline]
    #[rustc_allow_const_fn_unstable(ptr_alignment_type)]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SAFETY: the caller is required to uphold the preconditions. <br>调用者必须遵守先决条件。<br>
        unsafe { Layout { size, align: Alignment::new_unchecked(align) } }
    }

    /// The minimum size in bytes for a memory block of this layout. <br>此布局的存储块的最小大小 (以字节为单位)。<br>
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout_size_align", since = "1.50.0")]
    #[must_use]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size
    }

    /// The minimum byte alignment for a memory block of this layout. <br>此布局的存储块的最小字节对齐。<br>
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout_size_align", since = "1.50.0")]
    #[must_use = "this returns the minimum alignment, \
                  without modifying the layout"]
    #[inline]
    #[rustc_allow_const_fn_unstable(ptr_alignment_type)]
    pub const fn align(&self) -> usize {
        self.align.as_usize()
    }

    /// Constructs a `Layout` suitable for holding a value of type `T`. <br>创建一个适合保存 `T` 类型值的 `Layout`。<br>
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[must_use]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SAFETY: if the type is instantiated, rustc already ensures that its layout is valid. <br>如果类型被实例化，rustc 已经确保它的布局是有效的。<br>
        // Use the unchecked constructor to avoid inserting a panicking codepath that needs to be optimized out. <br>使用未检查的构造函数来避免插入需要优化的 panic 代码路径。<br>
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produces layout describing a record that could be used to allocate backing structure for `T` (which could be a trait or other unsized type like a slice). <br>产生描述记录的布局，该记录可用于为 `T` 分配支持结构 (可以是 trait 或其他未定义大小的类型，例如切片)。<br>
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[must_use]
    #[inline]
    pub const fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        // SAFETY: see rationale in `new` for why this is using the unsafe variant <br>请参见 `new` 中的基本原理，了解为什么要使用不安全的变体。<br>
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produces layout describing a record that could be used to allocate backing structure for `T` (which could be a trait or other unsized type like a slice). <br>产生描述记录的布局，该记录可用于为 `T` 分配支持结构 (可以是 trait 或其他未定义大小的类型，例如切片)。<br>
    ///
    /// # Safety
    ///
    /// This function is only safe to call if the following conditions hold: <br>仅在满足以下条件时，此函数才可以安全调用：<br>
    ///
    /// - If `T` is `Sized`, this function is always safe to call. <br>如果 `T` 是 `Sized`，则调用该函数始终是安全的。<br>
    /// - If the unsized tail of `T` is: <br>如果 `T` 的未定义大小的尾部为：<br>
    ///     - a [slice], then the length of the slice tail must be an initialized integer, and the size of the *entire value* (dynamic tail length + statically sized prefix) must fit in `isize`. <br>[slice]，则切片尾部的长度必须是初始化的整数，并且 *entire 值*(动态尾部长度 + 静态大小的前缀) 的大小必须适合 `isize`。<br>
    ///     - a [trait object], then the vtable part of the pointer must point to a valid vtable for the type `T` acquired by an unsizing coercion, and the size of the *entire value* (dynamic tail length + statically sized prefix) must fit in `isize`. <br>一个 [trait 对象][trait object]，那么指针的 vtable 部分必须指向一个由 unsizing coercion 获得的类型 `T` 的有效 vtable，并且整个值 (动态尾部长度 + 静态大小前缀) 的大小必须适合 `isize`。<br>
    ///
    ///     - an (unstable) [extern type], then this function is always safe to call, but may panic or otherwise return the wrong value, as the extern type's layout is not known. <br>一个不稳定的 [外部类型][extern type]，则此函数始终可以安全调用，但可能会 panic 或以其他方式返回错误的值，因为外部类型的布局未知。<br>
    ///     This is the same behavior as [`Layout::for_value`] on a reference to an extern type tail. <br>这与在外部类型尾巴上引用 [`Layout::for_value`] 时的行为相同。<br>
    ///     - otherwise, it is conservatively not allowed to call this function. <br>否则，保守地不允许调用此函数。<br>
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[must_use]
    pub const unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SAFETY: we pass along the prerequisites of these functions to the caller <br>我们将这些函数的先决条件传递给调用者<br>
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        // SAFETY: see rationale in `new` for why this is using the unsafe variant <br>请参见 `new` 中的基本原理，了解为什么要使用不安全的变体。<br>
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Creates a `NonNull` that is dangling, but well-aligned for this Layout. <br>创建一个悬垂的 `NonNull`，但此 Layout 非常适合该 `NonNull`。<br>
    ///
    /// Note that the pointer value may potentially represent a valid pointer, which means this must not be used as a "not yet initialized" sentinel value. <br>请注意，该指针值可能表示一个有效的指针，这意味着不得将其用作 "尚未初始化" 的标记值。<br>
    /// Types that lazily allocate must track initialization by some other means. <br>延迟分配的类型必须通过其他某种方式来跟踪初始化。<br>
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[must_use]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SAFETY: align is guaranteed to be non-zero <br>align 保证为非零<br>
        unsafe { NonNull::new_unchecked(crate::ptr::invalid_mut::<u8>(self.align())) }
    }

    /// Creates a layout describing the record that can hold a value of the same layout as `self`, but that also is aligned to alignment `align` (measured in bytes). <br>创建一个描述记录的布局，该记录可以保留与 `self` 相同的布局值，但也与对齐方式 `align` 对齐 (以字节为单位)。<br>
    ///
    ///
    /// If `self` already meets the prescribed alignment, then returns `self`. <br>如果 `self` 已经满足规定的对齐方式，则返回 `self`。<br>
    ///
    /// Note that this method does not add any padding to the overall size, regardless of whether the returned layout has a different alignment. <br>请注意，无论返回的布局是否具有不同的对齐方式，此方法都不会在整体大小上添加任何填充。<br>
    /// In other words, if `K` has size 16, `K.align_to(32)` will *still* have size 16. <br>换句话说，如果 `K` 的大小为 16，则 `K.align_to(32)`*仍* 的大小为 16。<br>
    ///
    /// Returns an error if the combination of `self.size()` and the given `align` violates the conditions listed in [`Layout::from_size_align`]. <br>如果 `self.size()` 和给定的 `align` 的组合违反 [`Layout::from_size_align`] 中列出的条件，则返回错误。<br>
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Returns the amount of padding we must insert after `self` to ensure that the following address will satisfy `align` (measured in bytes). <br>返回必须在 `self` 之后插入的填充量，以确保以下地址满足 `align` (以字节为单位)。<br>
    ///
    /// e.g., if `self.size()` is 9, then `self.padding_needed_for(4)` returns 3, because that is the minimum number of bytes of padding required to get a 4-aligned address (assuming that the corresponding memory block starts at a 4-aligned address). <br>例如，如果 `self.size()` 为 9，则 `self.padding_needed_for(4)` 返回 3，因为这是获得 4 对齐地址所需的最小填充字节数 (假设相应的存储块从 4 对齐地址开始)。<br>
    ///
    ///
    /// The return value of this function has no meaning if `align` is not a power-of-two. <br>如果 `align` 不是 2 的幂，则此函数的返回值没有意义。<br>
    ///
    /// Note that the utility of the returned value requires `align` to be less than or equal to the alignment of the starting address for the whole allocated block of memory. <br>注意，返回值的实用程序要求 `align` 小于或等于整个分配的内存块的起始地址的对齐方式。<br> One way to satisfy this constraint is to ensure `align <= self.align()`. <br>满足此约束的一种方法是确保 `align <= self.align()`。<br>
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[must_use = "this returns the padding needed, \
                  without modifying the `Layout`"]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Rounded up value is: <br>向上取整的值为：<br>
        //   len_rounded_up = (len + align - 1) & !(align - 1);
        // and then we return the padding difference: `len_rounded_up - len`. <br>然后我们返回填充差异: `len_rounded_up - len`。<br>
        //
        // We use modular arithmetic throughout: <br>我们在整个过程中都使用模块化的算法：<br>
        //
        // 1. align is guaranteed to be > 0, so align - 1 is always valid. <br>align 保证 > 0，因此 align - 1 始终有效。<br>
        //
        // 2.
        // `len + align - 1` can overflow by at most `align - 1`, so the &-mask with `!(align - 1)` will ensure that in the case of overflow, `len_rounded_up` will itself be <br>`len + align - 1` 最多可以溢出 `align - 1`，所以 &-mask 和 `!(align - 1)` 将确保在溢出的情况下，`len_rounded_up` 本身是<br> 0.
        //
        //    Thus the returned padding, when added to `len`, yields 0, which trivially satisfies the alignment `align`. <br>因此，当返回的填充添加到 `len` 时，将产生 0，该填充简单地满足了 `align` 的对齐方式。<br>
        //
        // (Of course, attempts to allocate blocks of memory whose size and padding overflow in the above manner should cause the allocator to yield an error anyway.) <br>(当然，尝试以上述方式分配其大小和填充溢出的内存块无论如何都会导致分配器产生错误。)<br>
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Creates a layout by rounding the size of this layout up to a multiple of the layout's alignment. <br>通过将布局的大小四舍五入到布局的对齐方式的倍数来创建布局。<br>
    ///
    ///
    /// This is equivalent to adding the result of `padding_needed_for` to the layout's current size. <br>这等效于将 `padding_needed_for` 的结果添加到布局的当前大小。<br>
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[must_use = "this returns a new `Layout`, \
                  without modifying the original"]
    #[inline]
    pub const fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // This cannot overflow. <br>这不会溢出。<br> Quoting from the invariant of Layout: <br>引用布局的不变量：<br>
        // > `size`, when rounded up to the nearest multiple of `align`, <br>`size`，当四舍五入到最接近的 `align` 倍数时，<br>
        // > must not overflow isize (i.e., the rounded value must be <br>不得溢出 isize (即，四舍五入的值必须是<br>
        // > less than or equal to `isize::MAX`) <br>小于或等于 `isize::MAX`)<br>
        let new_size = self.size() + pad;

        // SAFETY: padded size is guaranteed to not exceed `isize::MAX`. <br>填充大小保证不超过 `isize::MAX`。<br>
        unsafe { Layout::from_size_align_unchecked(new_size, self.align()) }
    }

    /// Creates a layout describing the record for `n` instances of `self`, with a suitable amount of padding between each to ensure that each instance is given its requested size and alignment. <br>创建一个布局，以描述 `self` 的 `n` 实例的记录，并在每个实例之间使用适当的填充量，以确保为每个实例提供其请求的大小和对齐方式。<br>
    /// On success, returns `(k, offs)` where `k` is the layout of the array and `offs` is the distance between the start of each element in the array. <br>成功后，返回 `(k, offs)`，其中 `k` 是数组的布局，`offs` 是数组中每个元素的起点之间的距离。<br>
    ///
    /// On arithmetic overflow, returns `LayoutError`. <br>算术溢出时，返回 `LayoutError`。<br>
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // This cannot overflow. <br>这不会溢出。<br> Quoting from the invariant of Layout: <br>引用布局的不变量：<br>
        // > `size`, when rounded up to the nearest multiple of `align`, <br>`size`，当四舍五入到最接近的 `align` 倍数时，<br>
        // > must not overflow isize (i.e., the rounded value must be <br>不得溢出 isize (即，四舍五入的值必须是<br>
        // > less than or equal to `isize::MAX`) <br>小于或等于 `isize::MAX`)<br>
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError)?;

        // The safe constructor is called here to enforce the isize size limit. <br>此处调用安全构造函数以强制执行 isize 大小限制。<br>
        let layout = Layout::from_size_alignment(alloc_size, self.align)?;
        Ok((layout, padded_size))
    }

    /// Creates a layout describing the record for `self` followed by `next`, including any necessary padding to ensure that `next` will be properly aligned, but *no trailing padding*. <br>创建一个布局，描述 `self` 的记录，后跟 `next` 的记录，包括确保 `next` 正确对齐但必须填充 *no trailing* 的所有必要填充。<br>
    ///
    /// In order to match C representation layout `repr(C)`, you should call `pad_to_align` after extending the layout with all fields. <br>为了匹配 C 表示形式的布局 `repr(C)`，应在扩展了所有字段的布局后调用 `pad_to_align`。<br>
    /// (There is no way to match the default Rust representation layout `repr(Rust)`, as it is unspecified.) <br>(由于未指定，因此无法匹配默认的 Rust 表示形式布局 `repr(Rust)`。)<br>
    ///
    /// Note that the alignment of the resulting layout will be the maximum of those of `self` and `next`, in order to ensure alignment of both parts. <br>请注意，最终布局的对齐方式将是 `self` 和 `next` 的最大对齐方式，以确保两个部分的对齐方式。<br>
    ///
    /// Returns `Ok((k, offset))`, where `k` is layout of the concatenated record and `offset` is the relative location, in bytes, of the start of the `next` embedded within the concatenated record (assuming that the record itself starts at offset 0). <br>返回 `Ok((k, offset))`，其中 `k` 是串联记录的布局，`offset` 是嵌入在串联记录中的 `next` 起始位置的相对位置 (以字节为单位) (假定记录本身从偏移量 0 开始)。<br>
    ///
    ///
    /// On arithmetic overflow, returns `LayoutError`. <br>算术溢出时，返回 `LayoutError`。<br>
    ///
    /// # Examples
    ///
    /// To calculate the layout of a `#[repr(C)]` structure and the offsets of the fields from its fields' layouts: <br>要计算 `#[repr(C)]` 结构体的布局以及字段与其字段布局的偏移量，请执行以下操作：<br>
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Remember to finalize with `pad_to_align`! <br>记得用 `pad_to_align` 来完成！<br>
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // test that it works <br>测试它是否有效<br>
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align, next.align);
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError)?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError)?;

        // The safe constructor is called here to enforce the isize size limit. <br>此处调用安全构造函数以强制执行 isize 大小限制。<br>
        let layout = Layout::from_size_alignment(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Creates a layout describing the record for `n` instances of `self`, with no padding between each instance. <br>创建一个布局，该布局描述 `self` 的 `n` 实例的记录，每个实例之间没有填充。<br>
    ///
    /// Note that, unlike `repeat`, `repeat_packed` does not guarantee that the repeated instances of `self` will be properly aligned, even if a given instance of `self` is properly aligned. <br>请注意，与 `repeat` 不同，即使给定的 `self` 实例正确对齐，`repeat_packed` 也不能保证 `self` 的重复实例将正确对齐。<br>
    /// In other words, if the layout returned by `repeat_packed` is used to allocate an array, it is not guaranteed that all elements in the array will be properly aligned. <br>换句话说，如果使用 `repeat_packed` 返回的布局来分配数组，则不能保证数组中的所有元素都将正确对齐。<br>
    ///
    /// On arithmetic overflow, returns `LayoutError`. <br>算术溢出时，返回 `LayoutError`。<br>
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError)?;
        // The safe constructor is called here to enforce the isize size limit. <br>此处调用安全构造函数以强制执行 isize 大小限制。<br>
        Layout::from_size_alignment(size, self.align)
    }

    /// Creates a layout describing the record for `self` followed by `next` with no additional padding between the two. <br>创建一个布局，描述 `self` 和 `next` 的记录，两者之间没有其他填充。<br>
    /// Since no padding is inserted, the alignment of `next` is irrelevant, and is not incorporated *at all* into the resulting layout. <br>由于没有插入填充，因此 `next` 的对齐方式是无关紧要的，并且不会将 *at all* 合并到结果布局中。<br>
    ///
    ///
    /// On arithmetic overflow, returns `LayoutError`. <br>算术溢出时，返回 `LayoutError`。<br>
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError)?;
        // The safe constructor is called here to enforce the isize size limit. <br>此处调用安全构造函数以强制执行 isize 大小限制。<br>
        Layout::from_size_alignment(new_size, self.align)
    }

    /// Creates a layout describing the record for a `[T; n]`. <br>创建一个布局，描述 `[T; n]` 的记录。<br>
    ///
    /// On arithmetic overflow or when the total size would exceed `isize::MAX`, returns `LayoutError`. <br>在算术溢出或总大小超过 `isize::MAX` 时，返回 `LayoutError`。<br>
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn array<T>(n: usize) -> Result<Self, LayoutError> {
        // Reduce the amount of code we need to monomorphize per `T`. <br>减少我们需要对每个 `T` 进行单态化的代码量。<br>
        return inner(mem::size_of::<T>(), Alignment::of::<T>(), n);

        #[inline]
        const fn inner(
            element_size: usize,
            align: Alignment,
            n: usize,
        ) -> Result<Layout, LayoutError> {
            // We need to check two things about the size: <br>我们需要检查关于大小的两件事:<br>
            //  - That the total size won't overflow a `usize`, and <br>总大小不会溢出 `usize`，并且<br>
            //  - That the total size still fits in an `isize`. <br>总大小仍然适合 `isize`。<br>
            // By using division we can check them both with a single threshold. <br>通过使用除法，我们可以用一个阈值检查它们。<br>
            // That'd usually be a bad idea, but thankfully here the element size and alignment are constants, so the compiler will fold all of it. <br>这通常是个坏主意，但幸运的是，这里的元素大小和对齐方式是常量，所以编译器会折叠所有这些。<br>
            //
            if element_size != 0 && n > Layout::max_size_for_align(align) / element_size {
                return Err(LayoutError);
            }

            let array_size = element_size * n;

            // SAFETY: We just checked above that the `array_size` will not exceed `isize::MAX` even when rounded up to the alignment. <br>我们刚刚在上面检查过，即使四舍五入到对齐，`array_size` 也不会超过 `isize::MAX`。<br>
            //
            // And `Alignment` guarantees it's a power of two. <br>`Alignment` 保证它是二的幂。<br>
            unsafe { Ok(Layout::from_size_align_unchecked(array_size, align.as_usize())) }
        }
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[deprecated(
    since = "1.52.0",
    note = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// The parameters given to `Layout::from_size_align` or some other `Layout` constructor do not satisfy its documented constraints. <br>给 `Layout::from_size_align` 或其他 `Layout` 构造函数的参数不满足其记录的约束。<br>
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[non_exhaustive]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError;

#[stable(feature = "alloc_layout", since = "1.28.0")]
impl Error for LayoutError {}

// (we need this for downstream impl of trait Error) <br>(对于 trait 错误的下游隐含我们需要此功能)<br>
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}

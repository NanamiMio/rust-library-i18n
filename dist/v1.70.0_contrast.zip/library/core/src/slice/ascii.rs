//! Operations on ASCII `[u8]`. <br>在 ASCII `[u8]` 上的操作。<br>

use crate::ascii;
use crate::fmt::{self, Write};
use crate::iter;
use crate::mem;
use crate::ops;

#[cfg(not(test))]
impl [u8] {
    /// Checks if all bytes in this slice are within the ASCII range. <br>检查此切片中的所有字节是否都在 ASCII 范围内。<br>
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[must_use]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Checks that two slices are an ASCII case-insensitive match. <br>检查两个片是否是 ASCII 大小写不敏感的匹配项。<br>
    ///
    /// Same as `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, but without allocating and copying temporaries. <br>与 `to_ascii_lowercase(a) == to_ascii_lowercase(b)` 相同，但不分配和复制临时文件。<br>
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[must_use]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && iter::zip(self, other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Converts this slice to its ASCII upper case equivalent in-place. <br>将该切片原位转换为其 ASCII 大写形式。<br>
    ///
    /// ASCII letters 'a' to 'z' are mapped to 'A' to 'Z', but non-ASCII letters are unchanged. <br>ASCII 字母 'a' 到 'z' 映射到 'A' 到 'Z'，但是非 ASCII 字母不变。<br>
    ///
    /// To return a new uppercased value without modifying the existing one, use [`to_ascii_uppercase`]. <br>要返回新的大写值而不修改现有值，请使用 [`to_ascii_uppercase`]。<br>
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Converts this slice to its ASCII lower case equivalent in-place. <br>将该切片原位转换为其 ASCII 小写等效项。<br>
    ///
    /// ASCII letters 'A' to 'Z' are mapped to 'a' to 'z', but non-ASCII letters are unchanged. <br>ASCII 字母 'A' 到 'Z' 映射到 'a' 到 'z'，但是非 ASCII 字母不变。<br>
    ///
    /// To return a new lowercased value without modifying the existing one, use [`to_ascii_lowercase`]. <br>要返回新的小写值而不修改现有值，请使用 [`to_ascii_lowercase`]。<br>
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }

    /// Returns an iterator that produces an escaped version of this slice, treating it as an ASCII string. <br>返回一个迭代器，该迭代器产生此转义版本的一个 ASCII 字符串，将其视为一个 ASCII 字符串。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    ///
    /// let s = b"0\t\r\n'\"\\\x9d";
    /// let escaped = s.escape_ascii().to_string();
    /// assert_eq!(escaped, "0\\t\\r\\n\\'\\\"\\\\\\x9d");
    /// ```
    #[must_use = "this returns the escaped bytes as an iterator, \
                  without modifying the original"]
    #[stable(feature = "inherent_ascii_escape", since = "1.60.0")]
    pub fn escape_ascii(&self) -> EscapeAscii<'_> {
        EscapeAscii { inner: self.iter().flat_map(EscapeByte) }
    }

    /// Returns a byte slice with leading ASCII whitespace bytes removed. <br>返回删除了前导 ASCII 空白字节的字节切片。<br>
    ///
    /// 'Whitespace' refers to the definition used by `u8::is_ascii_whitespace`. <br>'Whitespace' 是指 `u8::is_ascii_whitespace` 使用的定义。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(byte_slice_trim_ascii)]
    ///
    /// assert_eq!(b" \t hello world\n".trim_ascii_start(), b"hello world\n");
    /// assert_eq!(b"  ".trim_ascii_start(), b"");
    /// assert_eq!(b"".trim_ascii_start(), b"");
    /// ```
    #[unstable(feature = "byte_slice_trim_ascii", issue = "94035")]
    pub const fn trim_ascii_start(&self) -> &[u8] {
        let mut bytes = self;
        // Note: A pattern matching based approach (instead of indexing) allows making the function const. <br>基于模式匹配的方法 (而不是索引) 允许将函数设为 const。<br>
        //
        while let [first, rest @ ..] = bytes {
            if first.is_ascii_whitespace() {
                bytes = rest;
            } else {
                break;
            }
        }
        bytes
    }

    /// Returns a byte slice with trailing ASCII whitespace bytes removed. <br>返回删除了尾随 ASCII 空白字节的字节切片。<br>
    ///
    /// 'Whitespace' refers to the definition used by `u8::is_ascii_whitespace`. <br>'Whitespace' 是指 `u8::is_ascii_whitespace` 使用的定义。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(byte_slice_trim_ascii)]
    ///
    /// assert_eq!(b"\r hello world\n ".trim_ascii_end(), b"\r hello world");
    /// assert_eq!(b"  ".trim_ascii_end(), b"");
    /// assert_eq!(b"".trim_ascii_end(), b"");
    /// ```
    #[unstable(feature = "byte_slice_trim_ascii", issue = "94035")]
    pub const fn trim_ascii_end(&self) -> &[u8] {
        let mut bytes = self;
        // Note: A pattern matching based approach (instead of indexing) allows making the function const. <br>基于模式匹配的方法 (而不是索引) 允许将函数设为 const。<br>
        //
        while let [rest @ .., last] = bytes {
            if last.is_ascii_whitespace() {
                bytes = rest;
            } else {
                break;
            }
        }
        bytes
    }

    /// Returns a byte slice with leading and trailing ASCII whitespace bytes removed. <br>返回删除了前导和尾随 ASCII 空白字节的字节切片。<br>
    ///
    ///
    /// 'Whitespace' refers to the definition used by `u8::is_ascii_whitespace`. <br>'Whitespace' 是指 `u8::is_ascii_whitespace` 使用的定义。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(byte_slice_trim_ascii)]
    ///
    /// assert_eq!(b"\r hello world\n ".trim_ascii(), b"hello world");
    /// assert_eq!(b"  ".trim_ascii(), b"");
    /// assert_eq!(b"".trim_ascii(), b"");
    /// ```
    ///
    #[unstable(feature = "byte_slice_trim_ascii", issue = "94035")]
    pub const fn trim_ascii(&self) -> &[u8] {
        self.trim_ascii_start().trim_ascii_end()
    }
}

impl_fn_for_zst! {
    #[derive(Clone)]
    struct EscapeByte impl Fn = |byte: &u8| -> ascii::EscapeDefault {
        ascii::escape_default(*byte)
    };
}

/// An iterator over the escaped version of a byte slice. <br>一个字节的转义版本的迭代器。<br>
///
/// This `struct` is created by the [`slice::escape_ascii`] method. <br>这个 `struct` 是由 [`slice::escape_ascii`] 方法创建的。<br>
/// See its documentation for more information. <br>有关更多信息，请参见其文档。<br>
#[stable(feature = "inherent_ascii_escape", since = "1.60.0")]
#[derive(Clone)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub struct EscapeAscii<'a> {
    inner: iter::FlatMap<super::Iter<'a, u8>, ascii::EscapeDefault, EscapeByte>,
}

#[stable(feature = "inherent_ascii_escape", since = "1.60.0")]
impl<'a> iter::Iterator for EscapeAscii<'a> {
    type Item = u8;
    #[inline]
    fn next(&mut self) -> Option<u8> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
    #[inline]
    fn try_fold<Acc, Fold, R>(&mut self, init: Acc, fold: Fold) -> R
    where
        Fold: FnMut(Acc, Self::Item) -> R,
        R: ops::Try<Output = Acc>,
    {
        self.inner.try_fold(init, fold)
    }
    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        self.inner.fold(init, fold)
    }
    #[inline]
    fn last(mut self) -> Option<u8> {
        self.next_back()
    }
}

#[stable(feature = "inherent_ascii_escape", since = "1.60.0")]
impl<'a> iter::DoubleEndedIterator for EscapeAscii<'a> {
    fn next_back(&mut self) -> Option<u8> {
        self.inner.next_back()
    }
}
#[stable(feature = "inherent_ascii_escape", since = "1.60.0")]
impl<'a> iter::FusedIterator for EscapeAscii<'a> {}
#[stable(feature = "inherent_ascii_escape", since = "1.60.0")]
impl<'a> fmt::Display for EscapeAscii<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.clone().try_for_each(|b| f.write_char(b as char))
    }
}
#[stable(feature = "inherent_ascii_escape", since = "1.60.0")]
impl<'a> fmt::Debug for EscapeAscii<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("EscapeAscii").finish_non_exhaustive()
    }
}

/// Returns `true` if any byte in the word `v` is nonascii (>= 128). <br>如果单词 `v` 中的任何字节为 nonascii (>=128)，则返回 `true`。<br>
/// Snarfed from `../str/mod.rs`, which does something similar for utf8 validation. <br>来自 `../str/mod.rs`，它对 utf8 验证执行类似的操作。<br>
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = usize::repeat_u8(0x80);
    (NONASCII_MASK & v) != 0
}

/// Optimized ASCII test that will use usize-at-a-time operations instead of byte-at-a-time operations (when possible). <br>优化的 ASCII 测试，将使用每次使用一次的操作，而不是一次使用字节的操作 (如果可能)。<br>
///
/// The algorithm we use here is pretty simple. <br>我们在这里使用的算法非常简单。<br> If `s` is too short, we just check each byte and be done with it. <br>如果 `s` 太短，我们只检查每个字节并完成它。<br> Otherwise:
///
/// - Read the first word with an unaligned load. <br>读取未对齐负载的第一个单词。。<br>
/// - Align the pointer, read subsequent words until end with aligned loads. <br>对齐指针，读取后续单词，直到对齐负载结束。<br>
/// - Read the last `usize` from `s` with an unaligned load. <br>从 `s` 读取未装载的最后一个 `usize`。<br>
///
/// If any of these loads produces something for which `contains_nonascii` (above) returns true, then we know the answer is false. <br>如果这些负载中的任何一个产生了 `contains_nonascii` (above) 返回 true 的值，则我们知道答案为 false。<br>
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // If we wouldn't gain anything from the word-at-a-time implementation, fall back to a scalar loop. <br>如果我们不能从一次单词的实现中获得任何收益，请回到标量循环。<br>
    //
    // We also do this for architectures where `size_of::<usize>()` isn't sufficient alignment for `usize`, because it's a weird edge case. <br>我们还针对 `size_of::<usize>()` 不足以与 `usize` 对齐的体系结构执行此操作，因为这是一种奇怪的 edge 情况。<br>
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // We always read the first word unaligned, which means `align_offset` is <br>我们总是读第一个单词 unaligned，这意味着 `align_offset` 是<br>
    // 0, we'd read the same value again for the aligned read. <br>0，对于对齐的读取，我们将再次读取相同的值。<br>
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SAFETY: We verify `len < USIZE_SIZE` above. <br>我们在上面验证 `len < USIZE_SIZE`。<br>
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // We checked this above, somewhat implicitly. <br>我们在上面对此进行了某种程度的隐式检查。<br>
    // Note that `offset_to_aligned` is either `align_offset` or `USIZE_SIZE`, both of are explicitly checked above. <br>请注意，`offset_to_aligned` 是 `align_offset` 或 `USIZE_SIZE`，以上均已明确检查了两者。<br>
    //
    debug_assert!(offset_to_aligned <= len);

    // SAFETY: word_ptr is the (properly aligned) usize ptr we use to read the middle chunk of the slice. <br>word_ptr 是 (正确对齐的) usize ptr，用于读取切片的中间块。<br>
    //
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` is the byte index of `word_ptr`, used for loop end checks. <br>`byte_pos` 是 `word_ptr` 的字节索引，用于循环结束检查。<br>
    let mut byte_pos = offset_to_aligned;

    // Paranoia check about alignment, since we're about to do a bunch of unaligned loads. <br>偏执狂会检查对齐情况，因为我们将要进行一堆未对齐的负载。<br>
    // In practice this should be impossible barring a bug in `align_offset` though. <br>实际上，除非有 `align_offset` 中的错误，否则这应该是不可能的。<br>
    //
    debug_assert_eq!(word_ptr.addr() % mem::align_of::<usize>(), 0);

    // Read subsequent words until the last aligned word, excluding the last aligned word by itself to be done in tail check later, to ensure that tail is always one `usize` at most to extra branch `byte_pos == len`. <br>读取后续的单词，直到最后一个对齐的单词为止 (不包括最后一个对齐的单词本身)，以便稍后在尾部检查中完成，以确保尾部对于额外的分支 `byte_pos == len` 始终最多为一个 `usize`。<br>
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sanity check that the read is in bounds <br>完好无损的检查，以确保读取的范围<br>
            (word_ptr.addr() + USIZE_SIZE) <= start.addr().wrapping_add(len) &&
            // And that our assumptions about `byte_pos` hold. <br>并且我们关于 `byte_pos` 的假设成立。<br>
            (word_ptr.addr() - start.addr()) == byte_pos
        );

        // SAFETY: We know `word_ptr` is properly aligned (because of `align_offset`), and we know that we have enough bytes between `word_ptr` and the end <br>我们知道 `word_ptr` 正确对齐 (因为 `align_offset`)，并且我们知道 `word_ptr` 和末尾之间有足够的字节<br>
        //
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SAFETY: We know that `byte_pos <= len - USIZE_SIZE`, which means that after this `add`, `word_ptr` will be at most one-past-the-end. <br>我们知道 `byte_pos <= len - USIZE_SIZE`，这意味着在此 `add` 之后，`word_ptr` 最多只能是最后一个。<br>
        //
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Sanity check to ensure there really is only one `usize` left. <br>进行健全性检查，确保仅剩 `usize` 个。<br>
    // This should be guaranteed by our loop condition. <br>这应该由我们的循环条件来保证。<br>
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SAFETY: This relies on `len >= USIZE_SIZE`, which we check at the start. <br>这依赖于 `len >= USIZE_SIZE`，我们将在开始时对其进行检查。<br>
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}

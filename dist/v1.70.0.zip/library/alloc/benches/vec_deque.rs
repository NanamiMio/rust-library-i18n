use core::iter::Iterator;
use std::{
    collections::{vec_deque, VecDeque},
    mem,
};
use test::{black_box, Bencher};

#[bench]
fn bench_new(b: &mut Bencher) {
    b.iter(|| {
        let ring: VecDeque<i32> = VecDeque::new();
        black_box(ring);
    })
}

#[bench]
fn bench_grow_1025(b: &mut Bencher) {
    b.iter(|| {
        let mut deq = VecDeque::new();
        for i in 0..1025 {
            deq.push_front(i);
        }
        black_box(deq);
    })
}

#[bench]
fn bench_iter_1000(b: &mut Bencher) {
    let ring: VecDeque<_> = (0..1000).collect();

    b.iter(|| {
        let mut sum = 0;
        for &i in &ring {
            sum += i;
        }
        black_box(sum);
    })
}

#[bench]
fn bench_mut_iter_1000(b: &mut Bencher) {
    let mut ring: VecDeque<_> = (0..1000).collect();

    b.iter(|| {
        let mut sum = 0;
        for i in &mut ring {
            sum += *i;
        }
        black_box(sum);
    })
}

#[bench]
fn bench_try_fold(b: &mut Bencher) {
    let ring: VecDeque<_> = (0..1000).collect();

    b.iter(|| black_box(ring.iter().try_fold(0, |a, b| Some(a + b))))
}

/// 执行内存记录以在迭代之间重用 Vec 的缓冲区。
/// `setup` 不得修改其参数的长度或容量。`g` 不得移出其参数。
fn into_iter_helper<
    T: Copy,
    F: FnOnce(&mut VecDeque<T>),
    G: FnOnce(&mut vec_deque::IntoIter<T>),
>(
    v: &mut Vec<T>,
    setup: F,
    g: G,
) {
    let ptr = v.as_mut_ptr();
    let len = v.len();
    // 确保 vec 已满，以确保双端队列中的任何包装都不会访问未初始化的内存。
    //
    assert_eq!(v.len(), v.capacity());

    let mut deque = VecDeque::from(mem::take(v));
    setup(&mut deque);

    let mut it = deque.into_iter();
    g(&mut it);

    mem::forget(it);

    // SAFETY: 提供的函数不允许修改分配，因此缓冲区仍然存在。
    // 由于上述断言，len 和 capacity 是准确的。
    // 缓冲区中的所有元素仍然有效，因为 `T: Copy` 表示 `T: !Drop`。
    mem::forget(mem::replace(v, unsafe { Vec::from_raw_parts(ptr, len, len) }));
}

#[bench]
fn bench_into_iter(b: &mut Bencher) {
    let len = 1024;
    // 我们在每次运行中重复使用这个分配
    let mut vec: Vec<usize> = (0..len).collect();
    vec.shrink_to_fit();

    b.iter(|| {
        let mut sum = 0;
        into_iter_helper(
            &mut vec,
            |_| {},
            |it| {
                for i in it {
                    sum += i;
                }
            },
        );
        black_box(sum);

        let mut sum = 0;
        // 旋转一个完整的双端队列不会移动任何内存。
        into_iter_helper(
            &mut vec,
            |d| d.rotate_left(len / 2),
            |it| {
                for i in it {
                    sum += i;
                }
            },
        );
        black_box(sum);
    });
}

#[bench]
fn bench_into_iter_fold(b: &mut Bencher) {
    let len = 1024;

    // 因为 `fold` 拥有迭代器的所有权，我们无法阻止它丢弃内存，所以我们必须硬着头皮为每次迭代重新分配。
    //
    //
    //
    b.iter(|| {
        let deque: VecDeque<usize> = (0..len).collect();
        assert_eq!(deque.len(), deque.capacity());
        let sum = deque.into_iter().fold(0, |a, b| a + b);
        black_box(sum);

        // 旋转一个完整的双端队列不会移动任何内存。
        let mut deque: VecDeque<usize> = (0..len).collect();
        assert_eq!(deque.len(), deque.capacity());
        deque.rotate_left(len / 2);
        let sum = deque.into_iter().fold(0, |a, b| a + b);
        black_box(sum);
    });
}

#[bench]
fn bench_into_iter_try_fold(b: &mut Bencher) {
    let len = 1024;
    // 我们在每次运行中重复使用这个分配
    let mut vec: Vec<usize> = (0..len).collect();
    vec.shrink_to_fit();

    // Iterator::any 在引擎盖下使用 Iterator::try_fold
    b.iter(|| {
        let mut b = false;
        into_iter_helper(&mut vec, |_| {}, |it| b = it.any(|i| i == len - 1));
        black_box(b);

        into_iter_helper(&mut vec, |d| d.rotate_left(len / 2), |it| b = it.any(|i| i == len - 1));
        black_box(b);
    });
}

#[bench]
fn bench_into_iter_next_chunk(b: &mut Bencher) {
    let len = 1024;
    // 我们在每次运行中重复使用这个分配
    let mut vec: Vec<usize> = (0..len).collect();
    vec.shrink_to_fit();

    b.iter(|| {
        let mut buf = [0; 64];
        into_iter_helper(
            &mut vec,
            |_| {},
            |it| {
                while let Ok(a) = it.next_chunk() {
                    buf = a;
                }
            },
        );
        black_box(buf);

        into_iter_helper(
            &mut vec,
            |d| d.rotate_left(len / 2),
            |it| {
                while let Ok(a) = it.next_chunk() {
                    buf = a;
                }
            },
        );
        black_box(buf);
    });
}

#[bench]
fn bench_from_array_1000(b: &mut Bencher) {
    const N: usize = 1000;
    let mut array: [usize; N] = [0; N];

    for i in 0..N {
        array[i] = i;
    }

    b.iter(|| {
        let deq: VecDeque<_> = array.into();
        black_box(deq);
    })
}

#[bench]
fn bench_extend_bytes(b: &mut Bencher) {
    let mut ring: VecDeque<u8> = VecDeque::with_capacity(1000);
    let input: &[u8] = &[128; 512];

    b.iter(|| {
        ring.clear();
        ring.extend(black_box(input));
    });
}

#[bench]
fn bench_extend_vec(b: &mut Bencher) {
    let mut ring: VecDeque<u8> = VecDeque::with_capacity(1000);
    let input = vec![128; 512];

    b.iter(|| {
        ring.clear();

        let input = input.clone();
        ring.extend(black_box(input));
    });
}

#[bench]
fn bench_extend_trustedlen(b: &mut Bencher) {
    let mut ring: VecDeque<u16> = VecDeque::with_capacity(1000);

    b.iter(|| {
        ring.clear();
        ring.extend(black_box(0..512));
    });
}

#[bench]
fn bench_extend_chained_trustedlen(b: &mut Bencher) {
    let mut ring: VecDeque<u16> = VecDeque::with_capacity(1000);

    b.iter(|| {
        ring.clear();
        ring.extend(black_box((0..256).chain(768..1024)));
    });
}

#[bench]
fn bench_extend_chained_bytes(b: &mut Bencher) {
    let mut ring: VecDeque<u16> = VecDeque::with_capacity(1000);
    let input1: &[u16] = &[128; 256];
    let input2: &[u16] = &[255; 256];

    b.iter(|| {
        ring.clear();
        ring.extend(black_box(input1.iter().chain(input2.iter())));
    });
}

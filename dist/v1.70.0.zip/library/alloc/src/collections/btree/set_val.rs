/// 内部 `BTreeSet` 值的零大小类型 (ZST)。
/// 代替 `()` 用于区分:
/// * `BTreeMap<T, ()>` (可能的用户自定义 map)
/// * `BTreeMap<T, SetValZST>` (内部集合表示)
#[derive(Debug, Eq, PartialEq, Ord, PartialOrd, Hash, Clone, Default)]
pub struct SetValZST;

/// 用于区分 `BTreeMap` 和 `BTreeSet` 值的 trait。
/// 仅对 `SetValZST` 类型返回 `true`，对所有其他类型返回 `false` (一揽子实现)。
/// `TypeId` 需要一个 `'static` 生命周期，使用这个 trait 可以避免这个限制。
///
/// [`TypeId`]: std::any::TypeId
pub trait IsSetVal {
    fn is_set_val() -> bool;
}

// 一揽子实现
impl<V> IsSetVal for V {
    default fn is_set_val() -> bool {
        false
    }
}

// Specialization
impl IsSetVal for SetValZST {
    fn is_set_val() -> bool {
        true
    }
}

//! 一个在运行时获取回溯的库
//!
//! 该库旨在通过允许在运行时以编程方式获取回溯来补充对标准库的 `RUST_BACKTRACE=1` 支持。
//! 例如，不需要解析此库生成的回溯，并且可以公开多个后端实现的功能。
//!
//! # Usage
//!
//! 首先，将此添加到您的 Cargo.toml
//!
//! ```toml
//! [dependencies]
//! backtrace = "0.3"
//! ```
//!
//! Next:
//!
//! ```
//! fn main() {
//! # // 这里不安全，因此测试通过了 no_std。
//! # #[cfg(feature = "std")] {
//!     backtrace::trace(|frame| {
//!         let ip = frame.ip();
//!         let symbol_address = frame.symbol_address();
//!
//!         // 将此指令指针解析为符号名称
//!         backtrace::resolve_frame(frame, |symbol| {
//!             if let Some(name) = symbol.name() {
//!                 // ...
//!             }
//!             if let Some(filename) = symbol.filename() {
//!                 // ...
//!             }
//!         });
//!
//!         true // 继续前进到下一帧
//!     });
//! }
//! # }
//! ```
//!
//! # 回溯的准确性
//!
//! 这个 crate 尽最大努力尝试获取本机回溯。这并不总是能保证工作，有些平台根本不返回任何回溯。
//! 如果您的应用程序需要准确的回溯，那么建议仔细评估此 crate 以查看它是否适合您在目标平台上的用例。
//!
//!
//! 即使在受支持的平台上，回溯也有很多不准确的原因，包括但不限于：
//!
//! * 展开信息可能不可用。这个 crate 主要是通过展开栈来实现回溯，但并不是所有的函数都有展开信息 (例如
//! DWARF 展开信息)。
//!
//! * 对于某些函数，Rust 代码可能在没有展开信息的情况下编译。使用 `-Cpanic=abort` 编译的 Rust 代码也可能发生这种情况。
//! 但是，您可以使用 `-Cforce-unwind-tables` 作为编译器选项来解决此问题。
//!
//! * 展开信息可能不准确或损坏。在最坏的情况下，不准确的展开信息可能导致该库出现段错误。
//! 在最好的情况下，不准确的信息将导致栈跟踪被截断。
//!
//! * 由于调试信息丢失或损坏，回溯可能无法正确报告文件名/行号。
//! 与损坏的展开信息不同，这不会导致段错误，但缺少或格式错误的调试信息将意味着文件名和行号将不可用。
//! 这可能是因为调试信息不是由编译器生成的，或者它只是在文件系统中丢失了。
//!
//! * 并非所有平台都受支持。例如，目前无法在 WebAssembly 上获得回溯。
//!
//! * Crate 特性可能被禁用。目前这个 crate 支持在非 Windows 平台上使用 Gimli libbacktrace 来读取回溯的调试信息。
//! 但是，如果禁用了 crate 的两个特性，那么这些平台将生成回溯但不能为它生成符号。
//!
//! 在大多数标准平台的大多数标准工作流中，您通常不需要担心这些警告。
//! 随着时间的推移，我们将尝试修复那些可以修复的问题，但除此之外，重要的是要注意基于展开的回溯的局限性！
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(html_root_url = "https://docs.rs/backtrace")]
#![deny(missing_docs)]
#![no_std]
#![cfg_attr(
    all(feature = "std", target_env = "sgx", target_vendor = "fortanix"),
    feature(sgx_platform)
)]
#![warn(rust_2018_idioms)]
// 当我们作为 libstd 的一部分进行构建时，请静默所有警告，因为它们无关紧要，因为此 crate 是在树外开发的。
//
#![cfg_attr(backtrace_in_libstd, allow(warnings))]
#![cfg_attr(not(feature = "std"), allow(dead_code))]
// 我们知道这已被弃用，它仅用于向后兼容的原因。
#![cfg_attr(feature = "rustc-serialize", allow(deprecated))]

#[cfg(feature = "std")]
#[macro_use]
extern crate std;

// 这仅用于 gimli，并且只在一些平台上使用，还有 miri，所以如果它在其他配置中未使用，也不用担心。
//
#[allow(unused_extern_crates)]
extern crate alloc;

pub use self::backtrace::{trace_unsynchronized, Frame};
mod backtrace;

pub use self::symbolize::resolve_frame_unsynchronized;
pub use self::symbolize::{resolve_unsynchronized, Symbol, SymbolName};
mod symbolize;

pub use self::types::BytesOrWideString;
mod types;

#[cfg(feature = "std")]
pub use self::symbolize::clear_symbol_cache;

mod print;
pub use print::{BacktraceFmt, BacktraceFrameFmt, PrintFmt};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        pub use self::backtrace::trace;
        pub use self::symbolize::{resolve, resolve_frame};
        pub use self::capture::{Backtrace, BacktraceFrame, BacktraceSymbol};
        mod capture;
    }
}

#[allow(dead_code)]
struct Bomb {
    enabled: bool,
}

#[allow(dead_code)]
impl Drop for Bomb {
    fn drop(&mut self) {
        if self.enabled {
            panic!("cannot panic during the backtrace function");
        }
    }
}

#[allow(dead_code)]
#[cfg(feature = "std")]
mod lock {
    use std::boxed::Box;
    use std::cell::Cell;
    use std::sync::{Mutex, MutexGuard, Once};

    pub struct LockGuard(Option<MutexGuard<'static, ()>>);

    static mut LOCK: *mut Mutex<()> = 0 as *mut _;
    static INIT: Once = Once::new();
    thread_local!(static LOCK_HELD: Cell<bool> = Cell::new(false));

    impl Drop for LockGuard {
        fn drop(&mut self) {
            if self.0.is_some() {
                LOCK_HELD.with(|slot| {
                    assert!(slot.get());
                    slot.set(false);
                });
            }
        }
    }

    pub fn lock() -> LockGuard {
        if LOCK_HELD.with(|l| l.get()) {
            return LockGuard(None);
        }
        LOCK_HELD.with(|s| s.set(true));
        unsafe {
            INIT.call_once(|| {
                LOCK = Box::into_raw(Box::new(Mutex::new(())));
            });
            LockGuard(Some((*LOCK).lock().unwrap()))
        }
    }
}

#[cfg(all(windows, not(target_vendor = "uwp")))]
mod dbghelp;
#[cfg(windows)]
mod windows;

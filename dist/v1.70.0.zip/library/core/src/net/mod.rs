//! IP 通信的网络原语。
//!
//! 此模块提供 IP 和套接字地址的类型。
//!
//! # Organization
//!
//! * [`IpAddr`] 代表 IPv4 或 IPv6 的 IP 地址； [`Ipv4Addr`] 和 [`Ipv6Addr`] 分别是 IPv4 和 IPv6 地址
//! * [`SocketAddr`] 代表 IPv4 或 IPv6 的套接字地址； [`SocketAddrV4`] 和 [`SocketAddrV6`] 分别是 IPv4 和 IPv6 套接字地址
//!
//!

#![unstable(feature = "ip_in_core", issue = "108443")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::ip_addr::{IpAddr, Ipv4Addr, Ipv6Addr, Ipv6MulticastScope};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::parser::AddrParseError;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::socket_addr::{SocketAddr, SocketAddrV4, SocketAddrV6};

mod display_buffer;
mod ip_addr;
mod parser;
mod socket_addr;

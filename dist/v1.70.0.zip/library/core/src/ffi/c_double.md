等效于 C 的 `double` 类型。

这种类型几乎总是 [`f64`]，在 Rust 中保证是 [IEEE 754 double-precision float]。也就是说，该标准从技术上仅保证它是至少具有 [`float`] 精度的浮点数，并且它可以是 `f32` 或与 IEEE-754 标准完全不同的东西。

[IEEE 754 double-precision float]: https://en.wikipedia.org/wiki/IEEE_754
[`float`]: c_float

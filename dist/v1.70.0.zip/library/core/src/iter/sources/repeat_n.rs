use crate::iter::{FusedIterator, TrustedLen};
use crate::mem::ManuallyDrop;
use crate::num::NonZeroUsize;

/// 创建一个新的迭代器，该迭代器将单个元素重复给定的次数。
///
/// `repeat_n()` 函数精确重复单个值 `n` 次。
///
/// 这与将 [`repeat()`] 与 [`Iterator::take()`] 一起使用非常相似，但有两个区别:
///
/// - `repeat_n()` 可以返回原始值，而不是总是克隆。
/// - `repeat_n()` 生成 [`ExactSizeIterator`]。
///
/// [`repeat()`]: crate::iter::repeat
///
/// # Examples
///
/// 基本用法：
///
/// ```
/// #![feature(iter_repeat_n)]
/// use std::iter;
///
/// // 数字 4 中的 4:
/// let mut four_fours = iter::repeat_n(4, 4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // 没有更多的四
/// assert_eq!(None, four_fours.next());
/// ```
///
/// 对于非 `复制` 类型，
///
/// ```
/// #![feature(iter_repeat_n)]
/// use std::iter;
///
/// let v: Vec<i32> = Vec::with_capacity(123);
/// let mut it = iter::repeat_n(v, 5);
///
/// for i in 0..4 {
///     // 它从克隆事物开始
///     let cloned = it.next().unwrap();
///     assert_eq!(cloned.len(), 0);
///     assert_eq!(cloned.capacity(), 0);
/// }
///
/// // ... 但最后一项是原来的
/// let last = it.next().unwrap();
/// assert_eq!(last.len(), 0);
/// assert_eq!(last.capacity(), 123);
///
/// // ... 现在我们完成了
/// assert_eq!(None, it.next());
/// ```
#[inline]
#[unstable(feature = "iter_repeat_n", issue = "104434")]
#[doc(hidden)] // 等待 ACP#120 决定是否公开
pub fn repeat_n<T: Clone>(element: T, count: usize) -> RepeatN<T> {
    let mut element = ManuallyDrop::new(element);

    if count == 0 {
        // SAFETY: 我们肯定还没有丢掉它，因为我们刚刚传入它，并且因为计数为零，我们将要创建的实例不会丢掉它，所以为了避免泄漏我们现在需要。
        //
        //
        unsafe { ManuallyDrop::drop(&mut element) };
    }

    RepeatN { element, count }
}

/// 将元素重复精确次数的迭代器。
///
/// 这个 `struct` 是由 [`repeat_n()`] 函数创造的。
/// 有关更多信息，请参见其文档。
#[derive(Clone, Debug)]
#[unstable(feature = "iter_repeat_n", issue = "104434")]
#[doc(hidden)] // 等待 ACP#120 决定是否公开
pub struct RepeatN<A> {
    count: usize,
    // 不，变体: 已丢弃当且仅当计数 == 0.
    element: ManuallyDrop<A>,
}

impl<A> RepeatN<A> {
    /// 如果我们还没有抛弃该元素，请在选项中返回它。
    ///
    /// 清除计数，这样以后就不会再丢了。
    #[inline]
    fn take_element(&mut self) -> Option<A> {
        if self.count > 0 {
            self.count = 0;
            // SAFETY: 我们只是将 count 设置为零，这样它就不会再次丢弃，并且它曾经是非零的，所以它还没有被丢弃。
            //
            unsafe { Some(ManuallyDrop::take(&mut self.element)) }
        } else {
            None
        }
    }
}

#[unstable(feature = "iter_repeat_n", issue = "104434")]
impl<A> Drop for RepeatN<A> {
    fn drop(&mut self) {
        self.take_element();
    }
}

#[unstable(feature = "iter_repeat_n", issue = "104434")]
impl<A: Clone> Iterator for RepeatN<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.count == 0 {
            return None;
        }

        self.count -= 1;
        Some(if self.count == 0 {
            // SAFETY: 上面的检查确保了计数曾经是非零的，所以元素还没有丢弃，我们只是将计数降低到零所以它以后不会丢弃，所以把它放在这里是可以的。
            //
            //
            unsafe { ManuallyDrop::take(&mut self.element) }
        } else {
            A::clone(&self.element)
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    #[inline]
    fn advance_by(&mut self, skip: usize) -> Result<(), NonZeroUsize> {
        let len = self.count;

        if skip >= len {
            self.take_element();
        }

        if skip > len {
            // SAFETY: 我们刚刚检查了差异是积极的
            Err(unsafe { NonZeroUsize::new_unchecked(skip - len) })
        } else {
            self.count = len - skip;
            Ok(())
        }
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.take_element()
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }
}

#[unstable(feature = "iter_repeat_n", issue = "104434")]
impl<A: Clone> ExactSizeIterator for RepeatN<A> {
    fn len(&self) -> usize {
        self.count
    }
}

#[unstable(feature = "iter_repeat_n", issue = "104434")]
impl<A: Clone> DoubleEndedIterator for RepeatN<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn advance_back_by(&mut self, n: usize) -> Result<(), NonZeroUsize> {
        self.advance_by(n)
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        self.nth(n)
    }
}

#[unstable(feature = "iter_repeat_n", issue = "104434")]
impl<A: Clone> FusedIterator for RepeatN<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for RepeatN<A> {}

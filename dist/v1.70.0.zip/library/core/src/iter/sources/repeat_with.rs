use crate::fmt;
use crate::iter::{FusedIterator, TrustedLen};
use crate::ops::Try;

/// 创建一个新的迭代器，通过应用提供的闭包，转发器 `F: FnMut() -> A`，无限地重复 `A` 类型的元素。
///
/// `repeat_with()` 函数一遍又一遍地调用中继器。
///
/// 无限迭代器 (如 `repeat_with()`) 通常与适配器 (如 [`Iterator::take()`]) 一起使用，以使其具有有限性。
///
/// 如果您需要的迭代器的元素类型实现 [`Clone`]，并且可以将源元素保留在内存中，则应改用 [`repeat()`] 函数。
///
///
/// `repeat_with()` 产生的迭代器不是 [`DoubleEndedIterator`]。
/// 如果您需要 `repeat_with()` 来返回 [`DoubleEndedIterator`]，请打开 GitHub 问题，说明您的用例。
///
/// [`repeat()`]: crate::iter::repeat
///
/// # Examples
///
/// 基本用法：
///
/// ```
/// use std::iter;
///
/// // 假设我们有一些不是 `Clone` 类型的值，或者我们还不想在内存中拥有它，因为它很昂贵:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // 永远具有特定的值：
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// 使用可变和有限化：
///
/// ```rust
/// use std::iter;
///
/// // 从两个的零次幂到三次幂：
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... 现在我们完成了
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// 一个迭代器，通过应用提供的闭包 `F: FnMut() -> A`，无限地重复 `A` 类型的元素。
///
///
/// 该 `struct` 由 [`repeat_with()`] 函数创建。
/// 有关更多信息，请参见其文档。
#[derive(Copy, Clone)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with_debug", since = "1.68.0")]
impl<F> fmt::Debug for RepeatWith<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("RepeatWith").finish_non_exhaustive()
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn try_fold<Acc, Fold, R>(&mut self, mut init: Acc, mut fold: Fold) -> R
    where
        Fold: FnMut(Acc, Self::Item) -> R,
        R: Try<Output = Acc>,
    {
        // 这种覆盖并不是严格需要的，但避免了优化 `next`-always-returns-`Some` 的需要，并强调 `?` 是退出循环的唯一方法。
        //
        //

        loop {
            let item = (self.repeater)();
            init = fold(init, item)?;
        }
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}

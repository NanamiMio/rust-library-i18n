use crate::iter::TrustedLen;

/// [`TrustedLen`] 不能有方法，所以这允许扩充它。
///
/// 它目前需要 `TrustedLen`，因为尚不清楚依赖 `size_hint` 是否合理。
///
pub(crate) trait UncheckedIterator: TrustedLen {
    /// 从非空迭代器获取下一项。
    ///
    /// 因为总是有一个值要返回，这意味着它可以直接返回 `Item` 类型，而无需将其包装在 `Option` 中。
    ///
    /// # Safety
    ///
    /// 这只能在 `size_hint().0 != 0` 时调用，保证至少有一项可用。
    ///
    /// 否则 (也就是当 `size_hint ().1 == Some(0)`) 时，这是 UB。
    ///
    /// # 给实现者的注意事项
    ///
    /// 这有一个使用 [`Option::unwrap_unchecked`] 的默认实现。
    /// 如果您的 `next`*总是*返回 `Some`，这可能就足够了，例如对于无限迭代器。
    /// 然而，在更复杂的情况下，有时 `Option` 处理中的 IR 中仍会残留 `insertvalue`/`assume`/`extractvalue` 指令，此时您可能希望手动实现它。
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "trusted_len_next_unchecked", issue = "37572")]
    #[inline]
    unsafe fn next_unchecked(&mut self) -> Self::Item {
        let opt = self.next();
        // SAFETY: 调用者承诺我们不是空的，`Self: TrustedLen` 所以我们实际上可以信任 `size_hint`。
        //
        unsafe { opt.unwrap_unchecked() }
    }
}

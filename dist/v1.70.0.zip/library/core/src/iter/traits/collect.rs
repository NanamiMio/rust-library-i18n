/// 从 [`Iterator`] 转换。
///
/// 通过为类型实现 `FromIterator`，可以定义如何从迭代器创建它。
/// 这对于描述某种集合的类型很常见。
///
/// 如果想从迭代器的内容中创建一个集合，则首选 [`Iterator::collect()`] 方法。
/// 但是，当您需要指定容器类型时，[`FromIterator::from_iter()`] 比使用 turbofish 更具可读性 (例如
///
/// `::<Vec<_>>()`).
/// 有关其使用的更多示例，请参见 [`Iterator::collect()`] 文档。
///
/// 另请参见：[`IntoIterator`]。
///
/// # Examples
///
/// 基本用法：
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// 使用 [`Iterator::collect()`] 隐式使用 `FromIterator`：
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// 使用 [`FromIterator::from_iter()`] 作为更易读的替代方案
/// [`Iterator::collect()`]:
///
/// ```
/// use std::collections::VecDeque;
/// let first = (0..10).collect::<VecDeque<i32>>();
/// let second = VecDeque::from_iter(0..10);
///
/// assert_eq!(first, second);
/// ```
///
/// 为您的类型实现 `FromIterator`：
///
/// ```
/// // 一个样本集合，这只是 Vec<T> 的包装
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // 让我们给它一些方法，以便我们可以创建一个方法并向其中添加一些东西。
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // 我们将实现 FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // 现在我们可以创建一个新的迭代器...
/// let iter = (0..5).into_iter();
///
/// // ... 并用它制作一个 MyCollection
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // 也收集作品！
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[{A}]",
        message = "a slice of type `{Self}` cannot be built since `{Self}` has no definite size",
        label = "try explicitly collecting into a `Vec<{A}>`",
    ),
    on(
        all(A = "{integer}", any(_Self = "[{integral}]",)),
        message = "a slice of type `{Self}` cannot be built since `{Self}` has no definite size",
        label = "try explicitly collecting into a `Vec<{A}>`",
    ),
    on(
        _Self = "[{A}; _]",
        message = "an array of type `{Self}` cannot be built directly from an iterator",
        label = "try collecting into a `Vec<{A}>`, then using `.try_into()`",
    ),
    on(
        all(A = "{integer}", any(_Self = "[{integral}; _]",)),
        message = "an array of type `{Self}` cannot be built directly from an iterator",
        label = "try collecting into a `Vec<{A}>`, then using `.try_into()`",
    ),
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
#[rustc_diagnostic_item = "FromIterator"]
pub trait FromIterator<A>: Sized {
    /// 从迭代器创建一个值。
    ///
    /// 有关更多信息，请参见 [模块级文档][module-level documentation]。
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// 转换为 [`Iterator`]。
///
/// 通过为类型实现 `IntoIterator`，可以定义如何将其转换为迭代器。
/// 这对于描述某种集合的类型很常见。
///
/// 实现 `IntoIterator` 的好处之一是您的类型将为 [使用 Rust 的 `for` 循环语法](crate::iter#for-loops-and-intoiterator)。
///
///
/// 另请参见：[`FromIterator`]。
///
/// # Examples
///
/// 基本用法：
///
/// ```
/// let v = [1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// 为您的类型实现 `IntoIterator`：
///
/// ```
/// // 一个样本集合，这只是 Vec<T> 的包装
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // 让我们给它一些方法，以便我们可以创建一个方法并向其中添加一些东西。
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // 我们将实现 IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // 现在我们可以做一个新的集合...
/// let mut c = MyCollection::new();
///
/// // ... 添加一些东西...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... 然后将其转换为迭代器：
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// 通常将 `IntoIterator` 用作 trait bound。只要它仍然是迭代器，就可以更改输入集合类型。
/// 可以通过限制限制来指定其他范围
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{item:?}"))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[rustc_skip_array_during_method_dispatch]
#[stable(feature = "rust1", since = "1.0.0")]
#[const_trait]
pub trait IntoIterator {
    /// 被迭代的元素的类型。
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// 我们将其变成哪种迭代器？
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// 从一个值创建一个迭代器。
    ///
    /// 有关更多信息，请参见 [模块级文档][module-level documentation]。
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let v = [1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[rustc_const_unstable(feature = "const_intoiterator_identity", issue = "90603")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> const IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    #[inline]
    fn into_iter(self) -> I {
        self
    }
}

/// 用迭代器的内容扩展集合。
///
/// 迭代器产生一系列值，并且集合也可以视为一系列值。
/// `Extend` trait 弥补了这一差距，使您可以通过包含该迭代器的内容来扩展集合。
/// 当使用已经存在的键扩展集合时，该条目将被更新; 如果集合允许多个具有相同键的条目，则将插入该条目。
///
///
/// # Examples
///
/// 基本用法：
///
/// ```
/// // 您可以使用一些字符扩展 String：
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// 实现 `Extend`：
///
/// ```
/// // 一个样本集合，这只是 Vec<T> 的包装
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // 让我们给它一些方法，以便我们可以创建一个方法并向其中添加一些东西。
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // 由于 MyCollection 包含 i32 的列表，因此我们为 i32 实现 Extend
/// impl Extend<i32> for MyCollection {
///
///     // 使用具体的类型签名，这要简单一些：我们可以调用扩展为可转换为 It32 的 Iterator 的任何内容。
///     // 因为我们需要将 i32 放入 MyCollection 中。
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // 实现非常简单：遍历迭代器，然后将每个元素 add() 传递给我们自己。
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // 让我们用三个数字扩展集合
/// c.extend(vec![1, 2, 3]);
///
/// // 我们已经将这些元素添加到最后
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{c:?}"));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// 使用迭代器的内容扩展集合。
    ///
    /// 由于这是此 trait 唯一需要的方法，因此 [trait-level] 文档包含更多详细信息。
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// // 您可以使用一些字符扩展 String：
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// 用一个元素扩展一个集合。
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// 在集合中为给定数量的附加元素保留容量。
    ///
    /// 默认实现不执行任何操作。
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}

#[stable(feature = "extend_for_tuple", since = "1.56.0")]
impl<A, B, ExtendA, ExtendB> Extend<(A, B)> for (ExtendA, ExtendB)
where
    ExtendA: Extend<A>,
    ExtendB: Extend<B>,
{
    /// 允许 `extend` 一个集合的元组也实现 `Extend`。
    ///
    /// 另请参见：[`Iterator::unzip`]
    ///
    /// # Examples
    /// ```
    /// let mut tuple = (vec![0], vec![1]);
    /// tuple.extend([(2, 3), (4, 5), (6, 7)]);
    /// assert_eq!(tuple.0, [0, 2, 4, 6]);
    /// assert_eq!(tuple.1, [1, 3, 5, 7]);
    ///
    /// // 还允许任意嵌套的元组作为元素
    /// let mut nested_tuple = (vec![1], (vec![2], vec![3]));
    /// nested_tuple.extend([(4, (5, 6)), (7, (8, 9))]);
    ///
    /// let (a, (b, c)) = nested_tuple;
    /// assert_eq!(a, [1, 4, 7]);
    /// assert_eq!(b, [2, 5, 8]);
    /// assert_eq!(c, [3, 6, 9]);
    /// ```
    fn extend<T: IntoIterator<Item = (A, B)>>(&mut self, into_iter: T) {
        let (a, b) = self;
        let iter = into_iter.into_iter();

        fn extend<'a, A, B>(
            a: &'a mut impl Extend<A>,
            b: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                a.extend_one(t);
                b.extend_one(u);
            }
        }

        let (lower_bound, _) = iter.size_hint();
        if lower_bound > 0 {
            a.extend_reserve(lower_bound);
            b.extend_reserve(lower_bound);
        }

        iter.fold((), extend(a, b));
    }

    fn extend_one(&mut self, item: (A, B)) {
        self.0.extend_one(item.0);
        self.1.extend_one(item.1);
    }

    fn extend_reserve(&mut self, additional: usize) {
        self.0.extend_reserve(additional);
        self.1.extend_reserve(additional);
    }
}

// 有关文档，请参见 src/libstd/primitive_docs.rs。

use crate::cmp::Ordering::{self, *};
use crate::mem::transmute;

// 用于实现 n 元组函数和操作的递归宏
//
// 还提供了具有较少元组的实现。
// 例如，tuple_impls!(ABC) 将实现 (A, B, C)、(A, B) 和 (A,) 的所有内容。
macro_rules! tuple_impls {
    // 停止条件 (1 元组)
    ($T:ident) => {
        tuple_impls!(@impl $T);
    };
    // 运行条件 (n 元元组，n >= 2)
    ($T:ident $( $U:ident )+) => {
        tuple_impls!($( $U )+);
        tuple_impls!(@impl $T $( $U )+);
    };
    // "Private" 内部实现
    (@impl $( $T:ident )+) => {
        maybe_tuple_doc! {
            $($T)+ @
            #[stable(feature = "rust1", since = "1.0.0")]
            #[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
            impl<$($T: ~const PartialEq),+> const PartialEq for ($($T,)+)
            where
                last_type!($($T,)+): ?Sized
            {
                #[inline]
                fn eq(&self, other: &($($T,)+)) -> bool {
                    $( ${ignore(T)} self.${index()} == other.${index()} )&&+
                }
                #[inline]
                fn ne(&self, other: &($($T,)+)) -> bool {
                    $( ${ignore(T)} self.${index()} != other.${index()} )||+
                }
            }
        }

        maybe_tuple_doc! {
            $($T)+ @
            #[stable(feature = "rust1", since = "1.0.0")]
            impl<$($T: Eq),+> Eq for ($($T,)+)
            where
                last_type!($($T,)+): ?Sized
            {}
        }

        maybe_tuple_doc! {
            $($T)+ @
            #[stable(feature = "rust1", since = "1.0.0")]
            #[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
            impl<$($T: ~const PartialOrd + ~const PartialEq),+> const PartialOrd for ($($T,)+)
            where
                last_type!($($T,)+): ?Sized
            {
                #[inline]
                fn partial_cmp(&self, other: &($($T,)+)) -> Option<Ordering> {
                    lexical_partial_cmp!($( ${ignore(T)} self.${index()}, other.${index()} ),+)
                }
                #[inline]
                fn lt(&self, other: &($($T,)+)) -> bool {
                    lexical_ord!(lt, Less, $( ${ignore(T)} self.${index()}, other.${index()} ),+)
                }
                #[inline]
                fn le(&self, other: &($($T,)+)) -> bool {
                    lexical_ord!(le, Less, $( ${ignore(T)} self.${index()}, other.${index()} ),+)
                }
                #[inline]
                fn ge(&self, other: &($($T,)+)) -> bool {
                    lexical_ord!(ge, Greater, $( ${ignore(T)} self.${index()}, other.${index()} ),+)
                }
                #[inline]
                fn gt(&self, other: &($($T,)+)) -> bool {
                    lexical_ord!(gt, Greater, $( ${ignore(T)} self.${index()}, other.${index()} ),+)
                }
            }
        }

        maybe_tuple_doc! {
            $($T)+ @
            #[stable(feature = "rust1", since = "1.0.0")]
            #[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
            impl<$($T: ~const Ord),+> const Ord for ($($T,)+)
            where
                last_type!($($T,)+): ?Sized
            {
                #[inline]
                fn cmp(&self, other: &($($T,)+)) -> Ordering {
                    lexical_cmp!($( ${ignore(T)} self.${index()}, other.${index()} ),+)
                }
            }
        }

        maybe_tuple_doc! {
            $($T)+ @
            #[stable(feature = "rust1", since = "1.0.0")]
            #[rustc_const_unstable(feature = "const_default_impls", issue = "87864")]
            impl<$($T: ~const Default),+> const Default for ($($T,)+) {
                #[inline]
                fn default() -> ($($T,)+) {
                    ($({ let x: $T = Default::default(); x},)+)
                }
            }
        }
    }
}

// 如果这是一个一元元组，它会添加一个文档注释。
// 否则，它会完全隐藏文档。
macro_rules! maybe_tuple_doc {
    ($a:ident @ #[$meta:meta] $item:item) => {
        #[doc(fake_variadic)]
        #[doc = "This trait is implemented for tuples up to twelve items long."]
        #[$meta]
        $item
    };
    ($a:ident $($rest_a:ident)+ @ #[$meta:meta] $item:item) => {
        #[doc(hidden)]
        #[$meta]
        $item
    };
}

#[inline]
const fn ordering_is_some(c: Option<Ordering>, x: Ordering) -> bool {
    // FIXME: 一旦 `==` 在 `Option` 上是常量稳定的，只需使用它。
    // 这不是使用 `match`，因为由于进行两步检查 (`Some`*然后*内部值)，优化更差。
    //

    // SAFETY: `Option<Ordering>` 没有公共保证，但我们是核心，所以我们知道它肯定是一个字节。
    //
    unsafe {
        let c: i8 = transmute(c);
        let x: i8 = transmute(Some(x));
        c == x
    }
}

// 使用方法 `$rel` 创建一个执行词法排序的表达式。
// 这些值是交错的，因此 `(a1, a2, a3) < (b1, b2, b3)` 的宏调用将是 `lexical_ord!(lt, opt_is_lt, a1, b1, a2, b2, a3, b3)` (对于 `lexical_cmp` 也类似)
//
//
// `$ne_rel` 只是用来判断不相等的结果，所以 `lt` 和 `le` 都可以只用 `Less`。
//
//
macro_rules! lexical_ord {
    ($rel: ident, $ne_rel: ident, $a:expr, $b:expr, $($rest_a:expr, $rest_b:expr),+) => {{
        let c = PartialOrd::partial_cmp(&$a, &$b);
        if !ordering_is_some(c, Equal) { ordering_is_some(c, $ne_rel) }
        else { lexical_ord!($rel, $ne_rel, $($rest_a, $rest_b),+) }
    }};
    ($rel: ident, $ne_rel: ident, $a:expr, $b:expr) => {
        // 对最后一个元素使用特定方法
        PartialOrd::$rel(&$a, &$b)
    };
}

macro_rules! lexical_partial_cmp {
    ($a:expr, $b:expr, $($rest_a:expr, $rest_b:expr),+) => {
        match ($a).partial_cmp(&$b) {
            Some(Equal) => lexical_partial_cmp!($($rest_a, $rest_b),+),
            ordering   => ordering
        }
    };
    ($a:expr, $b:expr) => { ($a).partial_cmp(&$b) };
}

macro_rules! lexical_cmp {
    ($a:expr, $b:expr, $($rest_a:expr, $rest_b:expr),+) => {
        match ($a).cmp(&$b) {
            Equal => lexical_cmp!($($rest_a, $rest_b),+),
            ordering   => ordering
        }
    };
    ($a:expr, $b:expr) => { ($a).cmp(&$b) };
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple_impls!(E D C B A Z Y X W V U T);
